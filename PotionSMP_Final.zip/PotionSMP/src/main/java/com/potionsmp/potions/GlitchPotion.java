package com.potionsmp.potions;

import com.potionsmp.PotionSMP;
import com.potionsmp.managers.PotionManager;
import com.potionsmp.utils.PotionType;
import org.bukkit.*;
import org.bukkit.boss.BarColor;
import org.bukkit.entity.*;
import org.bukkit.event.player.PlayerPickupItemEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

import java.util.*;

/**
 * ⚡ Glitch Potion
 * Passive: Mining Fatigue I (infinite), subtle glitch particles
 * Active: System Corruption — force drop item, no-pickup 10s,
 *         micro-teleport stutters, purple/cyan glitch particles
 * Cooldown: 35s
 */
public class GlitchPotion {

    private final PotionSMP plugin;
    private final Set<UUID> active      = new HashSet<>();
    private final Set<UUID> noPickup    = new HashSet<>();
    // targets currently corrupted
    private final Map<UUID, Integer> corruptionTasks = new HashMap<>();

    public GlitchPotion(PotionSMP plugin) { this.plugin = plugin; }

    // ── Passive: apply on equip ────────────────────────────────────────────────
    public void onEquip(Player player) {
        player.addPotionEffect(new PotionEffect(PotionEffectType.MINING_FATIGUE,
            Integer.MAX_VALUE, 0, false, false));
        startPassiveAura(player);
    }

    public void onUnequip(Player player) {
        player.removePotionEffect(PotionEffectType.MINING_FATIGUE);
        cleanup(player);
        plugin.getAuraManager().stop(player.getUniqueId());
    }

    private void startPassiveAura(Player player) {
        UUID uuid = player.getUniqueId();
        Random rand = new Random();
        plugin.getAuraManager().start(uuid, () -> {
            if (!player.isOnline()) return;
            if (rand.nextInt(3) != 0) return;
            Location loc = player.getLocation().add(0, 1, 0);
            loc.getWorld().spawnParticle(Particle.DUST,
                loc.clone().add((rand.nextDouble()-0.5)*0.8, (rand.nextDouble()-0.5)*0.8,
                                (rand.nextDouble()-0.5)*0.8),
                1, new Particle.DustOptions(Color.fromRGB(150, 0, 255), 0.6f));
            loc.getWorld().spawnParticle(Particle.END_ROD,
                loc.clone().add((rand.nextDouble()-0.5)*0.5, 0, (rand.nextDouble()-0.5)*0.5),
                1, 0, 0, 0, 0.02);
        }, 3L);
    }

    // ── Active ─────────────────────────────────────────────────────────────────
    public void activate(Player attacker, LivingEntity targetEntity) {
        UUID uuid = attacker.getUniqueId();
        var cdm = plugin.getCooldownManager();

        if (cdm.isOnCooldown(uuid, PotionType.GLITCH)) {
            plugin.getPotionManager().sendCooldown(attacker, PotionType.GLITCH);
            return;
        }

        if (!(targetEntity instanceof Player target)) {
            PotionManager.actionBar(attacker, "§cGlitch only works on players!");
            return;
        }

        active.add(uuid);
        int dur   = plugin.getConfig().getInt("glitch.duration", 10);
        int ticks = dur * 20;
        int stutterCount = plugin.getConfig().getInt("glitch.stutter-count", 4);
        cdm.setCooldown(uuid, PotionType.GLITCH, plugin.getConfig().getLong("glitch.cooldown", 35));

        attacker.sendTitle("§d§l⚡ SYSTEM CORRUPTION", "§5Corrupting target...", 5, 40, 10);
        plugin.getBossBarManager().show(attacker, "§d⚡ System Corruption", BarColor.PURPLE, dur);

        // Activation burst on attacker
        Location aLoc = attacker.getLocation().add(0, 1, 0);
        aLoc.getWorld().spawnParticle(Particle.PORTAL, aLoc, 60, 0.5, 0.5, 0.5, 0.8);
        aLoc.getWorld().spawnParticle(Particle.END_ROD, aLoc, 30, 0.4, 0.4, 0.4, 0.3);
        aLoc.getWorld().spawnParticle(Particle.DUST, aLoc, 40,
            new Particle.DustOptions(Color.fromRGB(150, 0, 255), 1.2f));
        aLoc.getWorld().playSound(aLoc.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 1.5f, 0.4f);
        aLoc.getWorld().playSound(aLoc.getLocation(), Sound.BLOCK_RESPAWN_ANCHOR_CHARGE, 1f, 1.5f);

        // 1. Force drop held item
        ItemStack held = target.getInventory().getItemInMainHand();
        if (!held.getType().isAir()) {
            target.getInventory().setItemInMainHand(null);
            Item dropped = target.getWorld().dropItem(target.getLocation(), held);
            dropped.setPickupDelay(40);
            target.getWorld().spawnParticle(Particle.PORTAL,
                target.getLocation().add(0, 1, 0), 20, 0.3, 0.3, 0.3, 0.5);
            target.getWorld().playSound(target.getLocation(), Sound.ENTITY_ITEM_BREAK, 1f, 0.5f);
        }

        // 2. No-pickup state
        noPickup.add(target.getUniqueId());

        // 3. Notify target
        target.sendTitle("§d§l⚡ SYSTEM CORRUPTED", "§5Cannot pick up items!", 5, 60, 10);
        target.sendMessage("§d⚡ System Corruption by §f" + attacker.getName());
        target.getWorld().playSound(target.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 1.5f, 0.3f);

        // 4. Main corruption loop — particles + micro-stutters
        int stutterInterval = Math.max(1, ticks / (stutterCount + 1));
        int[] tick = {0};
        int[] stuttersDone = {0};
        Random rand = new Random();

        org.bukkit.scheduler.BukkitTask task = plugin.getServer().getScheduler()
            .runTaskTimer(plugin, () -> {
                if (tick[0]++ >= ticks || !target.isOnline()) {
                    endCorruption(target);
                    return;
                }
                Location loc = target.getLocation();

                // Glitch particles
                if (tick[0] % 2 == 0) {
                    loc.getWorld().spawnParticle(Particle.DUST,
                        loc.clone().add(rnd(rand), rnd(rand)+1, rnd(rand)), 3,
                        new Particle.DustOptions(Color.fromRGB(150, 0, 255), 0.8f));
                    loc.getWorld().spawnParticle(Particle.DUST,
                        loc.clone().add(rnd(rand), rnd(rand)+1, rnd(rand)), 2,
                        new Particle.DustOptions(Color.fromRGB(0, 255, 220), 0.8f));
                    loc.getWorld().spawnParticle(Particle.END_ROD,
                        loc.clone().add(rnd(rand)*0.5, 1+rnd(rand), rnd(rand)*0.5),
                        1, 0, 0, 0, 0.05);
                }
                if (tick[0] % 10 == 0) {
                    loc.getWorld().spawnParticle(Particle.PORTAL, loc.clone().add(0,1,0),
                        15, 0.5, 0.5, 0.5, 0.3);
                    loc.getWorld().playSound(loc, Sound.BLOCK_RESPAWN_ANCHOR_CHARGE, 0.5f, 2f);
                }

                // Micro-teleport stutter
                if (stuttersDone[0] < stutterCount && tick[0] == stutterInterval * (stuttersDone[0] + 1)) {
                    stuttersDone[0]++;
                    double ox = (rand.nextDouble()*2-1) * (1 + rand.nextDouble());
                    double oz = (rand.nextDouble()*2-1) * (1 + rand.nextDouble());
                    Location stutter = loc.clone().add(ox, 0, oz);
                    stutter.setYaw(loc.getYaw()); stutter.setPitch(loc.getPitch());
                    if (stutter.getBlock().getType().isAir() &&
                        stutter.clone().add(0,1,0).getBlock().getType().isAir()) {
                        target.teleport(stutter);
                    }
                    stutter.getWorld().spawnParticle(Particle.PORTAL, stutter, 25, 0.3, 0.5, 0.3, 0.4);
                    stutter.getWorld().spawnParticle(Particle.END_ROD, stutter, 10, 0.3, 0.3, 0.3, 0.1);
                    stutter.getWorld().playSound(stutter, Sound.ITEM_CHORUS_FRUIT_TELEPORT, 1f, 1.5f);
                    target.setVelocity(new Vector(
                        (rand.nextDouble()-0.5)*0.3, 0.1, (rand.nextDouble()-0.5)*0.3));
                }
            }, 0L, 1L);
        corruptionTasks.put(target.getUniqueId(), task.getTaskId());

        plugin.getTaskManager().later(uuid, () -> end(attacker), ticks);
    }

    private void endCorruption(Player target) {
        UUID uid = target.getUniqueId();
        noPickup.remove(uid);
        Integer taskId = corruptionTasks.remove(uid);
        if (taskId != null) plugin.getServer().getScheduler().cancelTask(taskId);
        if (target.isOnline()) {
            target.sendMessage("§7System Corruption has faded.");
            target.getWorld().playSound(target.getLocation(),
                Sound.BLOCK_REDSTONE_TORCH_BURNOUT, 1f, 0.8f);
        }
    }

    private double rnd(Random r) { return (r.nextDouble()-0.5)*1.2; }

    public boolean hasNoPickup(UUID uuid) { return noPickup.contains(uuid); }

    public void end(Player player) {
        active.remove(player.getUniqueId());
        plugin.getBossBarManager().remove(player.getUniqueId());
        PotionManager.actionBar(player, "§7System Corruption ended.");
    }

    public void cleanup(Player player) {
        UUID uuid = player.getUniqueId();
        active.remove(uuid);
    }

    public boolean isActive(UUID uuid) { return active.contains(uuid); }
}
