package com.potionsmp.potions;

import com.potionsmp.PotionSMP;
import com.potionsmp.managers.PotionManager;
import com.potionsmp.utils.PotionType;
import org.bukkit.*;
import org.bukkit.boss.BarColor;
import org.bukkit.entity.*;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

import java.util.*;

/**
 * ❄️ Freeze Potion
 * Passive: Every 10 hits → stun target 1s
 * Active (Right Click): Arctic Prison — 10-block freeze blast, 3s, 45s CD
 */
public class FreezePotion {

    private final PotionSMP plugin;
    private final Set<UUID> active = new HashSet<>();
    private final Map<UUID, Integer> hitCounters = new HashMap<>();
    // frozen entities: uuid -> task id
    private final Map<UUID, Integer> frozenTasks = new HashMap<>();
    private final Map<UUID, Location> frozenLocs = new HashMap<>();

    public FreezePotion(PotionSMP plugin) { this.plugin = plugin; }

    // ── Passive: hit counter ───────────────────────────────────────────────────
    public void onHit(Player attacker, LivingEntity target) {
        UUID uuid = attacker.getUniqueId();
        int hits = hitCounters.merge(uuid, 1, Integer::sum);

        // Subtle snowflake on each hit
        target.getWorld().spawnParticle(Particle.SNOWFLAKE,
            target.getLocation().add(0, 1, 0), 2, 0.15, 0.15, 0.15, 0.01);

        if (hits >= 10) {
            hitCounters.put(uuid, 0);
            freezeEntity(target, 20); // 1 second stun

            target.getWorld().spawnParticle(Particle.SNOWFLAKE,
                target.getLocation().add(0, 1, 0), 15, 0.5, 0.5, 0.5, 0.05);
            target.getWorld().spawnParticle(Particle.ITEM_SNOWBALL,
                target.getLocation().add(0, 1, 0), 8, 0.4, 0.4, 0.4, 0.05);
            target.getWorld().playSound(target.getLocation(), Sound.BLOCK_GLASS_BREAK, 1f, 1.5f);
            PotionManager.actionBar(attacker, "§b❄ Passive freeze triggered!");
        }
    }

    // ── Active ─────────────────────────────────────────────────────────────────
    public void activate(Player player) {
        UUID uuid = player.getUniqueId();
        var cdm = plugin.getCooldownManager();

        if (cdm.isOnCooldown(uuid, PotionType.FREEZE)) {
            plugin.getPotionManager().sendCooldown(player, PotionType.FREEZE);
            return;
        }

        active.add(uuid);
        int dur   = plugin.getConfig().getInt("freeze.duration", 3);
        int freezeTicks = dur * 20;
        int totalDur = plugin.getConfig().getInt("freeze.active-duration", 3);

        player.sendTitle("§b§l❄ ARCTIC PRISON", "§7The world freezes around you.", 5, 40, 10);
        plugin.getBossBarManager().show(player, "§b❄ Arctic Prison", BarColor.BLUE, totalDur);
        cdm.setCooldown(uuid, PotionType.FREEZE, plugin.getConfig().getLong("freeze.cooldown", 45));

        Location center = player.getLocation();
        int radius = plugin.getConfig().getInt("freeze.radius", 10);

        // Massive snowstorm burst
        center.getWorld().spawnParticle(Particle.SNOWFLAKE, center.clone().add(0, 1, 0),
            200, radius / 2.0, 2, radius / 2.0, 0.08);
        center.getWorld().spawnParticle(Particle.ITEM_SNOWBALL, center.clone().add(0, 1, 0),
            100, radius / 2.0, 1.5, radius / 2.0, 0.3);
        center.getWorld().spawnParticle(Particle.SNOWFLAKE, center.clone().add(0, 1, 0),
            80, 1, 1, 1, 0.5);
        center.getWorld().playSound(center, Sound.ENTITY_GUARDIAN_ELDER_CURSE, 1.5f, 0.5f);
        center.getWorld().playSound(center, Sound.BLOCK_POWDER_SNOW_STEP, 1.5f, 0.5f);

        // Freeze all nearby entities
        for (Entity e : center.getWorld().getNearbyEntities(center, radius, radius, radius)) {
            if (e instanceof LivingEntity le && !e.getUniqueId().equals(uuid)) {
                freezeEntity(le, freezeTicks);
                if (le instanceof Player p)
                    p.sendMessage("§b❄ You are frozen by §f" + player.getName() + "§b!");
            }
        }

        // Ice aura + spinning ring during duration
        double[] angle = {0};
        int[] t = {0};
        plugin.getAuraManager().start(uuid, () -> {
            if (!active.contains(uuid) || !player.isOnline()) return;
            Location loc = player.getLocation().add(0, 1, 0);

            // Two counter-rotating ice rings
            for (int i = 0; i < 16; i++) {
                double a = Math.toRadians((360.0 / 16 * i) + angle[0]);
                loc.getWorld().spawnParticle(Particle.SNOWFLAKE,
                    loc.getX() + Math.cos(a) * 1.4,
                    loc.getY() + 0.2,
                    loc.getZ() + Math.sin(a) * 1.4,
                    1, 0, 0, 0, 0.01);
            }
            for (int i = 0; i < 10; i++) {
                double a = Math.toRadians((360.0 / 10 * i) - angle[0] * 1.5);
                loc.getWorld().spawnParticle(Particle.ITEM_SNOWBALL,
                    loc.getX() + Math.cos(a) * 0.8,
                    loc.getY() + 0.5,
                    loc.getZ() + Math.sin(a) * 0.8,
                    1, 0, 0, 0, 0.01);
            }

            // Frost mist
            if (t[0] % 3 == 0)
                loc.getWorld().spawnParticle(Particle.SNOWFLAKE,
                    loc.getX(), loc.getY() - 0.8, loc.getZ(),
                    6, 0.4, 0.1, 0.4, 0.02);

            // Outer ring
            for (int i = 0; i < 12; i++) {
                double a = Math.toRadians((360.0 / 12 * i) + angle[0] * 0.5);
                center.getWorld().spawnParticle(Particle.SNOWFLAKE,
                    center.getX() + Math.cos(a) * radius * 0.7,
                    center.getY() + 1,
                    center.getZ() + Math.sin(a) * radius * 0.7,
                    1, 0, 0, 0, 0);
            }

            angle[0] += 6;
            t[0]++;
        }, 1L);

        plugin.getTaskManager().later(uuid, () -> end(player), freezeTicks);
    }

    // ── Freeze Entity ──────────────────────────────────────────────────────────
    private void freezeEntity(LivingEntity entity, int durationTicks) {
        UUID uid = entity.getUniqueId();
        // Cancel existing freeze task
        Integer existing = frozenTasks.remove(uid);
        if (existing != null) plugin.getServer().getScheduler().cancelTask(existing);

        Location loc = entity.getLocation().clone();
        frozenLocs.put(uid, loc);

        entity.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, durationTicks + 5, 254, false, false));
        entity.addPotionEffect(new PotionEffect(PotionEffectType.MINING_FATIGUE, durationTicks + 5, 254, false, false));
        entity.addPotionEffect(new PotionEffect(PotionEffectType.JUMP_BOOST, durationTicks + 5, 128, false, false));

        int[] ticks = {0};
        org.bukkit.scheduler.BukkitTask task = plugin.getServer().getScheduler()
            .runTaskTimer(plugin, () -> {
                if (ticks[0]++ >= durationTicks || !entity.isValid()) {
                    unfreezeEntity(uid);
                    return;
                }
                if (entity.getLocation().distanceSquared(loc) > 0.1)
                    entity.teleport(loc);
                entity.setVelocity(new Vector(0, 0, 0));
                entity.getWorld().spawnParticle(Particle.SNOWFLAKE,
                    entity.getLocation().add(0, 1, 0), 4, 0.3, 0.4, 0.3, 0.01);
            }, 0L, 1L);
        frozenTasks.put(uid, task.getTaskId());
    }

    private void unfreezeEntity(UUID uid) {
        frozenLocs.remove(uid);
        Integer taskId = frozenTasks.remove(uid);
        if (taskId != null) plugin.getServer().getScheduler().cancelTask(taskId);
        LivingEntity entity = null;
        for (var world : plugin.getServer().getWorlds()) {
            for (var e : world.getEntitiesByClass(LivingEntity.class)) {
                if (e.getUniqueId().equals(uid)) { entity = e; break; }
            }
            if (entity != null) break;
        }
        if (entity != null) {
            entity.removePotionEffect(PotionEffectType.SLOWNESS);
            entity.removePotionEffect(PotionEffectType.MINING_FATIGUE);
            entity.removePotionEffect(PotionEffectType.JUMP_BOOST);
        }
    }

    public void end(Player player) {
        cleanup(player);
        plugin.getAuraManager().stop(player.getUniqueId());
        plugin.getBossBarManager().remove(player.getUniqueId());
        PotionManager.actionBar(player, "§7Arctic Prison has ended.");
    }

    public void cleanup(Player player) {
        UUID uuid = player.getUniqueId();
        active.remove(uuid);
        hitCounters.remove(uuid);
    }

    public boolean isActive(UUID uuid) { return active.contains(uuid); }
}
