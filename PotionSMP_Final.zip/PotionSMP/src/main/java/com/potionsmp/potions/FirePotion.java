package com.potionsmp.potions;

import com.potionsmp.PotionSMP;
import com.potionsmp.managers.PotionManager;
import com.potionsmp.utils.PotionType;
import org.bukkit.*;
import org.bukkit.boss.BarColor;
import org.bukkit.entity.*;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

import java.util.*;

/**
 * 🔥 Fire Potion
 * Passive: Fire Resistance (infinite while equipped)
 * Every 10 hits: ignites target + nearby enemies
 * Active (Right Click): Inferno Rage — 10x10 fire aura, fire trail, 10s
 * Cooldown: 30s
 */
public class FirePotion {

    private final PotionSMP plugin;
    private final Set<UUID> active = new HashSet<>();
    private final Map<UUID, Integer> hitCounters = new HashMap<>();

    public FirePotion(PotionSMP plugin) { this.plugin = plugin; }

    // ── Passive: apply on equip ────────────────────────────────────────────────
    public void onEquip(Player player) {
        player.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE,
            Integer.MAX_VALUE, 0, false, false));
        PotionManager.actionBar(player, "§c🔥 Fire Resistance active.");
    }

    public void onUnequip(Player player) {
        player.removePotionEffect(PotionEffectType.FIRE_RESISTANCE);
        cleanup(player);
    }

    // ── Passive: hit counter ───────────────────────────────────────────────────
    public void onHit(Player attacker, LivingEntity target) {
        UUID uuid = attacker.getUniqueId();
        int hits = hitCounters.merge(uuid, 1, Integer::sum);

        // Subtle ember on each hit
        target.getWorld().spawnParticle(Particle.FLAME,
            target.getLocation().add(0, 1, 0), 2, 0.2, 0.2, 0.2, 0.01);

        if (hits >= 10) {
            hitCounters.put(uuid, 0);
            // Ignite target + nearby
            target.setFireTicks(100);
            for (Entity e : target.getWorld().getNearbyEntities(target.getLocation(), 3, 3, 3)) {
                if (e instanceof LivingEntity le && !e.getUniqueId().equals(uuid))
                    le.setFireTicks(80);
            }
            // Burst particles
            Location loc = target.getLocation().add(0, 1, 0);
            loc.getWorld().spawnParticle(Particle.FLAME, loc, 20, 0.5, 0.5, 0.5, 0.1);
            loc.getWorld().spawnParticle(Particle.LAVA, loc, 6, 0.3, 0.3, 0.3, 0);
            loc.getWorld().spawnParticle(Particle.SMALL_FLAME, loc, 10, 0.4, 0.4, 0.4, 0.05);
            loc.getWorld().playSound(loc, Sound.ENTITY_BLAZE_SHOOT, 1f, 0.8f);
            PotionManager.actionBar(attacker, "§c🔥 Passive ignition!");
        }
    }

    // ── Active ────────────────────────────────────────────────────────────────
    public void activate(Player player) {
        UUID uuid = player.getUniqueId();
        var cdm = plugin.getCooldownManager();

        if (cdm.isOnCooldown(uuid, PotionType.FIRE)) {
            plugin.getPotionManager().sendCooldown(player, PotionType.FIRE);
            return;
        }

        active.add(uuid);
        int dur   = plugin.getConfig().getInt("fire.duration", 10);
        int ticks = dur * 20;

        player.sendTitle("§c§l🔥 INFERNO RAGE", "§7The air burns around you.", 5, 40, 10);
        plugin.getBossBarManager().show(player, "§c🔥 Inferno Rage", BarColor.RED, dur);
        cdm.setCooldown(uuid, PotionType.FIRE, plugin.getConfig().getLong("fire.cooldown", 30));

        // Activation burst
        Location loc = player.getLocation().add(0, 1, 0);
        loc.getWorld().spawnParticle(Particle.FLAME, loc, 80, 2, 1, 2, 0.15);
        loc.getWorld().spawnParticle(Particle.LAVA, loc, 20, 1.5, 0.5, 1.5, 0.1);
        loc.getWorld().spawnParticle(Particle.SMALL_FLAME, loc, 50, 2, 0.5, 2, 0.08);
        loc.getWorld().playSound(loc.getLocation(), Sound.ENTITY_BLAZE_SHOOT, 1.5f, 0.6f);
        loc.getWorld().playSound(loc.getLocation(), Sound.ENTITY_GHAST_SHOOT, 0.8f, 1.2f);

        startFireAura(player, ticks);
        plugin.getTaskManager().later(uuid, () -> end(player), ticks);
    }

    private void startFireAura(Player player, int durationTicks) {
        UUID uuid = player.getUniqueId();
        int radius = 5; // 10x10 = radius 5
        double dps = 2.0;
        int[] ticks = {0};
        double[] angle = {0};

        plugin.getAuraManager().start(uuid, () -> {
            if (!active.contains(uuid) || !player.isOnline()) return;
            Location center = player.getLocation().add(0, 1, 0);

            // 3 spinning flame rings
            for (int layer = 0; layer < 3; layer++) {
                double r = radius * (0.6 + layer * 0.2);
                double layerAngle = angle[0] + (layer * 30);
                int points = 16 + (layer * 4);
                for (int i = 0; i < points; i++) {
                    double a = Math.toRadians((360.0 / points * i) + layerAngle);
                    center.getWorld().spawnParticle(Particle.FLAME,
                        center.getX() + Math.cos(a) * r,
                        center.getY() + (layer * 0.3),
                        center.getZ() + Math.sin(a) * r,
                        1, 0, 0, 0, 0.01);
                    if (ticks[0] % 3 == 0)
                        center.getWorld().spawnParticle(Particle.LAVA,
                            center.getX() + Math.cos(a) * r,
                            center.getY(),
                            center.getZ() + Math.sin(a) * r,
                            1, 0.1, 0.1, 0.1, 0);
                }
            }

            // Fire trail under feet
            center.getWorld().spawnParticle(Particle.FLAME,
                center.getX(), center.getY() - 0.9, center.getZ(),
                3, 0.1, 0, 0.1, 0.02);
            center.getWorld().spawnParticle(Particle.SMALL_FLAME,
                center.getX(), center.getY() - 0.9, center.getZ(),
                2, 0.2, 0, 0.2, 0.02);

            // Damage tick every second
            if (ticks[0] % 20 == 0) {
                for (Entity e : center.getWorld().getNearbyEntities(center, radius, 2.5, radius)) {
                    if (e instanceof LivingEntity le && !e.getUniqueId().equals(uuid)) {
                        le.damage(dps, player);
                        le.setFireTicks(40);
                    }
                }
            }

            angle[0] += 8;
            ticks[0]++;
        }, 1L);
    }

    public void end(Player player) {
        cleanup(player);
        plugin.getAuraManager().stop(player.getUniqueId());
        plugin.getBossBarManager().remove(player.getUniqueId());
        PotionManager.actionBar(player, "§7Inferno Rage has ended.");
        player.getWorld().playSound(player.getLocation(), Sound.BLOCK_FIRE_EXTINGUISH, 1f, 1f);
    }

    public void cleanup(Player player) {
        UUID uuid = player.getUniqueId();
        active.remove(uuid);
        hitCounters.remove(uuid);
    }

    public boolean isActive(UUID uuid) { return active.contains(uuid); }
}
