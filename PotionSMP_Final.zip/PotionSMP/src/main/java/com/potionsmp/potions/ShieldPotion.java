package com.potionsmp.potions;

import com.potionsmp.PotionSMP;
import com.potionsmp.managers.PotionManager;
import com.potionsmp.utils.PotionType;
import org.bukkit.*;
import org.bukkit.boss.BarColor;
import org.bukkit.entity.*;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

import java.util.*;

public class ShieldPotion {

    private final PotionSMP plugin;
    private final Set<UUID> active = new HashSet<>();
    private final Map<UUID, Double> ringAngle = new HashMap<>();

    public ShieldPotion(PotionSMP plugin) { this.plugin = plugin; }

    // ── Activate ─────────────────────────────────────────────────────────────

    public void activate(Player player) {
        UUID uuid = player.getUniqueId();
        var cdm = plugin.getCooldownManager();

        if (cdm.isOnCooldown(uuid, PotionType.SHIELD)) {
            plugin.getPotionManager().sendCooldown(player, PotionType.SHIELD);
            return;
        }

        active.add(uuid);
        ringAngle.put(uuid, 0.0);
        int dur   = plugin.getConfig().getInt("shield.duration", 10);
        int ticks = dur * 20;

        // ── Notify ──
        player.sendTitle("§f§l✦ DIVINE BARRIER", "§7You are protected.", 5, 40, 10);
        player.getWorld().playSound(player.getLocation(), Sound.BLOCK_BEACON_POWER_SELECT, 1f, 1.2f);

        // ── Slight resistance ──
        player.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, ticks, 1, true, false));

        // ── Boss bar ──
        plugin.getBossBarManager().show(player, "§f✦ Divine Barrier", BarColor.WHITE, dur);

        // ── Aura ──
        startAura(player);

        // ── End ──
        plugin.getTaskManager().later(uuid, () -> end(player), ticks);
        cdm.setCooldown(uuid, PotionType.SHIELD, plugin.getConfig().getLong("shield.cooldown", 45));
    }

    // ── Aura ─────────────────────────────────────────────────────────────────

    private void startAura(Player player) {
        UUID uuid = player.getUniqueId();
        World world = player.getWorld();

        plugin.getAuraManager().start(uuid, () -> {
            if (!player.isOnline() || !active.contains(uuid)) return;
            Location loc = player.getLocation().add(0, 1, 0);

            double angle = ringAngle.getOrDefault(uuid, 0.0) + 0.2;
            ringAngle.put(uuid, angle);

            // 3 rotating energy rings
            for (int layer = 0; layer < 3; layer++) {
                double r     = 0.9 + layer * 0.35;
                double yOff  = (layer - 1) * 0.45;
                double shift = angle + (Math.PI * 2.0 / 3) * layer;
                int    pts   = 10 + layer * 4;

                for (int i = 0; i < pts; i++) {
                    double a = shift + (2 * Math.PI / pts) * i;
                    Location p = loc.clone().add(Math.cos(a) * r, yOff, Math.sin(a) * r);

                    if (i % 3 == 0) {
                        world.spawnParticle(Particle.END_ROD, p, 1, 0, 0, 0, 0);
                    } else {
                        world.spawnParticle(Particle.DUST, p, 1,
                                new Particle.DustOptions(Color.fromRGB(180, 220, 255), 0.8f));
                    }
                }
            }

            // Hexagonal grid sparks
            if (Math.random() < 0.45)
                world.spawnParticle(Particle.ELECTRIC_SPARK, loc, 4, 0.9, 0.9, 0.9, 0.03);

            // Glow inner aura
            world.spawnParticle(Particle.GLOW, loc, 2, 0.5, 0.8, 0.5, 0);

            // Electric hum
            if (Math.random() < 0.06)
                world.playSound(loc, Sound.BLOCK_BEACON_AMBIENT, 0.25f, 1.6f);

            // Deflect projectiles
            deflectProjectiles(player, uuid);

        }, 1L);
    }

    // ── Projectile Deflection ─────────────────────────────────────────────────

    private void deflectProjectiles(Player player, UUID uuid) {
        double radius = plugin.getConfig().getDouble("shield.projectile-radius", 2.5);
        Location center = player.getLocation().add(0, 1, 0);

        for (Entity e : player.getWorld().getNearbyEntities(center, radius, radius, radius)) {
            if (!(e instanceof Projectile proj)) continue;
            if (proj.getShooter() instanceof Player s && s.getUniqueId().equals(uuid)) continue;

            // Deflect away
            Vector away = proj.getLocation().toVector()
                    .subtract(center.toVector()).normalize().add(new Vector(0, 0.4, 0)).normalize();
            proj.setVelocity(away.multiply(0.9));

            spawnBlockEffect(player.getLocation().add(0, 1, 0), player.getWorld());
            player.getWorld().playSound(player.getLocation(), Sound.ITEM_SHIELD_BLOCK, 1f, 1.2f);
        }
    }

    // ── Melee Damage Reduction (EntityDamageListener) ────────────────────────

    public double reduceDamage(Player defender, double originalDamage) {
        if (!active.contains(defender.getUniqueId())) return originalDamage;
        double reduction = plugin.getConfig().getDouble("shield.melee-reduction", 0.50);
        spawnBlockEffect(defender.getLocation().add(0, 1, 0), defender.getWorld());
        defender.getWorld().playSound(defender.getLocation(), Sound.ITEM_SHIELD_BLOCK, 0.9f, 1.1f);
        return originalDamage * (1.0 - reduction);
    }

    public double knockbackMultiplier(UUID uuid) {
        if (!active.contains(uuid)) return 1.0;
        return 1.0 - plugin.getConfig().getDouble("shield.knockback-reduction", 0.60);
    }

    // ── Block Effect ──────────────────────────────────────────────────────────

    private void spawnBlockEffect(Location loc, World world) {
        world.spawnParticle(Particle.END_ROD,        loc, 18, 0.7, 0.7, 0.7, 0.12);
        world.spawnParticle(Particle.ELECTRIC_SPARK, loc, 22, 0.8, 0.8, 0.8, 0.08);
        world.spawnParticle(Particle.GLOW,           loc, 10, 0.5, 0.5, 0.5, 0);
        world.spawnParticle(Particle.DUST,           loc, 14,
                new Particle.DustOptions(Color.fromRGB(200, 230, 255), 1.4f));
    }

    // ── End / Cleanup ─────────────────────────────────────────────────────────

    public void end(Player player) {
        cleanup(player);
        plugin.getAuraManager().stop(player.getUniqueId());
        plugin.getBossBarManager().remove(player.getUniqueId());
        PotionManager.actionBar(player, "§7Divine Barrier has faded.");
        player.getWorld().playSound(player.getLocation(), Sound.BLOCK_BEACON_DEACTIVATE, 1f, 0.9f);
    }

    public void cleanup(Player player) {
        UUID uuid = player.getUniqueId();
        active.remove(uuid);
        ringAngle.remove(uuid);
        player.removePotionEffect(PotionEffectType.RESISTANCE);
    }

    public boolean isActive(UUID uuid) { return active.contains(uuid); }
}
