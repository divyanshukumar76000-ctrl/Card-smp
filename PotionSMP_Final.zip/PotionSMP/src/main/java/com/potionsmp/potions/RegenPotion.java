package com.potionsmp.potions;

import com.potionsmp.PotionSMP;
import com.potionsmp.managers.PotionManager;
import com.potionsmp.utils.PotionType;
import org.bukkit.*;
import org.bukkit.boss.BarColor;
import org.bukkit.entity.*;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

import java.util.*;

public class RegenPotion {

    private final PotionSMP plugin;
    private final Set<UUID> active      = new HashSet<>();
    private final Set<UUID> diving      = new HashSet<>();  // waiting for ground hit
    private final Map<UUID, Location> healZones = new HashMap<>();

    public RegenPotion(PotionSMP plugin) { this.plugin = plugin; }

    // ── Activate ─────────────────────────────────────────────────────────────

    public void activate(Player player) {
        UUID uuid = player.getUniqueId();
        var cdm = plugin.getCooldownManager();

        if (cdm.isOnCooldown(uuid, PotionType.REGEN)) {
            plugin.getPotionManager().sendCooldown(player, PotionType.REGEN);
            return;
        }

        active.add(uuid);
        int dur   = plugin.getConfig().getInt("regen.duration", 20);
        int ticks = dur * 20;

        // ── Notify ──
        player.sendTitle("§e§l❤ VITALITY SURGE", "§7Life surges through you.", 5, 40, 10);
        player.getWorld().playSound(player.getLocation(), Sound.ITEM_TOTEM_USE, 0.8f, 1.0f);
        player.getWorld().playSound(player.getLocation(), Sound.BLOCK_BEACON_AMBIENT, 0.5f, 1.3f);

        // ── Buffs ──
        player.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, ticks, 2, true, false));
        player.addPotionEffect(new PotionEffect(PotionEffectType.ABSORPTION,   ticks, 1, true, false));

        // ── Boss bar ──
        plugin.getBossBarManager().show(player, "§e❤ Vitality Surge", BarColor.YELLOW, dur);

        // ── Golden aura ──
        startAura(player);

        // ── Aerial dive detection ──
        startDiveDetection(player);

        // ── Heal pulse every 3s ──
        plugin.getTaskManager().repeat(uuid, () -> {
            if (!active.contains(uuid) || !player.isOnline()) return;
            player.getWorld().spawnParticle(Particle.HEART,
                    player.getLocation().add(0, 1.5, 0), 6, 0.5, 0.5, 0.5, 0.05);
            player.getWorld().playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.3f, 1.8f);
        }, 60L, 60L);

        // ── End ──
        plugin.getTaskManager().later(uuid, () -> end(player), ticks);
        cdm.setCooldown(uuid, PotionType.REGEN, plugin.getConfig().getLong("regen.cooldown", 45));
    }

    // ── Aura ─────────────────────────────────────────────────────────────────

    private void startAura(Player player) {
        UUID uuid = player.getUniqueId();
        World world = player.getWorld();
        double[] angle = {0.0};

        plugin.getAuraManager().start(uuid, () -> {
            if (!player.isOnline() || !active.contains(uuid)) return;
            Location loc = player.getLocation().add(0, 1, 0);
            angle[0] += 0.2;

            // Golden dust rings
            for (int layer = 0; layer < 2; layer++) {
                double r   = 0.7 + layer * 0.5;
                double yOff = layer * 0.5 - 0.2;
                double shift = angle[0] + Math.PI * layer;
                for (int i = 0; i < 8; i++) {
                    double a = shift + (2 * Math.PI / 8) * i;
                    Location p = loc.clone().add(Math.cos(a) * r, yOff, Math.sin(a) * r);
                    world.spawnParticle(Particle.DUST, p, 1,
                            new Particle.DustOptions(Color.fromRGB(255, 200, 50), 1.1f));
                }
            }

            // Floating hearts
            if (Math.random() < 0.25)
                world.spawnParticle(Particle.HEART, loc.clone().add((Math.random()-0.5)*1.5, Math.random(), (Math.random()-0.5)*1.5), 1, 0, 0, 0, 0);

            // Totem-style trail
            world.spawnParticle(Particle.TOTEM_OF_UNDYING, loc, 2, 0.4, 0.5, 0.4, 0.05);

            // Glow trail
            if (Math.random() < 0.35)
                world.spawnParticle(Particle.GLOW, loc, 2, 0.6, 0.6, 0.6, 0);

            // Soft ambient sound
            if (Math.random() < 0.05)
                world.playSound(loc, Sound.BLOCK_BEACON_AMBIENT, 0.2f, 1.1f);

        }, 2L);
    }

    // ── Aerial Dive Detection ─────────────────────────────────────────────────

    private void startDiveDetection(Player player) {
        UUID uuid = player.getUniqueId();
        double launchVel = plugin.getConfig().getDouble("regen.launch-velocity", 1.6);

        // Launch player upward on next jump (PlayerMoveListener detects landing)
        plugin.getTaskManager().repeat(uuid, () -> {
            if (!active.contains(uuid) || !player.isOnline()) return;
            // If player is in air and looking downward (pitch > 45) → start dive
            if (!player.isOnGround() && player.getLocation().getPitch() > 45 && !diving.contains(uuid)) {
                // Launch up first
                player.setVelocity(player.getVelocity().add(new Vector(0, launchVel, 0)));
                diving.add(uuid);
                PotionManager.actionBar(player, "§e§l⬇ DIVE INCOMING — look down to smash!");
                player.getWorld().playSound(player.getLocation(), Sound.ENTITY_FIREWORK_ROCKET_LAUNCH, 0.7f, 0.8f);
            }
        }, 10L, 5L);
    }

    // ── Dive Impact (called from PlayerMoveListener on ground hit) ────────────

    public void onGroundHit(Player player) {
        UUID uuid = player.getUniqueId();
        if (!diving.contains(uuid)) return;
        diving.remove(uuid);

        Location impact = player.getLocation();
        World world = player.getWorld();
        double dmg      = plugin.getConfig().getDouble("regen.dive-damage", 10.0);
        double radius   = plugin.getConfig().getDouble("regen.dive-radius", 5.0);
        double knockback= plugin.getConfig().getDouble("regen.dive-knockback", 2.0);

        // ── Visual explosion ──
        world.spawnParticle(Particle.EXPLOSION,       impact, 3,  0.5, 0.1, 0.5, 0);
        world.spawnParticle(Particle.DUST,            impact, 40,
                new Particle.DustOptions(Color.fromRGB(255, 180, 0), 2.5f));
        world.spawnParticle(Particle.TOTEM_OF_UNDYING,impact, 60, 1.0, 1.0, 1.0, 0.3);
        world.spawnParticle(Particle.HEART,           impact, 20, 2.0, 1.5, 2.0, 0.1);
        world.spawnParticle(Particle.GLOW,            impact, 20, 1.5, 1.5, 1.5, 0);

        world.playSound(impact, Sound.ENTITY_GENERIC_EXPLODE, 1f, 0.7f);
        world.playSound(impact, Sound.ITEM_TOTEM_USE, 0.8f, 0.6f);
        world.playSound(impact, Sound.BLOCK_BEACON_POWER_SELECT, 1f, 0.5f);

        // ── Damage + knockback enemies ──
        for (Entity e : world.getNearbyEntities(impact, radius, radius, radius)) {
            if (!(e instanceof LivingEntity living) || e instanceof ArmorStand) continue;
            if (e instanceof Player p && p.getUniqueId().equals(uuid)) continue;

            living.damage(dmg, player);
            living.setNoDamageTicks(0);

            Vector kb = living.getLocation().toVector()
                    .subtract(impact.toVector()).normalize()
                    .multiply(knockback).add(new Vector(0, 0.8, 0));
            living.setVelocity(kb);
        }

        // ── Healing zone ──
        healZones.put(uuid, impact.clone());
        int healDur = plugin.getConfig().getInt("regen.heal-zone-duration", 5);
        double healRadius = plugin.getConfig().getDouble("regen.heal-zone-radius", 5.0);
        int[] elapsed = {0};

        plugin.getTaskManager().repeat(uuid, () -> {
            elapsed[0]++;
            if (elapsed[0] > healDur * 20 / 10) { healZones.remove(uuid); return; }

            Location zone = healZones.get(uuid);
            if (zone == null) return;

            // Healing ring visuals
            for (int i = 0; i < 16; i++) {
                double a = (2 * Math.PI / 16) * i + elapsed[0] * 0.1;
                Location p = zone.clone().add(Math.cos(a) * healRadius, 0.1, Math.sin(a) * healRadius);
                world.spawnParticle(Particle.DUST, p, 1,
                        new Particle.DustOptions(Color.fromRGB(100, 255, 100), 1.2f));
            }
            world.spawnParticle(Particle.HEART, zone.clone().add(0, 0.5, 0), 3, healRadius*0.5, 0.5, healRadius*0.5, 0.02);

            // Apply regen to allies in zone
            for (Entity e : world.getNearbyEntities(zone, healRadius, healRadius, healRadius)) {
                if (!(e instanceof Player ally)) continue;
                ally.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 30, 1, true, false));
            }
        }, 0L, 10L);
    }

    // ── End / Cleanup ─────────────────────────────────────────────────────────

    public void end(Player player) {
        cleanup(player);
        plugin.getAuraManager().stop(player.getUniqueId());
        plugin.getBossBarManager().remove(player.getUniqueId());
        PotionManager.actionBar(player, "§7Vitality Surge has ended.");
        player.getWorld().playSound(player.getLocation(), Sound.BLOCK_BEACON_DEACTIVATE, 1f, 1f);
    }

    public void cleanup(Player player) {
        UUID uuid = player.getUniqueId();
        active.remove(uuid);
        diving.remove(uuid);
        healZones.remove(uuid);
        player.removePotionEffect(PotionEffectType.REGENERATION);
        player.removePotionEffect(PotionEffectType.ABSORPTION);
    }

    public boolean isActive(UUID uuid)  { return active.contains(uuid); }
    public boolean isDiving(UUID uuid)  { return diving.contains(uuid); }
}
