package com.potionsmp.listeners;

import com.potionsmp.PotionSMP;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;

public class PlayerQuitListener implements Listener {

    private final PotionSMP plugin;

    public PlayerQuitListener(PotionSMP plugin) { this.plugin = plugin; }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        plugin.getPotionManager().removePlayer(e.getPlayer().getUniqueId());
    }
}
