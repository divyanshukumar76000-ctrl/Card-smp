package com.potionsmp.listeners;

import com.potionsmp.PotionSMP;
import com.potionsmp.utils.AbilityState;
import com.potionsmp.utils.PotionType;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.entity.Player;
import org.bukkit.inventory.EquipmentSlot;

public class PlayerInteractListener implements Listener {

    private final PotionSMP plugin;
    public PlayerInteractListener(PotionSMP plugin) { this.plugin = plugin; }

    @EventHandler(priority = EventPriority.HIGH)
    public void onInteract(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;

        Player player = e.getPlayer();
        AbilityState state = plugin.getPotionManager().getState(player.getUniqueId());
        if (state == null || !state.hasPotion()) return;

        boolean sneaking   = player.isSneaking();
        Action  action     = e.getAction();
        boolean rightClick = action == Action.RIGHT_CLICK_AIR || action == Action.RIGHT_CLICK_BLOCK;
        boolean leftClick  = action == Action.LEFT_CLICK_AIR  || action == Action.LEFT_CLICK_BLOCK;

        PotionType equipped = state.getEquippedPotion();

        if (sneaking && rightClick && equipped == PotionType.AQUA) {
            e.setCancelled(true);
            plugin.getPotionManager().triggerShiftRight(player);
        } else if (sneaking && leftClick && equipped == PotionType.SHIELD) {
            e.setCancelled(true);
            plugin.getPotionManager().triggerShiftLeft(player);
        } else if (!sneaking && rightClick &&
            (equipped == PotionType.REGEN ||
             equipped == PotionType.FIRE  ||
             equipped == PotionType.FREEZE)) {
            e.setCancelled(true);
            plugin.getPotionManager().triggerRight(player);
        }
        // Glitch: triggered on hit (EntityDamageListener), not on click
    }
}
