package com.potionsmp.listeners;

import com.potionsmp.PotionSMP;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;

public class PlayerMoveListener implements Listener {

    private final PotionSMP plugin;

    public PlayerMoveListener(PotionSMP plugin) { this.plugin = plugin; }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onMove(PlayerMoveEvent e) {
        Player player = e.getPlayer();

        // Only check y change to reduce overhead
        if (e.getFrom().getY() == e.getTo().getY()) return;

        var regen = plugin.getPotionManager().getRegen();
        if (regen.isDiving(player.getUniqueId()) && player.isOnGround()) {
            regen.onGroundHit(player);
        }
    }
}
