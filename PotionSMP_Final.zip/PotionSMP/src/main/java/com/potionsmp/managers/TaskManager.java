package com.potionsmp.managers;

import com.potionsmp.PotionSMP;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;

public class TaskManager {

    private final PotionSMP plugin;
    private final Map<UUID, List<BukkitTask>> tasks = new HashMap<>();

    public TaskManager(PotionSMP plugin) { this.plugin = plugin; }

    public void track(UUID uuid, BukkitTask task) {
        tasks.computeIfAbsent(uuid, k -> new ArrayList<>()).add(task);
    }

    public void cancelPlayer(UUID uuid) {
        List<BukkitTask> list = tasks.remove(uuid);
        if (list != null) list.forEach(t -> { try { t.cancel(); } catch (Exception ignored) {} });
    }

    public void cancelAll() {
        tasks.forEach((u, list) -> list.forEach(t -> { try { t.cancel(); } catch (Exception ignored) {} }));
        tasks.clear();
    }

    public BukkitTask repeat(UUID uuid, Runnable r, long delay, long period) {
        BukkitTask t = plugin.getServer().getScheduler().runTaskTimer(plugin, r, delay, period);
        track(uuid, t);
        return t;
    }

    public BukkitTask later(UUID uuid, Runnable r, long delay) {
        BukkitTask t = plugin.getServer().getScheduler().runTaskLater(plugin, r, delay);
        track(uuid, t);
        return t;
    }
}
