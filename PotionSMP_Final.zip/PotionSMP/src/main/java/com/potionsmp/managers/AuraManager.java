package com.potionsmp.managers;

import com.potionsmp.PotionSMP;
import org.bukkit.scheduler.BukkitTask;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class AuraManager {

    private final PotionSMP plugin;
    private final Map<UUID, BukkitTask> auras = new HashMap<>();

    public AuraManager(PotionSMP plugin) { this.plugin = plugin; }

    public void start(UUID uuid, Runnable r, long periodTicks) {
        stop(uuid);
        BukkitTask t = plugin.getServer().getScheduler().runTaskTimer(plugin, r, 0L, periodTicks);
        auras.put(uuid, t);
    }

    public void stop(UUID uuid) {
        BukkitTask old = auras.remove(uuid);
        if (old != null) { try { old.cancel(); } catch (Exception ignored) {} }
    }

    public void stopAll() {
        auras.forEach((u, t) -> { try { t.cancel(); } catch (Exception ignored) {} });
        auras.clear();
    }
}
