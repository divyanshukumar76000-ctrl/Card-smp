package com.potionsmp.managers;

import com.potionsmp.PotionSMP;
import com.potionsmp.utils.AbilityState;
import com.potionsmp.utils.PotionType;
import net.kyori.adventure.key.Key;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.Style;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.EnumMap;
import java.util.Map;

/**
 * ActionBar HUD using PotionSMP resource pack font (minecraft:potionsmp).
 * Shows potion icon + cooldown/ready status above XP bar.
 *
 * Font chars (from assets/minecraft/font/potionsmp.json):
 *   \uE000 = empty_slot
 *   \uE001 = aqua_potion
 *   \uE002 = glitch_potion
 *   \uE003 = warrior_potion
 *   \uE004 = freeze_potion
 *   \uE005 = ender_potion
 *   \uE006 = fire_potion
 *   \uE007 = teleport_potion
 *   \uE008 = regen_potion
 *   \uE010 = -4px  \uE011 = -8px  \uE012 = -16px  \uE013 = -18px
 *   \uE014 = +4px  \uE015 = +2px
 *
 * Shield has no icon in the pack — uses \uE000 (empty_slot) as fallback.
 */
public class HudManager {

    private static final Key FONT = Key.key("minecraft", "potionsmp");

    // Space chars
    private static final String NEG_16 = "\uE012";  // -16px
    private static final String POS_2  = "\uE015";  //  +2px

    private record IconInfo(String ch, NamedTextColor color) {}

    private static final Map<PotionType, IconInfo> ICONS = new EnumMap<>(PotionType.class);
    static {
        ICONS.put(PotionType.AQUA,   new IconInfo("\uE001", NamedTextColor.AQUA));
        ICONS.put(PotionType.GLITCH, new IconInfo("\uE002", NamedTextColor.LIGHT_PURPLE));
        ICONS.put(PotionType.FREEZE, new IconInfo("\uE004", NamedTextColor.AQUA));
        ICONS.put(PotionType.ENDER,  new IconInfo("\uE005", NamedTextColor.DARK_PURPLE));
        ICONS.put(PotionType.FIRE,   new IconInfo("\uE006", NamedTextColor.RED));
        ICONS.put(PotionType.REGEN,  new IconInfo("\uE008", NamedTextColor.GREEN));
        ICONS.put(PotionType.SHIELD, new IconInfo("\uE000", NamedTextColor.WHITE)); // fallback
    }

    private final PotionSMP plugin;
    private BukkitTask task;

    public HudManager(PotionSMP plugin) { this.plugin = plugin; }

    public void start() {
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 0L, 10L);
    }

    public void stop() { if (task != null) task.cancel(); }

    private void tick() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            AbilityState state = plugin.getPotionManager().getState(player.getUniqueId());
            if (state == null || !state.hasPotion()) continue;

            PotionType type = state.getEquippedPotion();
            IconInfo info = ICONS.getOrDefault(type, new IconInfo("\uE000", NamedTextColor.WHITE));

            boolean onCD = plugin.getCooldownManager().isOnCooldown(player.getUniqueId(), type);
            long rem = plugin.getCooldownManager().remainingSeconds(player.getUniqueId(), type);

            // Slot bg + icon overlay using negative space
            Component slot = Component.text("\uE000" + NEG_16 + info.ch() + POS_2)
                .style(Style.style().font(FONT).build())
                .color(info.color());

            Component status = onCD
                ? Component.text(" " + rem + "s", NamedTextColor.YELLOW)
                : Component.text(" Ready", NamedTextColor.GREEN);

            player.sendActionBar(Component.text().append(slot).append(status).build());
        }
    }
}
