package com.potionsmp.managers;

import com.potionsmp.PotionSMP;
import com.potionsmp.potions.*;
import com.potionsmp.utils.AbilityState;
import com.potionsmp.utils.PotionType;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.*;

public class PotionManager {

    public static final NamespacedKey POTION_KEY =
        new NamespacedKey(PotionSMP.getInstance(), "potionsmp_type");

    private final PotionSMP plugin;
    private final Map<UUID, AbilityState> states = new HashMap<>();

    private final AquaPotion   aqua;
    private final ShieldPotion shield;
    private final RegenPotion  regen;
    private final FirePotion   fire;
    private final FreezePotion freeze;
    private final GlitchPotion glitch;

    public PotionManager(PotionSMP plugin) {
        this.plugin = plugin;
        this.aqua   = new AquaPotion(plugin);
        this.shield = new ShieldPotion(plugin);
        this.regen  = new RegenPotion(plugin);
        this.fire   = new FirePotion(plugin);
        this.freeze = new FreezePotion(plugin);
        this.glitch = new GlitchPotion(plugin);
    }

    // ── GUI ───────────────────────────────────────────────────────────────────

    public void openGUI(Player player) {
        Inventory inv = plugin.getServer().createInventory(null, 9, "§bPotion SMP");

        inv.setItem(0, makeItem(Material.BLUE_DYE, "§b§lAqua Potion",
            List.of("§7Shift + Right Click", "§7■ Poseidon's Wrath  §eDur: §f15s  §eCD: §f240s"),
            PotionType.AQUA));
        inv.setItem(1, makeItem(Material.SHIELD, "§f§lShield Potion",
            List.of("§7Shift + Left Click", "§7■ Divine Barrier  §eDur: §f10s  §eCD: §f45s"),
            PotionType.SHIELD));
        inv.setItem(2, makeItem(Material.GOLDEN_APPLE, "§e§lRegen Potion",
            List.of("§7Right Click", "§7■ Vitality Surge  §eDur: §f20s  §eCD: §f45s"),
            PotionType.REGEN));
        inv.setItem(3, makeItem(Material.BLAZE_POWDER, "§c§lFire Potion",
            List.of("§7Right Click", "§7■ Inferno Rage  §eDur: §f10s  §eCD: §f30s",
                    "§7Passive: §fEvery 10 hits ignite enemies"),
            PotionType.FIRE));
        inv.setItem(4, makeItem(Material.BLUE_ICE, "§9§lFreeze Potion",
            List.of("§7Right Click", "§7■ Arctic Prison  §eDur: §f3s  §eCD: §f45s",
                    "§7Passive: §fEvery 10 hits stun target 1s"),
            PotionType.FREEZE));
        inv.setItem(5, makeItem(Material.ENDER_PEARL, "§d§lGlitch Potion",
            List.of("§7Hit enemy to activate", "§7■ System Corruption  §eDur: §f10s  §eCD: §f35s",
                    "§7Passive: §fMining Fatigue I (infinite)"),
            PotionType.GLITCH));

        // Remaining slots: filler
        ItemStack filler = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta fm = filler.getItemMeta();
        fm.setDisplayName("§8Coming soon...");
        filler.setItemMeta(fm);
        for (int i = 6; i < 9; i++) inv.setItem(i, filler);

        player.openInventory(inv);
    }

    private ItemStack makeItem(Material mat, String name, List<String> lore, PotionType type) {
        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(name);
        meta.setLore(lore);
        meta.getPersistentDataContainer().set(POTION_KEY, PersistentDataType.STRING, type.name());
        item.setItemMeta(meta);
        return item;
    }

    // ── GUI Click Handler ──────────────────────────────────────────────────────

    public void handleGUIClick(Player player, ItemStack clicked) {
        if (clicked == null || !clicked.hasItemMeta()) return;
        var pdc = clicked.getItemMeta().getPersistentDataContainer();
        if (!pdc.has(POTION_KEY, PersistentDataType.STRING)) return;

        PotionType type;
        try { type = PotionType.valueOf(pdc.get(POTION_KEY, PersistentDataType.STRING)); }
        catch (Exception e) { return; }

        UUID uuid = player.getUniqueId();
        AbilityState state = states.computeIfAbsent(uuid, u -> new AbilityState());

        if (type == state.getEquippedPotion()) unequip(player);
        else equip(player, type);
        player.closeInventory();
    }

    // ── Equip / Unequip ────────────────────────────────────────────────────────

    public void equip(Player player, PotionType type) {
        endAll(player);
        AbilityState state = states.computeIfAbsent(player.getUniqueId(), u -> new AbilityState());
        state.setEquippedPotion(type);

        // Apply passive effects on equip
        if (type == PotionType.FIRE)   fire.onEquip(player);
        if (type == PotionType.GLITCH) glitch.onEquip(player);

        actionBar(player, "§a✦ " + type.getDisplayName() + " §7equipped.");
        player.sendMessage(cfg("messages.prefix") + cfg("messages.equipped")
            .replace("{potion}", type.getDisplayName()));
    }

    public void unequip(Player player) {
        AbilityState state = states.get(player.getUniqueId());
        if (state != null && state.getEquippedPotion() != null) {
            PotionType type = state.getEquippedPotion();
            if (type == PotionType.FIRE)   fire.onUnequip(player);
            if (type == PotionType.GLITCH) glitch.onUnequip(player);
        }
        endAll(player);
        states.remove(player.getUniqueId());
        player.sendMessage(cfg("messages.prefix") + cfg("messages.unequipped"));
    }

    // ── Ability Triggers ───────────────────────────────────────────────────────

    /** Shift + Right Click → Aqua */
    public void triggerShiftRight(Player player) {
        AbilityState state = states.get(player.getUniqueId());
        if (state == null || !state.hasPotion()) { sendNoPotion(player); return; }
        if (state.getEquippedPotion() == PotionType.AQUA) aqua.activate(player);
        else actionBar(player, "§cShift + Right Click is only for Aqua Potion.");
    }

    /** Shift + Left Click → Shield */
    public void triggerShiftLeft(Player player) {
        AbilityState state = states.get(player.getUniqueId());
        if (state == null || !state.hasPotion()) { sendNoPotion(player); return; }
        if (state.getEquippedPotion() == PotionType.SHIELD) shield.activate(player);
        else actionBar(player, "§cShift + Left Click is only for Shield Potion.");
    }

    /** Right Click → Regen / Fire / Freeze */
    public void triggerRight(Player player) {
        AbilityState state = states.get(player.getUniqueId());
        if (state == null || !state.hasPotion()) { sendNoPotion(player); return; }
        switch (state.getEquippedPotion()) {
            case REGEN  -> regen.activate(player);
            case FIRE   -> fire.activate(player);
            case FREEZE -> freeze.activate(player);
            default     -> actionBar(player, "§cRight Click ability not available for this potion.");
        }
    }

    /** Hit event → passive hit counters + Glitch deploy */
    public void onHit(Player attacker, LivingEntity target) {
        AbilityState state = states.get(attacker.getUniqueId());
        if (state == null || !state.hasPotion()) return;
        switch (state.getEquippedPotion()) {
            case FIRE   -> fire.onHit(attacker, target);
            case FREEZE -> freeze.onHit(attacker, target);
            case GLITCH -> { if (target instanceof Player t) glitch.activate(attacker, t); }
            default     -> {}
        }
    }

    // ── Cleanup ────────────────────────────────────────────────────────────────

    public void endAll(Player player) {
        plugin.getTaskManager().cancelPlayer(player.getUniqueId());
        plugin.getAuraManager().stop(player.getUniqueId());
        plugin.getBossBarManager().remove(player.getUniqueId());
        aqua.cleanup(player);
        shield.cleanup(player);
        regen.cleanup(player);
        fire.cleanup(player);
        freeze.cleanup(player);
        glitch.cleanup(player);
        AbilityState state = states.get(player.getUniqueId());
        if (state != null) state.setAbilityActive(false);
    }

    public void removePlayer(UUID uuid) {
        Player p = plugin.getServer().getPlayer(uuid);
        if (p != null) endAll(p);
        states.remove(uuid);
        plugin.getCooldownManager().clear(uuid);
    }

    // ── Helpers ────────────────────────────────────────────────────────────────

    private void sendNoPotion(Player player) {
        player.sendMessage(cfg("messages.prefix") + cfg("messages.no-potion"));
    }

    public static void actionBar(Player player, String msg) {
        player.sendActionBar(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
            .legacySection().deserialize(msg));
    }

    public void sendCooldown(Player player, PotionType type) {
        long sec = plugin.getCooldownManager().remainingSeconds(player.getUniqueId(), type);
        String msg = cfg("messages.on-cooldown")
            .replace("{ability}", type.getDisplayName())
            .replace("{time}", String.valueOf(sec));
        player.sendMessage(cfg("messages.prefix") + msg);
        actionBar(player, msg);
    }

    private String cfg(String path) { return plugin.getConfig().getString(path, ""); }

    // ── Getters ────────────────────────────────────────────────────────────────

    public AbilityState getState(UUID uuid) { return states.get(uuid); }
    public AquaPotion   getAqua()   { return aqua; }
    public ShieldPotion getShield() { return shield; }
    public RegenPotion  getRegen()  { return regen; }
    public FirePotion   getFire()   { return fire; }
    public FreezePotion getFreeze() { return freeze; }
    public GlitchPotion getGlitch() { return glitch; }
}
