package com.potionsmp.managers;

import com.potionsmp.utils.PotionType;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class CooldownManager {

    // key = UUID + ":" + ability   value = expiry ms
    private final Map<String, Long> cooldowns = new HashMap<>();

    private String key(UUID uuid, PotionType type) {
        return uuid + ":" + type.name();
    }

    public boolean isOnCooldown(UUID uuid, PotionType type) {
        Long exp = cooldowns.get(key(uuid, type));
        if (exp == null) return false;
        if (System.currentTimeMillis() >= exp) { cooldowns.remove(key(uuid, type)); return false; }
        return true;
    }

    public long remainingSeconds(UUID uuid, PotionType type) {
        Long exp = cooldowns.get(key(uuid, type));
        if (exp == null) return 0;
        return Math.max(0, (exp - System.currentTimeMillis()) / 1000L);
    }

    public void setCooldown(UUID uuid, PotionType type, long seconds) {
        cooldowns.put(key(uuid, type), System.currentTimeMillis() + seconds * 1000L);
    }

    public void clear(UUID uuid) {
        cooldowns.keySet().removeIf(k -> k.startsWith(uuid.toString()));
    }
}
