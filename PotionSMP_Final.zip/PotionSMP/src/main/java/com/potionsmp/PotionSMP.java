package com.potionsmp;

import com.potionsmp.listeners.*;
import com.potionsmp.managers.*;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

public final class PotionSMP extends JavaPlugin {

    private static PotionSMP instance;

    private CooldownManager cooldownManager;
    private TaskManager     taskManager;
    private AuraManager     auraManager;
    private BossBarManager  bossBarManager;
    private PotionManager   potionManager;
    private HudManager      hudManager;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();

        cooldownManager = new CooldownManager();
        taskManager     = new TaskManager(this);
        auraManager     = new AuraManager(this);
        bossBarManager  = new BossBarManager(this);
        potionManager   = new PotionManager(this);
        hudManager      = new HudManager(this);

        var pm = getServer().getPluginManager();
        pm.registerEvents(new GUIListener(this),            this);
        pm.registerEvents(new PlayerInteractListener(this), this);
        pm.registerEvents(new EntityDamageListener(this),   this);
        pm.registerEvents(new PlayerMoveListener(this),     this);
        pm.registerEvents(new ProjectileListener(this),     this);
        pm.registerEvents(new PlayerQuitListener(this),     this);

        getCommand("potionsmp").setExecutor(new CommandExecutor() {
            @Override
            public boolean onCommand(CommandSender s, Command c, String l, String[] a) {
                if (!(s instanceof Player p)) { s.sendMessage("§cPlayers only."); return true; }
                potionManager.openGUI(p);
                return true;
            }
        });

        hudManager.start();
        getLogger().info("PotionSMP enabled! Fire, Freeze, Glitch, Shield, Regen, Aqua ready.");
    }

    @Override
    public void onDisable() {
        hudManager.stop();
        taskManager.cancelAll();
        auraManager.stopAll();
        bossBarManager.removeAll();
        getLogger().info("PotionSMP disabled.");
    }

    public static PotionSMP getInstance()       { return instance; }
    public CooldownManager getCooldownManager() { return cooldownManager; }
    public TaskManager     getTaskManager()     { return taskManager; }
    public AuraManager     getAuraManager()     { return auraManager; }
    public BossBarManager  getBossBarManager()  { return bossBarManager; }
    public PotionManager   getPotionManager()   { return potionManager; }
    public HudManager      getHudManager()      { return hudManager; }
}
