package com.potionsmp.utils;

public class AbilityState {

    private PotionType equippedPotion = null;
    private boolean abilityActive = false;
    private long abilityEndTime = 0;

    public PotionType getEquippedPotion() { return equippedPotion; }
    public void setEquippedPotion(PotionType type) { this.equippedPotion = type; }

    public boolean isAbilityActive() { return abilityActive; }
    public void setAbilityActive(boolean v) { this.abilityActive = v; }

    public long getAbilityEndTime() { return abilityEndTime; }
    public void setAbilityEndTime(long t) { this.abilityEndTime = t; }

    public boolean hasPotion() { return equippedPotion != null; }
}
