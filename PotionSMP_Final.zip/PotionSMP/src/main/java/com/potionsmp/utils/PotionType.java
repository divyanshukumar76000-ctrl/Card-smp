package com.potionsmp.utils;

public enum PotionType {
    AQUA("§b§lAqua Potion"),
    SHIELD("§f§lShield Potion"),
    REGEN("§e§lRegen Potion"),
    FIRE("§c§lFire Potion"),
    FREEZE("§9§lFreeze Potion"),
    GLITCH("§d§lGlitch Potion");

    private final String displayName;

    PotionType(String displayName) { this.displayName = displayName; }
    public String getDisplayName() { return displayName; }
}
