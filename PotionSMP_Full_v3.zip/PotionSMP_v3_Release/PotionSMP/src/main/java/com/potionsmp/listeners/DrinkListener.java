package com.potionsmp.listeners;

import com.potionsmp.PotionSMP;
import com.potionsmp.managers.PlayerPotionManager;
import com.potionsmp.utils.PotionUtils;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerItemConsumeEvent;

public class DrinkListener implements Listener {

    private final PotionSMP plugin;

    public DrinkListener(PotionSMP plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onConsume(PlayerItemConsumeEvent event) {
        String type = PotionUtils.getPotionType(event.getItem());
        if (type == null) return; // not a PotionSMP potion, ignore

        Player player = event.getPlayer();

        // Set this as the player's active potion (overrides previous one, if any)
        plugin.getPlayerPotionManager().setActive(player.getUniqueId(), type);

        // Reset hit counters & cooldowns for a clean start on the new potion
        if (PotionUtils.FIRE.equals(type)) {
            plugin.getHitCounterManager().resetFire(player.getUniqueId());
            player.sendMessage(PotionUtils.msg("drank-fire"));
        } else if (PotionUtils.FREEZE.equals(type)) {
            plugin.getHitCounterManager().resetFreeze(player.getUniqueId());
            player.sendMessage(PotionUtils.msg("drank-freeze"));
        }
    }
}
