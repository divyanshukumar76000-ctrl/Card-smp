package com.potionsmp.utils;

import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.potion.PotionType;

import java.util.List;

public class ItemBuilder {

    /**
     * Builds a real, drinkable potion item.
     * Fire potion is based on vanilla Fire Resistance (so it looks orange/fire-themed in inventory).
     * Freeze potion is based on vanilla Swiftness/Speed (so it looks distinct, blue-ish/fast themed).
     * Both are tagged via PersistentDataContainer so the plugin can identify them regardless of
     * resource pack state.
     */
    public static ItemStack buildPotion(String type) {
        ItemStack item = new ItemStack(Material.POTION);
        PotionMeta meta = (PotionMeta) item.getItemMeta();

        if (type.equals(PotionUtils.FIRE)) {
            meta.setBasePotionType(PotionType.FIRE_RESISTANCE);
            meta.setCustomModelData(PotionUtils.getFireModelData());
            meta.setDisplayName(PotionUtils.colorize("&c&l🔥 Fire Potion"));
            meta.setLore(List.of(
                PotionUtils.colorize("&7Passive: &fEvery 10 hits ignites enemies"),
                PotionUtils.colorize("&7Active: &c&lInferno Rage"),
                PotionUtils.colorize("&f  5x5 fire aura + fire trail"),
                PotionUtils.colorize("&f  +Fire Resistance for 10s"),
                PotionUtils.colorize("&eDuration: &f10s &7| &eCooldown: &f30s"),
                PotionUtils.colorize(""),
                PotionUtils.colorize("&eDrink to activate fire abilities!"),
                PotionUtils.colorize("&eThen right-click to use &cInferno Rage&e!")
            ));
        } else {
            meta.setBasePotionType(PotionType.SWIFTNESS);
            meta.setCustomModelData(PotionUtils.getFreezeModelData());
            meta.setDisplayName(PotionUtils.colorize("&b&l❄ Freeze Potion"));
            meta.setLore(List.of(
                PotionUtils.colorize("&7Passive: &fEvery 10 hits freezes target (1 heart dmg)"),
                PotionUtils.colorize("&7Active: &b&lArctic Prison"),
                PotionUtils.colorize("&f  10-block freeze blast"),
                PotionUtils.colorize("&f  Slowness + Mining Fatigue"),
                PotionUtils.colorize("&eDuration: &f3s &7| &eCooldown: &f45s"),
                PotionUtils.colorize(""),
                PotionUtils.colorize("&eDrink to activate freeze abilities!"),
                PotionUtils.colorize("&eThen right-click to use &bArctic Prison&e!")
            ));
        }

        PotionUtils.tagPotion(meta, type);
        item.setItemMeta(meta);
        return item;
    }
}
