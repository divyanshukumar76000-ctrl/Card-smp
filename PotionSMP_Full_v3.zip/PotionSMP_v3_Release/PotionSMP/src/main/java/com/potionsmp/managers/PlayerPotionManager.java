package com.potionsmp.managers;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class PlayerPotionManager {

    public static final String NONE = "none";
    public static final String FIRE = "fire";
    public static final String FREEZE = "freeze";

    // uuid -> active potion type ("fire", "freeze", or absent = none)
    private final Map<UUID, String> activePotion = new HashMap<>();

    public void setActive(UUID uuid, String type) {
        activePotion.put(uuid, type);
    }

    public String getActive(UUID uuid) {
        return activePotion.getOrDefault(uuid, NONE);
    }

    public boolean hasActive(UUID uuid) {
        return activePotion.containsKey(uuid) && !NONE.equals(activePotion.get(uuid));
    }

    public boolean isFireActive(UUID uuid) {
        return FIRE.equals(getActive(uuid));
    }

    public boolean isFreezeActive(UUID uuid) {
        return FREEZE.equals(getActive(uuid));
    }

    public void clear(UUID uuid) {
        activePotion.remove(uuid);
    }
}
