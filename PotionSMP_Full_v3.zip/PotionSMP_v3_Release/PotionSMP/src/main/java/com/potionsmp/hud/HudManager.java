package com.potionsmp.hud;

import com.potionsmp.PotionSMP;
import com.potionsmp.managers.PlayerPotionManager;
import org.bukkit.Bukkit;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Shows a small HUD (BossBar) above the XP bar for each player who has an active
 * PotionSMP potion. Displays an icon + status:
 *  - "🔥 Fire Potion | Ready" when ability is available
 *  - "🔥 Inferno Rage | 23s" countdown when on cooldown
 * Disappears entirely if the player has no active potion.
 */
public class HudManager {

    private final PotionSMP plugin;
    private final Map<UUID, BossBar> bars = new HashMap<>();
    private BukkitTask task;

    public HudManager(PotionSMP plugin) {
        this.plugin = plugin;
    }

    public void start() {
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 0L, 5L); // updates every 1/4 sec
    }

    public void stop() {
        if (task != null) task.cancel();
        for (BossBar bar : bars.values()) bar.removeAll();
        bars.clear();
    }

    private void tick() {
        PlayerPotionManager ppm = plugin.getPlayerPotionManager();

        for (Player player : Bukkit.getOnlinePlayers()) {
            UUID uid = player.getUniqueId();
            String type = ppm.getActive(uid);

            if (PlayerPotionManager.NONE.equals(type)) {
                // No active potion — remove bar if present
                BossBar bar = bars.remove(uid);
                if (bar != null) bar.removePlayer(player);
                continue;
            }

            boolean onCooldown = plugin.getCooldownManager().isOnCooldown(uid, type);
            long remaining = plugin.getCooldownManager().getRemainingSeconds(uid, type);

            String title;
            BarColor color;
            double progress;

            if (PlayerPotionManager.FIRE.equals(type)) {
                color = BarColor.RED;
                if (onCooldown) {
                    int totalCd = plugin.getConfig().getInt("fire-potion.active-cooldown", 30);
                    title = "§c🔥 Inferno Rage §7| §e" + remaining + "s";
                    progress = clamp(1.0 - ((double) remaining / totalCd));
                } else {
                    title = "§c🔥 Fire Potion §7| §aReady (Right-Click)";
                    progress = 1.0;
                }
            } else {
                color = BarColor.BLUE;
                if (onCooldown) {
                    int totalCd = plugin.getConfig().getInt("freeze-potion.active-cooldown", 45);
                    title = "§b❄ Arctic Prison §7| §e" + remaining + "s";
                    progress = clamp(1.0 - ((double) remaining / totalCd));
                } else {
                    title = "§b❄ Freeze Potion §7| §aReady (Right-Click)";
                    progress = 1.0;
                }
            }

            BossBar bar = bars.get(uid);
            if (bar == null) {
                bar = Bukkit.createBossBar(title, color, BarStyle.SOLID);
                bar.addPlayer(player);
                bars.put(uid, bar);
            } else {
                bar.setTitle(title);
                bar.setColor(color);
            }
            bar.setProgress(progress);
        }

        // Clean up bars for players who went offline
        bars.keySet().removeIf(uid -> Bukkit.getPlayer(uid) == null);
    }

    private double clamp(double val) {
        if (val < 0) return 0;
        if (val > 1) return 1;
        return val;
    }

    public void removeBar(UUID uid) {
        BossBar bar = bars.remove(uid);
        if (bar != null) bar.removeAll();
    }
}
