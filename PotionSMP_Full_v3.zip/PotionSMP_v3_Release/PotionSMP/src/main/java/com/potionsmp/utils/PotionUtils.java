package com.potionsmp.utils;

import com.potionsmp.PotionSMP;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

public class PotionUtils {

    public static final String FIRE = "fire";
    public static final String FREEZE = "freeze";
    public static final String NONE = "none";

    private static NamespacedKey key() {
        return new NamespacedKey(PotionSMP.getInstance(), "potionsmp_type");
    }

    public static int getFireModelData() {
        return PotionSMP.getInstance().getConfig().getInt("fire-potion.custom-model-data", 101);
    }

    public static int getFreezeModelData() {
        return PotionSMP.getInstance().getConfig().getInt("freeze-potion.custom-model-data", 102);
    }

    /**
     * Returns "fire", "freeze", or null if this item is not a PotionSMP potion
     */
    public static String getPotionType(ItemStack item) {
        if (item == null || item.getType() != Material.POTION) return null;
        if (!item.hasItemMeta()) return null;
        ItemMeta meta = item.getItemMeta();
        if (!meta.getPersistentDataContainer().has(key(), PersistentDataType.STRING)) return null;
        return meta.getPersistentDataContainer().get(key(), PersistentDataType.STRING);
    }

    public static void tagPotion(ItemMeta meta, String type) {
        meta.getPersistentDataContainer().set(key(), PersistentDataType.STRING, type);
    }

    public static boolean isFirePotion(ItemStack item) {
        return FIRE.equals(getPotionType(item));
    }

    public static boolean isFreezePotion(ItemStack item) {
        return FREEZE.equals(getPotionType(item));
    }

    public static String msg(String key) {
        String raw = PotionSMP.getInstance().getConfig().getString("messages." + key, "&cMissing message: " + key);
        return colorize(raw);
    }

    public static String colorize(String s) {
        return s.replace("&", "\u00a7");
    }
}
