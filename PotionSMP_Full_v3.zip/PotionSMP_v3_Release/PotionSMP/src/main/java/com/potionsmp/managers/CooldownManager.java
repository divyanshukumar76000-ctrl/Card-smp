package com.potionsmp.managers;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class CooldownManager {

    // key = uuid + ":" + potionType
    private final Map<String, Long> cooldowns = new HashMap<>();

    public boolean isOnCooldown(UUID uuid, String type) {
        String key = uuid + ":" + type;
        if (!cooldowns.containsKey(key)) return false;
        return System.currentTimeMillis() < cooldowns.get(key);
    }

    public long getRemainingSeconds(UUID uuid, String type) {
        String key = uuid + ":" + type;
        if (!cooldowns.containsKey(key)) return 0;
        long remaining = cooldowns.get(key) - System.currentTimeMillis();
        return remaining > 0 ? (remaining / 1000) + 1 : 0;
    }

    public void setCooldown(UUID uuid, String type, int seconds) {
        cooldowns.put(uuid + ":" + type, System.currentTimeMillis() + (seconds * 1000L));
    }

    public void clearCooldown(UUID uuid, String type) {
        cooldowns.remove(uuid + ":" + type);
    }
}
