package com.potionsmp;

import com.potionsmp.commands.PotionCommand;
import com.potionsmp.hud.HudManager;
import com.potionsmp.listeners.DrinkListener;
import com.potionsmp.listeners.FirePotionListener;
import com.potionsmp.listeners.FreezePotionListener;
import com.potionsmp.listeners.GUIListener;
import com.potionsmp.managers.CooldownManager;
import com.potionsmp.managers.HitCounterManager;
import com.potionsmp.managers.FrozenPlayerManager;
import com.potionsmp.managers.FireAuraManager;
import com.potionsmp.managers.PlayerPotionManager;
import org.bukkit.plugin.java.JavaPlugin;

public class PotionSMP extends JavaPlugin {

    private static PotionSMP instance;
    private CooldownManager cooldownManager;
    private HitCounterManager hitCounterManager;
    private FrozenPlayerManager frozenPlayerManager;
    private FireAuraManager fireAuraManager;
    private PlayerPotionManager playerPotionManager;
    private HudManager hudManager;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();

        // Init managers
        cooldownManager = new CooldownManager();
        hitCounterManager = new HitCounterManager();
        frozenPlayerManager = new FrozenPlayerManager(this);
        fireAuraManager = new FireAuraManager(this);
        playerPotionManager = new PlayerPotionManager();
        hudManager = new HudManager(this);

        // Register listeners
        getServer().getPluginManager().registerEvents(new DrinkListener(this), this);
        getServer().getPluginManager().registerEvents(new FreezePotionListener(this), this);
        getServer().getPluginManager().registerEvents(new FirePotionListener(this), this);
        getServer().getPluginManager().registerEvents(new GUIListener(this), this);

        // Register command
        PotionCommand cmd = new PotionCommand(this);
        getCommand("potionsmp").setExecutor(cmd);
        getCommand("potionsmp").setTabCompleter(cmd);

        // Start HUD update loop
        hudManager.start();

        getLogger().info("PotionSMP v2 enabled! Fire & Freeze abilities ready.");
    }

    @Override
    public void onDisable() {
        frozenPlayerManager.unfreezeAll();
        fireAuraManager.cancelAll();
        hudManager.stop();
        getLogger().info("PotionSMP disabled.");
    }

    public static PotionSMP getInstance() { return instance; }
    public CooldownManager getCooldownManager() { return cooldownManager; }
    public HitCounterManager getHitCounterManager() { return hitCounterManager; }
    public FrozenPlayerManager getFrozenPlayerManager() { return frozenPlayerManager; }
    public FireAuraManager getFireAuraManager() { return fireAuraManager; }
    public PlayerPotionManager getPlayerPotionManager() { return playerPotionManager; }
    public HudManager getHudManager() { return hudManager; }
}
