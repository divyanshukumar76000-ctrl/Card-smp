package com.potionsmp.managers;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class HitCounterManager {

    private final Map<UUID, Integer> fireHits = new HashMap<>();
    private final Map<UUID, Integer> freezeHits = new HashMap<>();

    public int incrementFire(UUID uuid) {
        int val = fireHits.getOrDefault(uuid, 0) + 1;
        fireHits.put(uuid, val);
        return val;
    }

    public int incrementFreeze(UUID uuid) {
        int val = freezeHits.getOrDefault(uuid, 0) + 1;
        freezeHits.put(uuid, val);
        return val;
    }

    public void resetFire(UUID uuid) { fireHits.put(uuid, 0); }
    public void resetFreeze(UUID uuid) { freezeHits.put(uuid, 0); }
}
