# 🧪 PotionSMP Plugin v2

Fire 🔥 and Freeze ❄️ Potion ability system for PaperMC / Spigot 1.21.1 (Java 21).

## ✅ What changed in v2 (fixing the bugs from screenshots)

1. **No more identical GUI textures.** The GUI now hands out *real* vanilla potions
   (Fire Resistance base for Fire Potion, Swiftness/Speed base for Freeze Potion).
   They are visually distinct immediately, in inventory, hotbar, and GUI — no resource
   pack required for this part.
2. **No more ground fire spreading.** The Fire Potion's active ability ("Inferno Rage")
   no longer places any fire blocks. It's a pure aura: a ring of particles that follows
   the player, damaging and igniting any player/mob that stands inside the radius. Zero
   block changes, so no lag, no fire spread, no chunk damage.
3. **New HUD system.** A BossBar appears above the XP bar the moment a player drinks
   either potion. It shows:
   - `🔥 Fire Potion | Ready (Right-Click)` when the ability is available
   - `🔥 Inferno Rage | 23s` countdown while on cooldown
   - Same pattern for `❄ Freeze Potion` / `❄ Arctic Prison`
   The bar disappears completely if the player has no active potion.
4. **New activation flow**, matching what you described:
   - Player **drinks** the potion (it's consumed, like vanilla) → this sets their
     "active potion type" permanently until they drink the other one.
   - While a type is active: passive ability works automatically (every 10 hits).
   - Player **right-clicks empty air/block** (with empty hand or non-potion item) to
     fire the **active ability**, which then goes on cooldown.
   - Drinking the *other* potion overwrites the active type — old abilities turn off,
     new one turns on.

---

## 📦 Building the Plugin

```bash
cd PotionSMP
mvn clean package
```

Output: `target/PotionSMP.jar` → drop into `plugins/`.

---

## 🎮 Commands

| Command | Description |
|---|---|
| `/potionSMP` | Open potion GUI (pick Fire or Freeze) |
| `/potionSMP give fire [player]` | Give Fire Potion (op only) |
| `/potionSMP give freeze [player]` | Give Freeze Potion (op only) |

Aliases: `/psmp`, `/potion`

---

## 🔥 Fire Potion — Inferno Rage

| | |
|---|---|
| **Item look** | Vanilla Fire Resistance potion (orange-red bottle) |
| **Passive** | Every 10 hits: ignites target + nearby enemies (3-block radius) |
| **Active** | Right-click → 5×5 (radius 2) damage **aura** around you — no fire blocks, just particles + damage/ignite tick every second to anyone standing in it. Fire trail particles follow your movement. You get Fire Resistance for the duration. |
| **Duration** | 10 seconds |
| **Cooldown** | 30 seconds |

## ❄️ Freeze Potion — Arctic Prison

| | |
|---|---|
| **Item look** | Vanilla Swiftness/Speed potion |
| **Passive** | Every 10 hits: 1 extra heart damage + brief freeze (2s) on target |
| **Active** | Right-click → 10-block radius freeze blast. All enemies in range locked in place (can't move/attack/use abilities/throw pearls) for 3 seconds, with Slowness + Mining Fatigue. Ice particle aura. |
| **Duration** | 3 seconds freeze |
| **Cooldown** | 45 seconds |

---

## ⚙️ config.yml

All durations, radii, cooldowns, hit thresholds, and chat messages are configurable in
`plugins/PotionSMP/config.yml`.

---

## 🔗 About the Texture Pack

Potions are built on real vanilla potion types (Fire Resistance / Swiftness) **and** carry
`CustomModelData` (101 for Fire, 102 for Freeze). This means:

- **Without the resource pack**: items still look distinct (vanilla Fire Resistance vs
  Swiftness bottle colors) and function correctly — nothing breaks.
- **With the resource pack** (`PotionSMP_TexturePack.zip`, included separately): the bottles
  show your custom ice-crystal-shield (Freeze) and blue-flame-shield (Fire) icons instead.

Install the resource pack like any other: drop it in `resourcepacks/` (client) or host it
and set `resource-pack=` in `server.properties` (server-wide). Pack format is set to `34`
with `supported_formats` covering 1.20.2 through 1.21.x, so it should load correctly on
your 1.21.1 server.

---

## 📋 Permissions

| Permission | Default | Description |
|---|---|---|
| `potionsmp.use` | true (everyone) | Open GUI, use potions |
| `potionsmp.give` | op only | Give potions to players |
