package com.potionsmp.hud;

import com.potionsmp.PotionSMP;
import com.potionsmp.utils.PotionType;
import net.kyori.adventure.key.Key;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.Style;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.EnumMap;
import java.util.Map;

/**
 * HudManager — renders 2-slot HUD above XP bar via ActionBar.
 *
 * Font: minecraft:default  (assets/minecraft/font/default.json)
 * Namespace: potionsmp:    (assets/potionsmp/textures/icons/)
 *
 * Unicode map (matching default.json):
 *   \uE901 = empty slot background
 *   \uE001 = aqua     (normal)
 *   \uE201 = aqua     (dark — used when on cooldown)
 *   \uE002 = glitch
 *   \uE003 = warrior
 *   \uE004 = freeze
 *   \uE005 = ender
 *   \uE006 = fire
 *   \uE007 = teleport
 *   \uE008 = regen
 *   \uE904 = +2px space
 *   \uE905 = +6px space
 *
 * HUD layout (always shown to all online players):
 *   [SLOT1]  [SLOT2]
 *   Default empty: \uE901 \uE904 \uE901
 */
public class HudManager {

    // Font is minecraft:default — same as InfusePack
    private static final Key ICON_FONT = Key.key("minecraft", "default");

    // ── Slot background ───────────────────────────────────────────────────
    private static final String EMPTY = "\uE901";

    // ── Space chars ───────────────────────────────────────────────────────
    private static final String SP2  = "\uE904"; // +2px
    private static final String SP6  = "\uE905"; // +6px

    // ── Normal icon chars (col 0 of effects.png) ──────────────────────────
    private static final String ICON_AQUA     = "\uE001";
    private static final String ICON_GLITCH   = "\uE002";
    private static final String ICON_WARRIOR  = "\uE003";
    private static final String ICON_FREEZE   = "\uE004";
    private static final String ICON_ENDER    = "\uE005";
    private static final String ICON_FIRE     = "\uE006";
    private static final String ICON_TELEPORT = "\uE007";
    private static final String ICON_REGEN    = "\uE008";

    // ── Dark/cooldown icon chars (col 2 of effects.png) ───────────────────
    private static final String DARK_AQUA     = "\uE201";
    private static final String DARK_GLITCH   = "\uE202";
    private static final String DARK_WARRIOR  = "\uE203";
    private static final String DARK_FREEZE   = "\uE204";
    private static final String DARK_ENDER    = "\uE205";
    private static final String DARK_FIRE     = "\uE206";
    private static final String DARK_TELEPORT = "\uE207";
    private static final String DARK_REGEN    = "\uE208";

    // ── PotionType → (normal icon, dark icon) ─────────────────────────────
    private record IconPair(String normal, String dark) {}

    private static final Map<PotionType, IconPair> ICONS = new EnumMap<>(PotionType.class);
    static {
        ICONS.put(PotionType.FIRE,   new IconPair(ICON_FIRE,     DARK_FIRE));
        ICONS.put(PotionType.FREEZE, new IconPair(ICON_FREEZE,   DARK_FREEZE));
        ICONS.put(PotionType.REGEN,  new IconPair(ICON_REGEN,    DARK_REGEN));
        ICONS.put(PotionType.GLITCH, new IconPair(ICON_GLITCH,   DARK_GLITCH));
        ICONS.put(PotionType.SHIELD, new IconPair(ICON_WARRIOR,  DARK_WARRIOR));
        // Future:
        // ICONS.put(PotionType.AQUA,     new IconPair(ICON_AQUA,     DARK_AQUA));
        // ICONS.put(PotionType.ENDER,    new IconPair(ICON_ENDER,    DARK_ENDER));
        // ICONS.put(PotionType.TELEPORT, new IconPair(ICON_TELEPORT, DARK_TELEPORT));
    }

    private final PotionSMP plugin;
    private BukkitTask task;

    public HudManager(PotionSMP plugin) {
        this.plugin = plugin;
    }

    public void start() {
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 0L, 10L);
    }

    public void stop() {
        if (task != null) { task.cancel(); task = null; }
    }

    private void tick() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            player.sendActionBar(buildHUD(player));
        }
    }

    /**
     * Always renders 2 slots — empty or filled.
     * Layout: [Slot1] SP6 [Slot2]
     */
    private Component buildHUD(Player player) {
        PotionType slot1 = plugin.getSlotManager().getSlot1(player.getUniqueId());
        PotionType slot2 = plugin.getSlotManager().getSlot2(player.getUniqueId());

        Style font = Style.style().font(ICON_FONT).build();

        return Component.empty()
                .append(buildSlot(player, slot1, font))
                .append(Component.text(SP6).style(font))   // gap
                .append(buildSlot(player, slot2, font));
    }

    /**
     * Builds a single slot:
     * - null      → empty slot background (\uE901)
     * - equipped  → normal icon if ready, dark icon if on cooldown
     *               + yellow cooldown text suffix
     */
    private Component buildSlot(Player player, PotionType type, Style font) {
        if (type == null) {
            return Component.text(EMPTY).style(font);
        }

        IconPair icons = ICONS.getOrDefault(type,
            new IconPair(EMPTY, EMPTY));

        boolean onCooldown = plugin.getCooldownManager()
                .isOnCooldown(player.getUniqueId(), type);

        if (onCooldown) {
            long remaining = plugin.getCooldownManager()
                    .getRemainingSeconds(player.getUniqueId(), type);
            // Dark icon + cooldown seconds
            return Component.empty()
                    .append(Component.text(icons.dark()).style(font))
                    .append(Component.text(SP2).style(font))
                    .append(Component.text(remaining + "s", NamedTextColor.YELLOW));
        }

        // Normal icon, no text
        return Component.text(icons.normal()).style(font);
    }
}
