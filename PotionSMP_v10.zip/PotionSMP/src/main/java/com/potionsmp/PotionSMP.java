package com.potionsmp;

import com.potionsmp.abilities.AbilityRegistry;
import com.potionsmp.commands.PotionCommand;
import com.potionsmp.commands.SlotCommand;
import com.potionsmp.hud.HudManager;
import com.potionsmp.listeners.CombatListener;
import com.potionsmp.listeners.DrinkListener;
import com.potionsmp.listeners.GUIListener;
import com.potionsmp.listeners.JumpListener;
import com.potionsmp.managers.CooldownManager;
import com.potionsmp.managers.FireAuraManager;
import com.potionsmp.managers.FrozenPlayerManager;
import com.potionsmp.managers.HitCounterManager;
import com.potionsmp.managers.RegenAbilityManager;
import com.potionsmp.managers.ParticleManager;
import com.potionsmp.managers.GlitchManager;
import com.potionsmp.managers.ShieldManager;
import com.potionsmp.managers.SlotManager;
import org.bukkit.plugin.java.JavaPlugin;

public class PotionSMP extends JavaPlugin {

    private static PotionSMP instance;

    private CooldownManager cooldownManager;
    private HitCounterManager hitCounterManager;
    private FrozenPlayerManager frozenPlayerManager;
    private FireAuraManager fireAuraManager;
    private RegenAbilityManager regenAbilityManager;
    private ParticleManager particleManager;
    private GlitchManager glitchManager;
    private ShieldManager shieldManager;
    private SlotManager slotManager;
    private AbilityRegistry abilityRegistry;
    private HudManager hudManager;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();

        cooldownManager = new CooldownManager();
        hitCounterManager = new HitCounterManager();
        frozenPlayerManager = new FrozenPlayerManager(this);
        fireAuraManager = new FireAuraManager(this);
        regenAbilityManager = new RegenAbilityManager(this);
        particleManager = new ParticleManager(this);
        glitchManager = new GlitchManager(this);
        shieldManager = new ShieldManager(this);
        slotManager = new SlotManager();
        abilityRegistry = new AbilityRegistry();
        hudManager = new HudManager(this);

        getServer().getPluginManager().registerEvents(new DrinkListener(this), this);
        getServer().getPluginManager().registerEvents(new CombatListener(this), this);
        getServer().getPluginManager().registerEvents(new JumpListener(this), this);
        getServer().getPluginManager().registerEvents(new GUIListener(this), this);

        PotionCommand cmd = new PotionCommand(this);
        getCommand("potionsmp").setExecutor(cmd);
        getCommand("potionsmp").setTabCompleter(cmd);

        getCommand("slot1").setExecutor(new SlotCommand(this, SlotManager.SLOT_1));
        getCommand("slot2").setExecutor(new SlotCommand(this, SlotManager.SLOT_2));

        hudManager.start();

        getLogger().info("PotionSMP v3 enabled! Slot-based ability system ready (Fire, Freeze, Regen).");
    }

    @Override
    public void onDisable() {
        frozenPlayerManager.unfreezeAll();
        fireAuraManager.cancelAll();
        particleManager.cancelAll();
        glitchManager.cancelAll();
        shieldManager.cancelAll();
        hudManager.stop();
        getLogger().info("PotionSMP disabled.");
    }

    public static PotionSMP getInstance() { return instance; }
    public CooldownManager getCooldownManager() { return cooldownManager; }
    public HitCounterManager getHitCounterManager() { return hitCounterManager; }
    public FrozenPlayerManager getFrozenPlayerManager() { return frozenPlayerManager; }
    public FireAuraManager getFireAuraManager() { return fireAuraManager; }
    public RegenAbilityManager getRegenAbilityManager() { return regenAbilityManager; }
    public SlotManager getSlotManager() { return slotManager; }
    public AbilityRegistry getAbilityRegistry() { return abilityRegistry; }
    public HudManager getHudManager() { return hudManager; }
    public ParticleManager getParticleManager() { return particleManager; }
    public GlitchManager getGlitchManager() { return glitchManager; }
    public ShieldManager getShieldManager() { return shieldManager; }
}
