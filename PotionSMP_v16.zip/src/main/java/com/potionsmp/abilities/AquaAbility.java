package com.potionsmp.abilities;

import com.potionsmp.PotionSMP;
import com.potionsmp.utils.PotionType;
import com.potionsmp.utils.PotionUtils;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.UUID;

/**
 * 🌊 AQUA POTION — SUPREME ULTIMATE
 *
 * ── Passive 1: Ocean's Blessing ───────────────────────────────────────────
 * Refresh every 20 ticks:
 *   Water Breathing, Dolphin's Grace, Night Vision, Haste II
 *
 * ── Passive 2: Leviathan's Rage ───────────────────────────────────────────
 * Every 6 hits → massive water explosion + pull + true damage splash
 *
 * ── Active: Poseidon's Wrath ──────────────────────────────────────────────
 * Duration 15s | Cooldown 240s
 *   - Ocean Domain (15-block radius)
 *   - Divine Trident orbit + lock-on one-shot strike
 *   - Leviathan Judgment every 1.5s
 *   - Storm effects
 */
public class AquaAbility implements Ability {

    @Override
    public PotionType type() { return PotionType.AQUA; }

    // ── Equip ─────────────────────────────────────────────────────────────

    @Override
    public void onEquip(PotionSMP plugin, Player player) {
        startBlessingLoop(plugin, player);
        player.sendMessage(PotionUtils.colorize("&b🌊 Ocean's Blessing active."));
    }

    @Override
    public void onUnequip(PotionSMP plugin, Player player) {
        plugin.getParticleManager().cancelAura(player.getUniqueId());
        plugin.getAquaDomainManager().endDomain(player);
        removeBlessingEffects(player);
        plugin.getHitCounterManager().reset(player.getUniqueId(), type());
    }

    // ── Passive 1: Ocean's Blessing loop ─────────────────────────────────

    private void startBlessingLoop(PotionSMP plugin, Player player) {
        plugin.getParticleManager().cancelAura(player.getUniqueId());
        new BukkitRunnable() {
            @Override
            public void run() {
                if (!player.isOnline() ||
                    !plugin.getSlotManager().hasEquipped(player.getUniqueId(), PotionType.AQUA)) {
                    removeBlessingEffects(player);
                    cancel();
                    return;
                }
                applyBlessingEffects(player);
                spawnBlessingAura(player);
            }
        }.runTaskTimer(plugin, 0L, 20L);
    }

    private void applyBlessingEffects(Player player) {
        int dur = 30; // 30 ticks = 1.5s buffer (refreshed every 20t)
        player.addPotionEffect(new PotionEffect(PotionEffectType.WATER_BREATHING, dur, 0, false, false));
        player.addPotionEffect(new PotionEffect(PotionEffectType.DOLPHINS_GRACE,  dur, 0, false, false));
        player.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION,    dur + 200, 0, false, false));
        player.addPotionEffect(new PotionEffect(PotionEffectType.HASTE,           dur, 1, false, false));
    }

    private void removeBlessingEffects(Player player) {
        player.removePotionEffect(PotionEffectType.WATER_BREATHING);
        player.removePotionEffect(PotionEffectType.DOLPHINS_GRACE);
        player.removePotionEffect(PotionEffectType.NIGHT_VISION);
        player.removePotionEffect(PotionEffectType.HASTE);
    }

    private void spawnBlessingAura(Player player) {
        Location loc = player.getLocation().add(0, 1, 0);
        loc.getWorld().spawnParticle(Particle.BUBBLE_POP,    loc, 2, 0.4,0.5,0.4, 0.03);
        loc.getWorld().spawnParticle(Particle.DRIP_WATER,    loc, 2, 0.3,0.5,0.3, 0);
        if (Math.random() < 0.3)
            loc.getWorld().spawnParticle(Particle.NAUTILUS,  loc, 1, 0.4,0.4,0.4, 0.02);
    }

    // ── Passive 2: Leviathan's Rage (every 6 hits) ───────────────────────

    @Override
    public void onHit(PotionSMP plugin, Player player, LivingEntity target) {
        int count = plugin.getHitCounterManager().registerHit(
            player.getUniqueId(), type(),
            target.getUniqueId(),
            player.getWorld().getFullTime());

        if (count == -1) return;

        int threshold = plugin.getConfig().getInt("potions.aqua.rage-hits", 6);

        // Hit splash (mini water burst every hit)
        target.getWorld().spawnParticle(Particle.SPLASH,
            target.getLocation().add(0,1,0), 8, 0.3,0.3,0.3, 0.1);

        if (count >= threshold) {
            plugin.getHitCounterManager().reset(player.getUniqueId(), type());
            plugin.getAquaDomainManager().triggerLeviathanRage(player, target);
        }
    }

    // ── Active: Poseidon's Wrath ──────────────────────────────────────────

    @Override
    public ActivationResult activate(PotionSMP plugin, Player player) {
        UUID uid = player.getUniqueId();

        if (plugin.getCooldownManager().isOnCooldown(uid, type()))
            return ActivationResult.ON_COOLDOWN;

        // Block if inside Ender domain
        if (plugin.getEnderDomainManager().isSuppressed(uid)) {
            player.sendMessage(PotionUtils.colorize("&5☠ Your abilities are suppressed by the Abyss Domain!"));
            return ActivationResult.SUCCESS;
        }

        int cooldown = plugin.getConfig().getInt("potions.aqua.active-cooldown", 240);
        plugin.getCooldownManager().setCooldown(uid, type(), cooldown);

        plugin.getAquaDomainManager().startDomain(player);
        return ActivationResult.SUCCESS;
    }
}
