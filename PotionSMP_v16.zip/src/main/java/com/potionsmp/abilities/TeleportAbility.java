package com.potionsmp.abilities;

import com.potionsmp.PotionSMP;
import com.potionsmp.utils.PotionType;
import com.potionsmp.utils.PotionUtils;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.*;

/**
 * 🌀 TELEPORT POTION
 *
 * ── Passive: Infinite Invisibility ───────────────────────────────────────
 * Player is invisible while potion is equipped.
 * Faint shadow particles leak every 3 ticks so enemies can barely detect them.
 *
 * ── Active: Shadow Hunt ───────────────────────────────────────────────────
 * Usage: /slot1 or /slot2  →  then /hunt <playerName>
 *
 * Flow:
 *   1. Player activates → nearest online enemy auto-selected (or last looked-at)
 *   2. 5-second countdown with dark portal particles gathering around user
 *   3. Instant teleport to target (ignores walls)
 *   4. On arrival:
 *      - Nausea + Blindness I → target (3s)
 *      - Enderman teleport flash
 *      - Purple-black shockwave ring
 *      - Screen distortion (title flash) on target
 *   5. Ability ends immediately — no duration
 *
 * Cooldown: 90 seconds
 */
public class TeleportAbility implements Ability {

    @Override
    public PotionType type() { return PotionType.TELEPORT; }

    // Players currently in countdown phase
    private final Set<UUID> inCountdown = new HashSet<>();
    // Players who have activated and are awaiting target selection
    private final Map<UUID, String> pendingTarget = new HashMap<>();

    // ── Equip / Unequip ───────────────────────────────────────────────────

    @Override
    public void onEquip(PotionSMP plugin, Player player) {
        applyInvisibility(player);
        startShadowTrail(plugin, player);
        player.sendMessage(PotionUtils.colorize("&5🌀 Shadow Cloak active — you are invisible."));
    }

    @Override
    public void onUnequip(PotionSMP plugin, Player player) {
        player.removePotionEffect(PotionEffectType.INVISIBILITY);
        plugin.getParticleManager().cancelAura(player.getUniqueId());
        inCountdown.remove(player.getUniqueId());
        pendingTarget.remove(player.getUniqueId());
    }

    private void applyInvisibility(Player player) {
        player.addPotionEffect(new PotionEffect(
            PotionEffectType.INVISIBILITY, Integer.MAX_VALUE, 0, false, false));
    }

    // ── Shadow Trail Passive ──────────────────────────────────────────────

    private void startShadowTrail(PotionSMP plugin, Player player) {
        plugin.getParticleManager().cancelAura(player.getUniqueId());

        new BukkitRunnable() {
            final Random rand = new Random();
            double angle = 0;

            @Override
            public void run() {
                if (!player.isOnline() ||
                    !plugin.getSlotManager().hasEquipped(player.getUniqueId(), PotionType.TELEPORT)) {
                    cancel(); return;
                }

                // Ensure invisibility stays on
                if (!player.hasPotionEffect(PotionEffectType.INVISIBILITY)) {
                    applyInvisibility(player);
                }

                Location loc = player.getLocation().add(0, 0.1, 0);
                angle += 0.3;

                // Faint shadow — very few particles, hard to see
                if (rand.nextInt(3) == 0) {
                    double r = 0.4 + rand.nextDouble() * 0.3;
                    double a = angle;
                    loc.getWorld().spawnParticle(Particle.SQUID_INK,
                        loc.clone().add(Math.cos(a) * r, 0, Math.sin(a) * r),
                        1, 0, 0, 0, 0);
                }

                // Very rare purple wisp
                if (rand.nextInt(10) == 0) {
                    loc.getWorld().spawnParticle(Particle.DUST,
                        loc.clone().add((rand.nextDouble()-0.5)*0.5, rand.nextDouble()*0.5,
                            (rand.nextDouble()-0.5)*0.5),
                        1, new Particle.DustOptions(
                            Color.fromRGB(80, 0, 120), 0.5f));
                }
            }
        }.runTaskTimer(plugin, 0L, 3L);
    }

    // ── Active: Shadow Hunt ───────────────────────────────────────────────

    @Override
    public ActivationResult activate(PotionSMP plugin, Player player) {
        UUID uid = player.getUniqueId();

        if (plugin.getCooldownManager().isOnCooldown(uid, type()))
            return ActivationResult.ON_COOLDOWN;

        if (inCountdown.contains(uid)) {
            player.sendMessage(PotionUtils.colorize("&5🌀 Already charging Shadow Hunt!"));
            return ActivationResult.SUCCESS;
        }

        // ── Find target: nearest player in same world ─────────────────────
        Player target = findTarget(player);
        if (target == null) {
            player.sendMessage(PotionUtils.colorize("&cNo valid target found nearby!"));
            return ActivationResult.SUCCESS;
        }

        // ── Start countdown ───────────────────────────────────────────────
        inCountdown.add(uid);
        pendingTarget.put(uid, target.getName());

        plugin.getCooldownManager().setCooldown(uid, type(),
            plugin.getConfig().getInt("potions.teleport.cooldown", 90));

        player.sendMessage(PotionUtils.colorize(
            "&5🌀 Shadow Hunt targeting: &f" + target.getName() +
            " &5— Teleporting in &d5 seconds..."));

        startCountdown(plugin, player, target);
        return ActivationResult.SUCCESS;
    }

    /**
     * Find the nearest visible (online) player in the same world.
     * Prefers the player the activator is looking at; falls back to closest.
     */
    private Player findTarget(Player player) {
        // 1. Try raycast — who is the player looking at?
        Player looked = (Player) player.getTargetEntity(60, e -> e instanceof Player p
            && !p.getUniqueId().equals(player.getUniqueId()));

        if (looked != null && looked.getWorld().equals(player.getWorld())) return looked;

        // 2. Closest player in world
        Player closest = null;
        double minDist = Double.MAX_VALUE;
        for (Player p : player.getWorld().getPlayers()) {
            if (p.getUniqueId().equals(player.getUniqueId())) continue;
            double d = p.getLocation().distanceSquared(player.getLocation());
            if (d < minDist) { minDist = d; closest = p; }
        }
        return closest;
    }

    // ── Countdown (5 seconds) ─────────────────────────────────────────────

    private void startCountdown(PotionSMP plugin, Player player, Player target) {
        UUID uid = player.getUniqueId();
        World world = player.getWorld();

        new BukkitRunnable() {
            int secondsLeft = 5;
            int ticks = 0;

            @Override
            public void run() {
                if (!player.isOnline() || !inCountdown.contains(uid)) {
                    cancel(); return;
                }

                // Every 20 ticks = 1 second
                if (ticks % 20 == 0 && ticks > 0) {
                    secondsLeft--;
                }

                Location loc = player.getLocation().add(0, 1, 0);

                // ── Dark portal particles gathering ───────────────────────
                double progress = 1.0 - (secondsLeft / 5.0) + (ticks % 20) / 100.0;
                int particleCount = (int)(3 + progress * 12);

                for (int i = 0; i < particleCount; i++) {
                    double angle = (ticks * 0.3) + (Math.PI * 2 / particleCount) * i;
                    double r = 2.0 - progress * 1.5; // shrinks inward
                    Location p = loc.clone().add(
                        Math.cos(angle) * r, (Math.random() - 0.5) * 2, Math.sin(angle) * r);

                    world.spawnParticle(Particle.PORTAL,         p, 2, 0.1, 0.1, 0.1, 0.3);
                    world.spawnParticle(Particle.REVERSE_PORTAL, p, 1, 0.1, 0.1, 0.1, 0.1);
                    world.spawnParticle(Particle.SQUID_INK,      p, 1, 0.1, 0.1, 0.1, 0.02);
                }

                // Countdown title every second
                if (ticks % 20 == 0) {
                    String color = secondsLeft <= 1 ? "§c" : secondsLeft <= 2 ? "§e" : "§d";
                    player.sendActionBar(net.kyori.adventure.text.Component.text(
                        "§5🌀 Shadow Hunt: " + color + secondsLeft + "s → §f" + target.getName()));
                    world.playSound(loc, Sound.BLOCK_BEACON_AMBIENT, 0.6f, 1.5f + (5 - secondsLeft) * 0.1f);
                }

                ticks++;

                // ── TELEPORT at end ───────────────────────────────────────
                if (secondsLeft <= 0) {
                    inCountdown.remove(uid);
                    pendingTarget.remove(uid);
                    cancel();
                    executeTeleport(plugin, player, target);
                }
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    // ── Execute Teleport ──────────────────────────────────────────────────

    private void executeTeleport(PotionSMP plugin, Player player, Player target) {
        if (!player.isOnline() || !target.isOnline()) return;

        World world  = player.getWorld();
        Location from = player.getLocation().clone();
        Location to   = target.getLocation().clone();

        // ── Pre-teleport effects at origin ────────────────────────────────
        world.spawnParticle(Particle.PORTAL,         from.clone().add(0,1,0), 40, 0.5,1,0.5, 0.4);
        world.spawnParticle(Particle.REVERSE_PORTAL, from.clone().add(0,1,0), 30, 0.5,1,0.5, 0.2);
        world.spawnParticle(Particle.SQUID_INK,      from.clone().add(0,1,0), 20, 0.4,0.5,0.4,0.05);
        world.playSound(from, Sound.ENTITY_ENDERMAN_TELEPORT, 1f, 0.7f);

        // ── Teleport ──────────────────────────────────────────────────────
        player.teleport(to);

        // ── Post-teleport effects at destination ──────────────────────────
        World destWorld = to.getWorld();

        // Enderman flash burst
        destWorld.spawnParticle(Particle.PORTAL,          to.clone().add(0,1,0), 60, 0.6,1.2,0.6, 0.5);
        destWorld.spawnParticle(Particle.REVERSE_PORTAL,  to.clone().add(0,1,0), 40, 0.5,1.0,0.5, 0.3);
        destWorld.spawnParticle(Particle.END_ROD,          to.clone().add(0,2,0), 25, 0.4,0.6,0.4, 0.2);
        destWorld.spawnParticle(Particle.DRAGON_BREATH,   to.clone().add(0,1,0), 20, 0.4,0.5,0.4, 0.05);

        // Purple-black shockwave ring
        spawnShockwaveRing(destWorld, to, 4.0);

        // Sounds
        destWorld.playSound(to, Sound.ENTITY_ENDERMAN_TELEPORT,  1.2f, 0.8f);
        destWorld.playSound(to, Sound.ENTITY_WARDEN_SONIC_CHARGE,0.4f, 0.3f);

        // ── Target debuff ─────────────────────────────────────────────────
        int debuffDur = plugin.getConfig().getInt("potions.teleport.debuff-duration-ticks", 60);
        target.addPotionEffect(new PotionEffect(PotionEffectType.NAUSEA,    debuffDur, 0, false, false));
        target.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, debuffDur, 0, false, false));

        // Screen distortion for target — title flash
        target.sendTitle("§5§l!!!", "§8Shadow teleported to you!", 2, 15, 5);
        target.getWorld().playSound(target.getLocation(),
            Sound.ITEM_CHORUS_FRUIT_TELEPORT, 1.2f, 0.5f);
        target.sendMessage(PotionUtils.colorize(
            "&5☠ &f" + player.getName() + " &5shadow-teleported to you!"));

        // ── Feedback to caster ────────────────────────────────────────────
        player.sendMessage(PotionUtils.colorize(
            "&5🌀 Shadow Hunt complete → &fTeleported to §d" + target.getName() + "&5!"));
        player.sendActionBar(net.kyori.adventure.text.Component.text(
            "§5🌀 Teleported to §f" + target.getName()));

        // Re-apply invisibility (teleport cancels it briefly)
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            if (player.isOnline() &&
                plugin.getSlotManager().hasEquipped(player.getUniqueId(), PotionType.TELEPORT)) {
                applyInvisibility(player);
            }
        }, 2L);
    }

    // ── Shockwave Ring ────────────────────────────────────────────────────

    private void spawnShockwaveRing(World world, Location center, double radius) {
        new BukkitRunnable() {
            double r = 0.3;
            int ticks = 0;

            @Override
            public void run() {
                if (r > radius || ticks > 12) { cancel(); return; }

                int points = (int)(r * 10) + 8;
                for (int i = 0; i < points; i++) {
                    double angle = (Math.PI * 2 / points) * i;
                    double x = center.getX() + r * Math.cos(angle);
                    double z = center.getZ() + r * Math.sin(angle);
                    Location p = new Location(world, x, center.getY() + 0.1, z);

                    world.spawnParticle(Particle.DUST, p, 1,
                        new Particle.DustOptions(Color.fromRGB(100, 0, 200), 1.5f));
                    world.spawnParticle(Particle.SQUID_INK, p, 1, 0, 0, 0, 0.01);
                }

                r += radius / 10.0;
                ticks++;
            }
        }.runTaskTimer(
            com.potionsmp.PotionSMP.getInstance(), 0L, 1L);
    }
}
