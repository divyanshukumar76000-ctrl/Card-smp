package com.potionsmp.abilities;

import com.potionsmp.PotionSMP;
import com.potionsmp.utils.PotionType;
import com.potionsmp.utils.PotionUtils;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.*;

/**
 * ☠ ENDER POTION
 *
 * ── Passive: Void Corruption ──────────────────────────────────────────────
 * Every 10 successful hits on the SAME or different targets:
 *   1. Summon Ender Dragon Fireball at target
 *   2. Stun target 1 second (Slowness 255 + Weakness 255)
 *   3. Void lightning visual strike
 *   4. True Damage
 *   5. Void Corruption particles (dragon breath, end rod, reverse portal)
 *
 * ── Active: Abyss Domain ──────────────────────────────────────────────────
 * 12s duration, 15 block radius
 * - Blindness, Weakness II on all enemies
 * - Teleport/Shield/Regen abilities disabled for enemies
 * - Dragon Breath DOT every second
 * - Void Lightning every 2s on random enemy
 * - Rotating void energy rings
 * - Collapses with void explosion at end
 * Cooldown: 180s
 */
public class EnderAbility implements Ability, Listener {

    @Override
    public PotionType type() { return PotionType.ENDER; }

    public void register(PotionSMP plugin) {
        plugin.getServer().getPluginManager().registerEvents(this, plugin);
    }

    // ── Equip / Unequip ───────────────────────────────────────────────────

    @Override
    public void onEquip(PotionSMP plugin, Player player) {
        // Passive glow aura — subtle void flicker
        startPassiveAura(plugin, player);
        player.sendMessage(PotionUtils.colorize("&8☠ &5Void Corruption passive active."));
    }

    @Override
    public void onUnequip(PotionSMP plugin, Player player) {
        plugin.getParticleManager().cancelAura(player.getUniqueId());
        plugin.getEnderDomainManager().endDomain(player);
    }

    // ── Passive: every 10 hits ────────────────────────────────────────────

    @Override
    public void onHit(PotionSMP plugin, Player player, LivingEntity target) {
        int count = plugin.getHitCounterManager().registerHit(
            player.getUniqueId(), type(),
            target.getUniqueId(),
            player.getWorld().getFullTime());

        if (count == -1) return;

        int threshold = plugin.getConfig().getInt("potions.ender.passive-hits", 10);

        // Small flicker on every hit
        target.getWorld().spawnParticle(Particle.DRAGON_BREATH,
            target.getLocation().add(0, 1, 0), 3, 0.2, 0.3, 0.2, 0.02);

        if (count >= threshold) {
            plugin.getHitCounterManager().reset(player.getUniqueId(), type());
            triggerVoidCorruption(plugin, player, target);
        }
    }

    private void triggerVoidCorruption(PotionSMP plugin, Player player, LivingEntity target) {
        Location loc = target.getLocation();
        World world  = target.getWorld();

        double trueDmg = plugin.getConfig().getDouble("potions.ender.passive-true-damage", 6.0);

        // 1. True damage
        target.damage(trueDmg, player);
        target.setNoDamageTicks(0);

        // 2. Stun 1 second (20 ticks)
        target.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS,  25, 255, false, false));
        target.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS,  25, 255, false, false));
        target.addPotionEffect(new PotionEffect(PotionEffectType.JUMP_BOOST,25, 128, false, false));

        // 3. Void Lightning
        world.strikeLightningEffect(loc);
        world.playSound(loc, Sound.ENTITY_LIGHTNING_BOLT_IMPACT, 1.0f, 0.4f);

        // 4. Ender Dragon Fireball (visual summon — spawned then removed after 1s)
        DragonFireball fb = (DragonFireball) world.spawnEntity(
            loc.clone().add(0, 3, 0), EntityType.DRAGON_FIREBALL);
        fb.setShooter(player);
        fb.setVelocity(new org.bukkit.util.Vector(0, -0.3, 0));
        // Remove after short time — it's visual + stun, not a flying projectile
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            if (!fb.isDead()) fb.remove();
        }, 10L);

        // 5. Void Corruption particles
        world.spawnParticle(Particle.DRAGON_BREATH,  loc.clone().add(0,1,0), 30, 0.5, 0.8, 0.5, 0.05);
        world.spawnParticle(Particle.REVERSE_PORTAL, loc.clone().add(0,1,0), 20, 0.4, 0.6, 0.4, 0.1);
        world.spawnParticle(Particle.END_ROD,         loc.clone().add(0,2,0), 15, 0.3, 0.5, 0.3, 0.15);
        world.spawnParticle(Particle.PORTAL,          loc.clone().add(0,1,0), 25, 0.4, 0.6, 0.4, 0.3);
        world.spawnParticle(Particle.SQUID_INK,       loc.clone().add(0,1,0), 10, 0.3, 0.4, 0.3, 0.05);

        // Black smoke pillars
        new BukkitRunnable() {
            int t = 0;
            @Override
            public void run() {
                if (t >= 20 || !target.isValid()) { cancel(); return; }
                for (int y = 0; y < 3; y++)
                    world.spawnParticle(Particle.SQUID_INK,
                        loc.clone().add(0, y * 0.5, 0), 1, 0.1, 0, 0.1, 0.01);
                t++;
            }
        }.runTaskTimer(plugin, 0L, 1L);

        world.playSound(loc, Sound.ENTITY_ENDER_DRAGON_GROWL,   0.8f, 0.8f);
        world.playSound(loc, Sound.BLOCK_END_PORTAL_SPAWN,       0.6f, 0.7f);
        world.playSound(loc, Sound.ENTITY_LIGHTNING_BOLT_THUNDER,0.5f, 0.3f);

        player.sendMessage(PotionUtils.colorize("&5☠ Void Corruption triggered on &8" + target.getName() + "&5!"));
        if (target instanceof Player p)
            p.sendMessage(PotionUtils.colorize("&5☠ Void Corruption strikes you!"));
    }

    // ── Passive Aura ──────────────────────────────────────────────────────

    private void startPassiveAura(PotionSMP plugin, Player player) {
        plugin.getParticleManager().cancelAura(player.getUniqueId());
        new BukkitRunnable() {
            double angle = 0;
            final Random rand = new Random();
            @Override
            public void run() {
                if (!player.isOnline() ||
                    !plugin.getSlotManager().hasEquipped(player.getUniqueId(), PotionType.ENDER)) {
                    cancel(); return;
                }
                Location loc = player.getLocation().add(0, 1, 0);
                angle += 0.2;

                // Slow rotating dragon breath wisps
                for (int i = 0; i < 3; i++) {
                    double a = angle + (Math.PI * 2 / 3) * i;
                    Location p = loc.clone().add(Math.cos(a) * 1.0, 0.2 * Math.sin(angle * 2), Math.sin(a) * 1.0);
                    loc.getWorld().spawnParticle(Particle.DRAGON_BREATH, p, 1, 0, 0, 0, 0.01);
                }
                if (rand.nextInt(4) == 0)
                    loc.getWorld().spawnParticle(Particle.REVERSE_PORTAL,
                        loc, 1, 0.3, 0.3, 0.3, 0.05);
                if (rand.nextInt(6) == 0)
                    loc.getWorld().spawnParticle(Particle.END_ROD,
                        loc, 1, 0.4, 0.6, 0.4, 0.05);
            }
        }.runTaskTimer(plugin, 0L, 3L);
    }

    // ── Active: Abyss Domain ──────────────────────────────────────────────

    @Override
    public ActivationResult activate(PotionSMP plugin, Player player) {
        UUID uid = player.getUniqueId();
        if (plugin.getCooldownManager().isOnCooldown(uid, type()))
            return ActivationResult.ON_COOLDOWN;

        int cooldown = plugin.getConfig().getInt("potions.ender.active-cooldown", 180);
        plugin.getCooldownManager().setCooldown(uid, type(), cooldown);

        plugin.getEnderDomainManager().startDomain(player);
        return ActivationResult.SUCCESS;
    }

    // ── Block suppressed players from using abilities ──────────────────────
    // Checked in SlotCommand / activate() pipeline via EnderDomainManager.isSuppressed()
}
