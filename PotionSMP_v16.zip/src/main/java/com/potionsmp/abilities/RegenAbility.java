package com.potionsmp.abilities;

import com.potionsmp.PotionSMP;
import com.potionsmp.managers.ParticleManager;
import com.potionsmp.utils.PotionType;
import com.potionsmp.utils.PotionUtils;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class RegenAbility implements Ability, Listener {

    // Track players whose fall damage should be negated (after successful hit while charged)
    private final Set<UUID> fallNegate = new HashSet<>();

    public void register(PotionSMP plugin) {
        plugin.getServer().getPluginManager().registerEvents(this, plugin);
    }

    @Override
    public PotionType type() { return PotionType.REGEN; }

    @Override
    public void onEquip(PotionSMP plugin, Player player) {
        int amp = plugin.getConfig().getInt("potions.regen.regen-amplifier", 0);
        player.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION,
            Integer.MAX_VALUE, amp, false, false));
    }

    @Override
    public void onUnequip(PotionSMP plugin, Player player) {
        player.removePotionEffect(PotionEffectType.REGENERATION);
        plugin.getRegenAbilityManager().clearCharge(player.getUniqueId());
        plugin.getRegenAbilityManager().disarm(player.getUniqueId());
        plugin.getParticleManager().cancelAura(player.getUniqueId());
        fallNegate.remove(player.getUniqueId());
    }

    @Override
    public void onHit(PotionSMP plugin, Player player, LivingEntity target) {
        if (!plugin.getRegenAbilityManager().isChargedForDive(player.getUniqueId())) return;

        double dmg = plugin.getConfig().getDouble("potions.regen.mace-dive-damage", 10.0) * 2;
        plugin.getRegenAbilityManager().triggerMaceDive(player, target, dmg);
        player.sendMessage(PotionUtils.msg("mace-dive-hit").replace("%target%", target.getName()));

        // ── Negate fall damage after successful mace hit ──────────────────
        fallNegate.add(player.getUniqueId());
        // Remove after 3 seconds (if they don't land)
        plugin.getServer().getScheduler().runTaskLater(plugin,
            () -> fallNegate.remove(player.getUniqueId()), 60L);
    }

    /** Negate fall damage after successful mace dive hit */
    @EventHandler(priority = EventPriority.HIGH)
    public void onFallDamage(EntityDamageEvent e) {
        if (e.getCause() != EntityDamageEvent.DamageCause.FALL) return;
        if (!(e.getEntity() instanceof Player p)) return;
        if (fallNegate.remove(p.getUniqueId())) {
            e.setCancelled(true);
        }
    }

    @Override
    public ActivationResult activate(PotionSMP plugin, Player player) {
        UUID uid = player.getUniqueId();

        // ── If cooldown remaining BUT ability already running → re-arm ────
        // (player can use double jump again while ability is active)
        if (plugin.getRegenAbilityManager().isAbilityRunning(uid)) {
            plugin.getRegenAbilityManager().arm(uid);
            player.sendMessage(PotionUtils.colorize("&a✦ Re-armed! Double-jump to launch again."));
            return ActivationResult.SUCCESS;
        }

        // ── Normal activation — need fresh cooldown ───────────────────────
        if (plugin.getCooldownManager().isOnCooldown(uid, type()))
            return ActivationResult.ON_COOLDOWN;

        int cooldown = plugin.getConfig().getInt("potions.regen.active-cooldown", 45);
        plugin.getCooldownManager().setCooldown(uid, type(), cooldown);
        plugin.getRegenAbilityManager().arm(uid);
        player.sendMessage(PotionUtils.colorize("&a✦ Vitality Surge armed! Double-jump to launch."));
        return ActivationResult.SUCCESS;
    }

    public void triggerVitalitySurge(PotionSMP plugin, Player player) {
        int height   = plugin.getConfig().getInt("potions.regen.active-jump-height", 10);
        int duration = plugin.getConfig().getInt("potions.regen.active-duration", 200);
        int amp      = plugin.getConfig().getInt("potions.regen.regen-amplifier", 0);

        player.sendMessage(PotionUtils.msg("regen-active"));
        plugin.getParticleManager().startRegenAura(player, duration);
        ParticleManager.spawnRegenPassiveParticles(player.getLocation().clone().add(0, 1, 0));
        plugin.getRegenAbilityManager().launch(player, height, duration, amp + 1);
    }
}
