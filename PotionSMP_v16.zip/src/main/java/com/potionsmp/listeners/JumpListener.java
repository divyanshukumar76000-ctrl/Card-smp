package com.potionsmp.listeners;

import com.potionsmp.PotionSMP;
import com.potionsmp.abilities.RegenAbility;
import com.potionsmp.utils.PotionType;
import com.destroystokyo.paper.event.player.PlayerJumpEvent;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Regen Potion — Continuous Double Jump System
 *
 * While ability is ACTIVE and player is ON GROUND:
 *   → Player can double jump again (re-launches them)
 *   → This repeats until ability duration ends
 *
 * Phase 1 — PlayerJumpEvent: record first jump, mark airborne
 * Phase 2 — PlayerMoveEvent: detect landing (isOnGround)
 * Phase 3 — PlayerJumpEvent again while landed flag active = double jump → launch
 */
public class JumpListener implements Listener {

    private final PotionSMP plugin;

    // Players currently airborne (jumped, not yet landed)
    private final Map<UUID, Boolean> airborne = new HashMap<>();
    // Players who landed and are eligible for a double-jump trigger
    private final Map<UUID, Long> landedAt = new HashMap<>();
    // Players whose ability is currently running (can keep re-jumping)
    private final Set<UUID> abilityActive = new HashSet<>();

    private static final long DOUBLE_JUMP_WINDOW_MS = 800;

    public JumpListener(PotionSMP plugin) {
        this.plugin = plugin;
    }

    /** Called when Vitality Surge launches — marks ability as active. */
    public void markActive(UUID uuid) {
        abilityActive.add(uuid);
    }

    /** Called when ability ends — clears active state. */
    public void markInactive(UUID uuid) {
        abilityActive.remove(uuid);
        airborne.remove(uuid);
        landedAt.remove(uuid);
    }

    private boolean regenEquipped(Player player) {
        PotionType s1 = plugin.getSlotManager().getSlot1(player.getUniqueId());
        PotionType s2 = plugin.getSlotManager().getSlot2(player.getUniqueId());
        return s1 == PotionType.REGEN || s2 == PotionType.REGEN;
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onJump(PlayerJumpEvent event) {
        Player player = event.getPlayer();
        if (!regenEquipped(player)) return;

        UUID uid = player.getUniqueId();

        // ── First jump while armed → arm phase, detect double jump ───────
        if (plugin.getRegenAbilityManager().isArmed(uid)) {
            Long landed = landedAt.get(uid);
            if (landed != null && (System.currentTimeMillis() - landed) <= DOUBLE_JUMP_WINDOW_MS) {
                // Double jump confirmed → trigger Vitality Surge launch
                landedAt.remove(uid);
                airborne.put(uid, true);
                markActive(uid);

                RegenAbility ability = (RegenAbility) plugin.getAbilityRegistry().get(PotionType.REGEN);
                ability.triggerVitalitySurge(plugin, player);
            } else {
                // First jump — mark airborne, wait for landing
                airborne.put(uid, true);
                landedAt.remove(uid);
            }
            return;
        }

        // ── Ability is ACTIVE → allow re-launch on every ground jump ─────
        if (abilityActive.contains(uid)) {
            Long landed = landedAt.get(uid);
            if (landed != null) {
                // Player is on ground and jumps → re-launch!
                landedAt.remove(uid);
                airborne.put(uid, true);

                int height   = plugin.getConfig().getInt("potions.regen.active-jump-height", 10);
                int duration = plugin.getConfig().getInt("potions.regen.active-duration", 200);
                int amp      = plugin.getConfig().getInt("potions.regen.regen-amplifier", 0);
                plugin.getRegenAbilityManager().launchOnly(player, height);

                player.sendActionBar(net.kyori.adventure.text.Component.text(
                    "§a⬆ Jump boost! Land again to re-launch."));
            } else {
                // First jump while active — mark airborne
                airborne.put(uid, true);
            }
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onMove(PlayerMoveEvent event) {
        Player player = event.getPlayer();
        UUID uid = player.getUniqueId();

        if (!airborne.getOrDefault(uid, false)) return;

        boolean isRegen = plugin.getRegenAbilityManager().isArmed(uid)
                || abilityActive.contains(uid);
        if (!isRegen) return;

        // Player was airborne and just touched ground
        if (player.isOnGround()) {
            airborne.put(uid, false);
            landedAt.put(uid, System.currentTimeMillis());
        }
    }
}
