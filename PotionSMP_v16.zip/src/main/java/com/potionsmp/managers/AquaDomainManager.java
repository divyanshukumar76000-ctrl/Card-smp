package com.potionsmp.managers;

import com.potionsmp.PotionSMP;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import java.util.*;

/**
 * Manages:
 * 1. Ocean Domain (15-block radius, 15s)
 * 2. Leviathan Judgment task (every 1.5s)
 * 3. Divine Trident entity + lock-on strike
 * 4. Storm effects (particles + sound loop)
 * 5. Full cleanup on end
 */
public class AquaDomainManager {

    private final PotionSMP plugin;

    // Active domain tasks per player
    private final Map<UUID, BukkitTask> domainTasks    = new HashMap<>();
    private final Map<UUID, BukkitTask> leviathanTasks = new HashMap<>();
    private final Map<UUID, BukkitTask> stormTasks     = new HashMap<>();
    private final Map<UUID, BukkitTask> tridentAnim    = new HashMap<>();

    // Summoned trident stand per player
    private final Map<UUID, ArmorStand> tridents       = new HashMap<>();

    // Lock-on strike used flag (1 per activation)
    private final Map<UUID, Boolean>    lockOnUsed     = new HashMap<>();

    // Fire ability suppression — players inside domain
    private final Map<UUID, UUID> suppressedFire       = new HashMap<>();

    public AquaDomainManager(PotionSMP plugin) { this.plugin = plugin; }

    // ── Start full Poseidon's Wrath ───────────────────────────────────────

    public void startDomain(Player owner) {
        UUID uid = owner.getUniqueId();
        cancelAll(uid);
        lockOnUsed.put(uid, false);

        int    dur    = plugin.getConfig().getInt("potions.aqua.active-duration", 15);
        int    ticks  = dur * 20;
        double radius = plugin.getConfig().getDouble("potions.aqua.domain-radius", 15.0);

        Location center = owner.getLocation().clone();

        // ── Activation burst ──────────────────────────────────────────────
        spawnActivationBurst(center, radius);
        owner.getWorld().playSound(center, Sound.BLOCK_CONDUIT_ACTIVATE, 1.5f, 0.7f);
        owner.getWorld().playSound(center, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 0.8f, 0.4f);
        owner.sendTitle("§b§l🌊 POSEIDON'S WRATH", "§7The ocean obeys your command.", 5, 45, 10);

        // ── Summon Divine Trident ─────────────────────────────────────────
        summonTrident(owner, ticks);

        // ── Ocean Domain loop (every 5 ticks) ─────────────────────────────
        BukkitTask domainTask = new BukkitRunnable() {
            int elapsed = 0;
            double ringAngle = 0;

            @Override
            public void run() {
                if (elapsed >= ticks || !owner.isOnline()) { endDomain(owner); cancel(); return; }

                // Rotating vortex rings at center
                drawOceanRings(center, radius, ringAngle);
                ringAngle += 12;

                // Random falling water + splash in domain
                spawnStormParticles(center, radius);

                // Suppress fire abilities of enemies inside domain
                applyDomainDebuffs(owner, center, radius);

                elapsed += 5;
            }
        }.runTaskTimer(plugin, 0L, 5L);
        domainTasks.put(uid, domainTask);

        // ── Storm sound loop ──────────────────────────────────────────────
        BukkitTask stormTask = new BukkitRunnable() {
            int elapsed = 0;
            @Override
            public void run() {
                if (elapsed >= ticks || !owner.isOnline()) { cancel(); return; }
                center.getWorld().playSound(center, Sound.BLOCK_CONDUIT_AMBIENT, 0.4f, 0.9f);
                if (elapsed % 40 == 0)
                    center.getWorld().playSound(center, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 0.25f, 0.5f);
                elapsed += 20;
            }
        }.runTaskTimer(plugin, 0L, 20L);
        stormTasks.put(uid, stormTask);

        // ── Leviathan Judgment (every 30 ticks = 1.5s) ────────────────────
        BukkitTask levTask = new BukkitRunnable() {
            int elapsed = 0;
            @Override
            public void run() {
                if (elapsed >= ticks || !owner.isOnline()) { cancel(); return; }
                triggerLeviathanJudgment(owner, center, radius);
                elapsed += 30;
            }
        }.runTaskTimer(plugin, 30L, 30L);
        leviathanTasks.put(uid, levTask);

        // ── Auto-end after duration ────────────────────────────────────────
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            if (domainTasks.containsKey(uid)) endDomain(owner);
        }, ticks + 2L);
    }

    // ── Domain: apply debuffs + suppress fire ─────────────────────────────

    private void applyDomainDebuffs(Player owner, Location center, double radius) {
        UUID uid = owner.getUniqueId();
        for (Entity e : center.getWorld().getNearbyEntities(center, radius, radius, radius)) {
            if (!(e instanceof LivingEntity le)) continue;
            if (e.getUniqueId().equals(uid) || e instanceof ArmorStand) continue;

            // Slowness III
            le.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 15, 2, false, false));

            // Pull toward center
            Vector pull = center.toVector().subtract(le.getLocation().toVector()).normalize().multiply(0.35);
            pull.setY(0);
            le.setVelocity(le.getVelocity().add(pull));

            // Suppress fire potion
            suppressedFire.put(e.getUniqueId(), uid);

            if (le instanceof Player p)
                p.sendActionBar(net.kyori.adventure.text.Component.text(
                    "§b🌊 Inside §3" + owner.getName() + "§b's Ocean Domain!"));
        }
        // Remove players who left domain
        suppressedFire.entrySet().removeIf(entry ->
            entry.getValue().equals(uid) &&
            !isInside(entry.getKey(), center, radius));
    }

    public boolean isFireSuppressed(UUID uuid) { return suppressedFire.containsKey(uuid); }

    // ── Leviathan Judgment ────────────────────────────────────────────────

    private void triggerLeviathanJudgment(Player owner, Location center, double radius) {
        double dmg = plugin.getConfig().getDouble("potions.aqua.leviathan-damage", 3.0);

        for (Entity e : center.getWorld().getNearbyEntities(center, radius, radius, radius)) {
            if (!(e instanceof LivingEntity le)) continue;
            if (e.getUniqueId().equals(owner.getUniqueId()) || e instanceof ArmorStand) continue;

            Location loc = le.getLocation();

            // Whirlpool pull
            Vector pull = center.toVector().subtract(loc.toVector()).normalize().multiply(0.5);
            pull.setY(0.1);
            le.setVelocity(pull);

            // True damage
            le.damage(dmg, owner);
            le.setNoDamageTicks(0);

            // Short stun (10 ticks)
            le.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 12, 6, false, false));
            le.addPotionEffect(new PotionEffect(PotionEffectType.JUMP_BOOST, 12, 128, false, false));

            // Particles on entity
            loc.getWorld().spawnParticle(Particle.BUBBLE_COLUMN_UP, loc.clone().add(0,1,0), 8, 0.3,0.4,0.3, 0.05);
            loc.getWorld().spawnParticle(Particle.SPLASH,            loc.clone().add(0,1,0), 10, 0.4,0.4,0.4, 0.2);
            loc.getWorld().spawnParticle(Particle.NAUTILUS,          loc.clone().add(0,1,0), 5, 0.3,0.3,0.3, 0.05);
            loc.getWorld().spawnParticle(Particle.ELECTRIC_SPARK,    loc.clone().add(0,1,0), 4, 0.2,0.3,0.2, 0.05);
        }

        // Whirlpool ring at center
        drawWhirlpoolRing(center, 4.0);
        center.getWorld().playSound(center, Sound.BLOCK_CONDUIT_ATTACK_DAMAGE, 0.8f, 0.6f);
    }

    // ── Divine Trident ────────────────────────────────────────────────────

    private void summonTrident(Player owner, int durationTicks) {
        UUID uid = owner.getUniqueId();
        Location loc = owner.getLocation().add(0, 2.5, 0);

        ArmorStand stand = (ArmorStand) owner.getWorld().spawnEntity(loc, EntityType.ARMOR_STAND);
        stand.setVisible(false);
        stand.setGravity(false);
        stand.setCollidable(false);
        stand.setGlowing(true);
        stand.setSmall(true);
        stand.customName(net.kyori.adventure.text.Component.text("§b⚡ Divine Trident"));
        stand.setCustomNameVisible(false);

        // Give glowing trident item
        org.bukkit.inventory.ItemStack tridentItem = new org.bukkit.inventory.ItemStack(Material.TRIDENT);
        org.bukkit.inventory.meta.ItemMeta meta = tridentItem.getItemMeta();
        meta.setDisplayName("§b⚡ Poseidon's Divine Trident");
        meta.setUnbreakable(true);
        meta.addEnchant(org.bukkit.enchantments.Enchantment.LOYALTY, 3, true);
        meta.addEnchant(org.bukkit.enchantments.Enchantment.SHARPNESS, 10, true);
        tridentItem.setItemMeta(meta);
        stand.getEquipment().setItemInMainHand(tridentItem);

        tridents.put(uid, stand);

        // Orbit animation + lock-on detection
        double[] angle = {0.0};
        double[] lockTime = {0.0};
        BukkitTask anim = new BukkitRunnable() {
            int ticks = 0;

            @Override
            public void run() {
                if (ticks >= durationTicks || stand.isDead() || !owner.isOnline()) {
                    removeTrident(uid); cancel(); return;
                }

                // Orbit
                angle[0] += 0.1;
                double r = 1.8;
                Location orbit = owner.getLocation().clone().add(
                    Math.cos(angle[0]) * r, 2.4, Math.sin(angle[0]) * r);
                stand.teleport(orbit);

                // Trail particles
                orbit.getWorld().spawnParticle(Particle.BUBBLE_COLUMN_UP, orbit, 2, 0.1,0.1,0.1, 0.02);
                orbit.getWorld().spawnParticle(Particle.NAUTILUS,          orbit, 1, 0.1,0.1,0.1, 0);
                if (ticks % 5 == 0)
                    orbit.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, orbit, 2, 0.1,0.1,0.1, 0.02);

                // Lock-on: check if player is looking at an enemy & haven't used strike yet
                if (!lockOnUsed.getOrDefault(uid, true)) {
                    LivingEntity looked = getLookedTarget(owner, 20);
                    if (looked != null) {
                        lockTime[0]++;
                        if (lockTime[0] >= 5) { // 5 ticks looking = trigger
                            lockOnUsed.put(uid, true);
                            triggerLockOnStrike(owner, looked, stand);
                            lockTime[0] = 0;
                        }
                    } else {
                        lockTime[0] = 0;
                    }
                }

                ticks++;
            }
        }.runTaskTimer(plugin, 0L, 1L);
        tridentAnim.put(uid, anim);
    }

    // ── Lock-On Strike ────────────────────────────────────────────────────

    private void triggerLockOnStrike(Player owner, LivingEntity target, ArmorStand stand) {
        Location targetLoc = target.getLocation().clone().add(0, 1, 0);
        World world = target.getWorld();

        // Fly stand to target
        double[] progress = {0.0};
        Location startLoc = stand.getLocation().clone();

        new BukkitRunnable() {
            @Override
            public void run() {
                progress[0] += 0.15;
                if (progress[0] >= 1.0 || stand.isDead()) {
                    // Impact!
                    onTridentImpact(owner, target, targetLoc);
                    cancel();
                    return;
                }
                // Lerp position
                Location cur = startLoc.clone().add(
                    targetLoc.clone().subtract(startLoc).toVector().multiply(progress[0]));
                stand.teleport(cur);
                world.spawnParticle(Particle.BUBBLE_COLUMN_UP, cur, 3, 0.1,0.1,0.1, 0.05);
                world.spawnParticle(Particle.ELECTRIC_SPARK,   cur, 2, 0.1,0.1,0.1, 0.05);
            }
        }.runTaskTimer(plugin, 0L, 1L);

        owner.sendActionBar(net.kyori.adventure.text.Component.text("§b⚡ Lock-On Strike!"));
        world.playSound(targetLoc, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 1f, 0.7f);
    }

    private void onTridentImpact(Player owner, LivingEntity target, Location loc) {
        World world = loc.getWorld();

        // True damage (one-hit divine)
        double dmg = plugin.getConfig().getDouble("potions.aqua.lockon-damage", 18.0);
        target.damage(dmg, owner);
        target.setNoDamageTicks(0);

        // Lightning
        world.strikeLightningEffect(loc);

        // Water explosion
        world.spawnParticle(Particle.SPLASH,           loc, 40, 0.7,0.7,0.7, 0.4);
        world.spawnParticle(Particle.BUBBLE_COLUMN_UP, loc, 30, 0.5,0.5,0.5, 0.2);
        world.spawnParticle(Particle.NAUTILUS,         loc, 20, 0.5,0.5,0.5, 0.05);
        world.spawnParticle(Particle.ELECTRIC_SPARK,   loc, 25, 0.5,0.5,0.5, 0.1);

        // Pull nearby enemies
        for (Entity e : world.getNearbyEntities(loc, 5, 5, 5)) {
            if (!(e instanceof LivingEntity le)) continue;
            if (e.getUniqueId().equals(owner.getUniqueId()) || e instanceof ArmorStand) continue;
            Vector pull = loc.toVector().subtract(le.getLocation().toVector()).normalize().multiply(0.6);
            pull.setY(0.2);
            le.setVelocity(pull);
        }

        world.playSound(loc, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 1.5f, 0.6f);
        world.playSound(loc, Sound.ITEM_TRIDENT_THUNDER,           1.2f, 0.8f);
    }

    // ── Passive: Leviathan's Rage (every 6 hits) ──────────────────────────

    public void triggerLeviathanRage(Player owner, LivingEntity target) {
        Location loc = target.getLocation().clone();
        World world  = loc.getWorld();
        double dmg   = plugin.getConfig().getDouble("potions.aqua.rage-splash-damage", 5.0);

        // Water explosion
        world.spawnParticle(Particle.SPLASH,            loc.clone().add(0,1,0), 50, 0.8,0.8,0.8, 0.5);
        world.spawnParticle(Particle.BUBBLE_COLUMN_UP,  loc.clone().add(0,1,0), 35, 0.6,0.6,0.6, 0.2);
        world.spawnParticle(Particle.NAUTILUS,           loc.clone().add(0,1,0), 20, 0.5,0.5,0.5, 0.05);
        world.spawnParticle(Particle.FALLING_WATER,      loc.clone().add(0,2,0), 30, 1.0,0.5,1.0, 0);

        // Pull + true damage splash within 5 blocks
        for (Entity e : world.getNearbyEntities(loc, 5, 5, 5)) {
            if (!(e instanceof LivingEntity le)) continue;
            if (e.getUniqueId().equals(owner.getUniqueId()) || e instanceof ArmorStand) continue;

            Vector pull = loc.toVector().subtract(le.getLocation().toVector()).normalize().multiply(0.6);
            pull.setY(0.15);
            le.setVelocity(pull);

            le.damage(dmg, owner);
            le.setNoDamageTicks(0);
        }

        world.playSound(loc, Sound.ITEM_TRIDENT_THUNDER, 1.2f, 0.7f);
        world.playSound(loc, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 0.7f, 0.5f);
        owner.sendActionBar(net.kyori.adventure.text.Component.text("§b🌊 Leviathan's Rage!"));
    }

    // ── Visual helpers ────────────────────────────────────────────────────

    private void drawOceanRings(Location center, double radius, double angleOffset) {
        int pts = (int)(radius * 6);
        for (int ring = 0; ring < 3; ring++) {
            double r    = radius * (0.35 + ring * 0.3);
            double yOff = ring * 0.5;
            for (int i = 0; i < pts; i++) {
                double a = Math.toRadians((360.0 / pts) * i + angleOffset + ring * 45);
                Location p = center.clone().add(Math.cos(a)*r, yOff, Math.sin(a)*r);
                center.getWorld().spawnParticle(Particle.BUBBLE_COLUMN_UP, p, 1, 0,0.2,0, 0.01);
                if (i % 6 == 0) center.getWorld().spawnParticle(Particle.NAUTILUS, p, 1, 0,0,0, 0);
            }
        }
    }

    private void drawWhirlpoolRing(Location center, double radius) {
        int pts = 24;
        for (int i = 0; i < pts; i++) {
            double a = Math.toRadians((360.0 / pts) * i);
            Location p = center.clone().add(Math.cos(a)*radius, 0.3, Math.sin(a)*radius);
            center.getWorld().spawnParticle(Particle.BUBBLE_COLUMN_UP, p, 2, 0.1,0.3,0.1, 0.05);
            center.getWorld().spawnParticle(Particle.SPLASH,            p, 3, 0.2,0.2,0.2, 0.1);
        }
    }

    private void spawnStormParticles(Location center, double radius) {
        Random rand = new Random();
        for (int i = 0; i < 10; i++) {
            double rx = (rand.nextDouble()-0.5) * radius * 2;
            double rz = (rand.nextDouble()-0.5) * radius * 2;
            Location rain = center.clone().add(rx, 4 + rand.nextDouble()*3, rz);
            center.getWorld().spawnParticle(Particle.FALLING_WATER, rain, 1, 0.1,0.1,0.1, 0);
            center.getWorld().spawnParticle(Particle.SPLASH,        rain, 2, 0.2,0.2,0.2, 0.1);
        }
    }

    private void spawnActivationBurst(Location center, double radius) {
        center.getWorld().spawnParticle(Particle.BUBBLE_COLUMN_UP, center, 150, radius*0.4, 2, radius*0.4, 0.2);
        center.getWorld().spawnParticle(Particle.SPLASH,            center, 200, radius*0.5, 2, radius*0.5, 0.4);
        center.getWorld().spawnParticle(Particle.NAUTILUS,          center, 80,  radius*0.4, 2, radius*0.4, 0.05);
        center.getWorld().spawnParticle(Particle.ELECTRIC_SPARK,    center, 60,  radius*0.3, 1, radius*0.3, 0.1);
        center.getWorld().spawnParticle(Particle.FALLING_WATER,     center.clone().add(0,3,0),
            100, radius*0.5, 0.5, radius*0.5, 0);
    }

    // ── End / Cleanup ─────────────────────────────────────────────────────

    public void endDomain(Player owner) {
        UUID uid = owner.getUniqueId();
        cancelAll(uid);
        suppressedFire.entrySet().removeIf(e -> e.getValue().equals(uid));

        if (!owner.isOnline()) return;

        Location loc = owner.getLocation();
        loc.getWorld().spawnParticle(Particle.SPLASH,           loc, 120, 5,2,5, 0.4);
        loc.getWorld().spawnParticle(Particle.BUBBLE_COLUMN_UP, loc,  80, 5,2,5, 0.2);
        loc.getWorld().playSound(loc, Sound.BLOCK_CONDUIT_DEACTIVATE, 1f, 1f);
        owner.sendActionBar(net.kyori.adventure.text.Component.text("§7Poseidon's Wrath has ended."));
    }

    private void cancelAll(UUID uid) {
        cancel(domainTasks,    uid);
        cancel(leviathanTasks, uid);
        cancel(stormTasks,     uid);
        cancel(tridentAnim,    uid);
        removeTrident(uid);
        lockOnUsed.remove(uid);
    }

    private void cancel(Map<UUID, BukkitTask> map, UUID uid) {
        BukkitTask t = map.remove(uid);
        if (t != null) { try { t.cancel(); } catch (Exception ignored) {} }
    }

    private void removeTrident(UUID uid) {
        ArmorStand stand = tridents.remove(uid);
        if (stand != null && !stand.isDead()) stand.remove();
    }

    public void cancelAllDomains() {
        new HashSet<>(domainTasks.keySet()).forEach(uid -> {
            Player p = plugin.getServer().getPlayer(uid);
            if (p != null) endDomain(p); else cancelAll(uid);
        });
    }

    // ── Utility ───────────────────────────────────────────────────────────

    private LivingEntity getLookedTarget(Player player, double range) {
        Entity e = player.getTargetEntity((int) range,
            en -> en instanceof LivingEntity && !en.getUniqueId().equals(player.getUniqueId())
               && !(en instanceof ArmorStand));
        return e instanceof LivingEntity le ? le : null;
    }

    private boolean isInside(UUID uuid, Location center, double radius) {
        Entity e = plugin.getServer().getEntity(uuid);
        if (e == null) return false;
        return e.getLocation().distanceSquared(center) <= radius * radius;
    }

    public boolean hasDomain(UUID uuid) { return domainTasks.containsKey(uuid); }
}
