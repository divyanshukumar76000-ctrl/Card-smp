package com.potionsmp.managers;

import com.potionsmp.PotionSMP;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public class RegenAbilityManager {

    private final PotionSMP plugin;

    private final Set<UUID> armed           = new HashSet<>();
    private final Map<UUID, Long> lastJumpTime = new HashMap<>();
    private static final long DOUBLE_JUMP_WINDOW_MS = 600;

    private final Set<UUID> abilityRunning  = new HashSet<>();
    private final Set<UUID> chargedForDive  = new HashSet<>();

    public RegenAbilityManager(PotionSMP plugin) {
        this.plugin = plugin;
    }

    public void arm(UUID uuid)                  { armed.add(uuid); }
    public boolean isArmed(UUID uuid)           { return armed.contains(uuid); }
    public boolean isAbilityRunning(UUID uuid)  { return abilityRunning.contains(uuid); }
    public boolean isChargedForDive(UUID uuid)  { return chargedForDive.contains(uuid); }
    public void clearCharge(UUID uuid)          { chargedForDive.remove(uuid); }

    public void disarm(UUID uuid) {
        armed.remove(uuid);
        lastJumpTime.remove(uuid);
    }

    public boolean registerJumpAndCheckDouble(UUID uuid) {
        long now = System.currentTimeMillis();
        Long last = lastJumpTime.get(uuid);
        lastJumpTime.put(uuid, now);
        return last != null && (now - last) <= DOUBLE_JUMP_WINDOW_MS;
    }

    /**
     * Full launch — first activation from double jump.
     * Starts ability duration, regen effects, visual loop, jump tracking.
     */
    public void launch(Player player, int heightBlocks, int durationTicks, int regenAmplifier) {
        UUID uid = player.getUniqueId();
        disarm(uid);
        abilityRunning.add(uid);

        // Notify JumpListener — ability is now active
        plugin.getJumpListener().markActive(uid);

        doLaunch(player, heightBlocks);
        chargedForDive.add(uid);

        player.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION,
            durationTicks, regenAmplifier, false, true));
        player.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING,
            durationTicks, 0, false, false));

        Location loc = player.getLocation();
        loc.getWorld().spawnParticle(Particle.HEART,
            loc.clone().add(0, 1, 0), 12, 0.4, 0.3, 0.4, 0);
        loc.getWorld().spawnParticle(Particle.TOTEM_OF_UNDYING,
            loc.clone().add(0, 0.2, 0), 20, 0.4, 0.1, 0.4, 0.2);
        loc.getWorld().playSound(loc, Sound.BLOCK_BEACON_AMBIENT, 1f, 1.2f);
        loc.getWorld().playSound(loc, Sound.ITEM_TOTEM_USE, 0.6f, 1.4f);

        runVisualLoop(player, durationTicks);

        // Schedule ability end
        new BukkitRunnable() {
            @Override
            public void run() {
                abilityRunning.remove(uid);
                chargedForDive.remove(uid);
                plugin.getJumpListener().markInactive(uid);
                if (player.isOnline())
                    player.sendActionBar(net.kyori.adventure.text.Component.text(
                        "§7Vitality Surge ended."));
            }
        }.runTaskLater(plugin, durationTicks);
    }

    /**
     * Re-launch only — while ability already running, player lands & jumps again.
     */
    public void launchOnly(Player player, int heightBlocks) {
        doLaunch(player, heightBlocks);
        chargedForDive.add(player.getUniqueId());

        Location loc = player.getLocation();
        loc.getWorld().spawnParticle(Particle.HEART,
            loc.clone().add(0, 1, 0), 6, 0.3, 0.2, 0.3, 0);
        loc.getWorld().spawnParticle(Particle.TOTEM_OF_UNDYING,
            loc.clone().add(0, 0.2, 0), 10, 0.3, 0.1, 0.3, 0.1);
        loc.getWorld().playSound(loc, Sound.BLOCK_BEACON_AMBIENT, 0.7f, 1.5f);
    }

    private void doLaunch(Player player, int heightBlocks) {
        double velocity = Math.sqrt(heightBlocks) * 0.85;
        player.setVelocity(new Vector(0, velocity, 0));
    }

    private void runVisualLoop(Player player, int durationTicks) {
        new BukkitRunnable() {
            int ticks = 0;
            double angle = 0;

            @Override
            public void run() {
                if (ticks >= durationTicks || !player.isOnline()) { cancel(); return; }
                Location loc = player.getLocation();

                for (int i = 0; i < 3; i++) {
                    double a = Math.toRadians(angle + (i * 120));
                    loc.getWorld().spawnParticle(Particle.HEART,
                        loc.clone().add(Math.cos(a) * 0.8, 1, Math.sin(a) * 0.8),
                        1, 0, 0, 0, 0);
                }
                angle += 10;

                if (ticks % 10 == 0)
                    loc.getWorld().spawnParticle(Particle.HAPPY_VILLAGER,
                        loc.clone().add(0, 0.2, 0), 4, 0.5, 0.1, 0.5, 0);

                ticks++;
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    /**
     * Mace Dive — TRUE damage, AoE knockback, no iframes.
     */
    public void triggerMaceDive(Player player, LivingEntity target, double diveDamage) {
        UUID uid = player.getUniqueId();
        chargedForDive.remove(uid);

        Location impactLoc = target.getLocation();
        double aoeRadius = plugin.getConfig().getDouble("potions.regen.mace-dive-radius", 5.0);

        // TRUE damage on primary target
        target.damage(diveDamage, player);
        target.setNoDamageTicks(0);

        // AoE damage + knockback
        for (var e : impactLoc.getWorld().getNearbyEntities(impactLoc, aoeRadius, aoeRadius, aoeRadius)) {
            if (!(e instanceof LivingEntity le)) continue;
            if (e.getUniqueId().equals(uid)) continue;
            if (e.getUniqueId().equals(target.getUniqueId())) continue;

            double dist = e.getLocation().distance(impactLoc);
            double aoeDmg = diveDamage * (1.0 - (dist / aoeRadius));
            le.damage(aoeDmg, player);
            le.setNoDamageTicks(0);

            Vector kb = le.getLocation().toVector()
                .subtract(impactLoc.toVector()).normalize()
                .multiply(1.5).setY(0.6);
            le.setVelocity(kb);
        }

        // Particles
        impactLoc.getWorld().spawnParticle(Particle.HEART,
            impactLoc.clone().add(0, 1, 0), 25, 0.6, 0.6, 0.6, 0);
        impactLoc.getWorld().spawnParticle(Particle.TOTEM_OF_UNDYING,
            impactLoc.clone().add(0, 1, 0), 35, 0.6, 0.4, 0.6, 0.3);
        impactLoc.getWorld().spawnParticle(Particle.EXPLOSION,
            impactLoc.clone().add(0, 0.1, 0), 3, 0.5, 0, 0.5, 0);

        // Shockwave ring
        for (int i = 0; i < 36; i++) {
            double angle = Math.toRadians(i * 10);
            impactLoc.getWorld().spawnParticle(Particle.SWEEP_ATTACK,
                impactLoc.getX() + aoeRadius * 0.6 * Math.cos(angle),
                impactLoc.getY() + 0.1,
                impactLoc.getZ() + aoeRadius * 0.6 * Math.sin(angle),
                1, 0, 0, 0, 0);
        }

        impactLoc.getWorld().playSound(impactLoc, Sound.ITEM_MACE_SMASH_GROUND, 1.5f, 0.8f);
        impactLoc.getWorld().playSound(impactLoc, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 0.7f, 0.5f);
        impactLoc.getWorld().playSound(impactLoc, Sound.ENTITY_GENERIC_EXPLODE, 0.6f, 1.2f);
    }
}
