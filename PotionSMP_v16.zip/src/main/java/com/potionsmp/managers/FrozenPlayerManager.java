package com.potionsmp.managers;

import com.potionsmp.PotionSMP;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.entity.ProjectileLaunchEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Fully locks frozen players/entities:
 * - Cannot move
 * - Cannot attack
 * - Cannot throw pearls or any projectile
 * - Cannot interact (block/item use)
 * - Cannot pick up items
 * - Velocity zeroed every tick
 */
public class FrozenPlayerManager implements Listener {

    private final PotionSMP plugin;
    private final Map<UUID, Location> frozenLoc    = new HashMap<>();
    private final Map<UUID, Integer>  frozenTasks  = new HashMap<>();

    public FrozenPlayerManager(PotionSMP plugin) {
        this.plugin = plugin;
        // Register as listener for full freeze blocking
        plugin.getServer().getPluginManager().registerEvents(this, plugin);
    }

    // ── Freeze ────────────────────────────────────────────────────────────

    public void freezeEntity(LivingEntity entity, int durationTicks) {
        UUID uid = entity.getUniqueId();
        Location loc = entity.getLocation().clone();
        frozenLoc.put(uid, loc);

        // Cancel existing task
        Integer old = frozenTasks.remove(uid);
        if (old != null) plugin.getServer().getScheduler().cancelTask(old);

        int dur = durationTicks + 5;

        // Potion effects — completely lock movement & actions
        entity.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS,       dur, 255, false, false));
        entity.addPotionEffect(new PotionEffect(PotionEffectType.MINING_FATIGUE, dur, 255, false, false));
        entity.addPotionEffect(new PotionEffect(PotionEffectType.JUMP_BOOST,     dur, 128, false, false));
        entity.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS,       dur, 255, false, false));

        BukkitRunnable task = new BukkitRunnable() {
            int ticks = 0;

            @Override
            public void run() {
                if (ticks >= durationTicks || !entity.isValid()) {
                    unfreeze(entity);
                    cancel();
                    return;
                }

                // Lock position every tick
                if (entity.getLocation().distanceSquared(loc) > 0.05) {
                    entity.teleport(loc);
                }
                entity.setVelocity(new Vector(0, 0, 0));

                // Ice particles around frozen entity
                entity.getWorld().spawnParticle(Particle.SNOWFLAKE,
                    entity.getLocation().add(0, 1, 0), 4, 0.3, 0.5, 0.3, 0.01);
                if (ticks % 10 == 0) {
                    entity.getWorld().spawnParticle(Particle.ITEM_SNOWBALL,
                        entity.getLocation().add(0, 1, 0), 3, 0.3, 0.3, 0.3, 0);
                    entity.getWorld().playSound(entity.getLocation(),
                        Sound.BLOCK_POWDER_SNOW_STEP, 0.3f, 1.5f);
                }

                ticks++;
            }
        };

        int taskId = task.runTaskTimer(plugin, 0L, 1L).getTaskId();
        frozenTasks.put(uid, taskId);

        // Notify if player
        if (entity instanceof Player p) {
            p.sendActionBar(net.kyori.adventure.text.Component.text("§b❄ You are frozen!"));
        }
    }

    // ── Block all actions for frozen entities ─────────────────────────────

    /** Block movement */
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onMove(PlayerMoveEvent e) {
        if (!frozenLoc.containsKey(e.getPlayer().getUniqueId())) return;
        Location loc = frozenLoc.get(e.getPlayer().getUniqueId());
        // Allow head rotation (yaw/pitch) but block positional movement
        if (e.getTo().getX() != e.getFrom().getX()
         || e.getTo().getY() != e.getFrom().getY()
         || e.getTo().getZ() != e.getFrom().getZ()) {
            e.setCancelled(true);
            e.getPlayer().teleport(loc);
        }
    }

    /** Block attacking */
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onAttack(EntityDamageByEntityEvent e) {
        if (e.getDamager() instanceof LivingEntity le
         && frozenLoc.containsKey(le.getUniqueId())) {
            e.setCancelled(true);
        }
    }

    /** Block projectile throwing (pearls, snowballs, arrows etc.) */
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onProjectile(ProjectileLaunchEvent e) {
        if (e.getEntity().getShooter() instanceof LivingEntity le
         && frozenLoc.containsKey(le.getUniqueId())) {
            e.setCancelled(true);
        }
    }

    /** Block all interactions (right-click items, blocks) */
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onInteract(PlayerInteractEvent e) {
        if (frozenLoc.containsKey(e.getPlayer().getUniqueId())) {
            e.setCancelled(true);
        }
    }

    /** Block item pickup */
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPickup(EntityPickupItemEvent e) {
        if (e.getEntity() instanceof LivingEntity le
         && frozenLoc.containsKey(le.getUniqueId())) {
            e.setCancelled(true);
        }
    }

    // ── Unfreeze ──────────────────────────────────────────────────────────

    public void unfreeze(LivingEntity entity) {
        UUID uid = entity.getUniqueId();
        frozenLoc.remove(uid);
        Integer taskId = frozenTasks.remove(uid);
        if (taskId != null) plugin.getServer().getScheduler().cancelTask(taskId);

        if (entity.isValid()) {
            entity.removePotionEffect(PotionEffectType.SLOWNESS);
            entity.removePotionEffect(PotionEffectType.MINING_FATIGUE);
            entity.removePotionEffect(PotionEffectType.JUMP_BOOST);
            entity.removePotionEffect(PotionEffectType.WEAKNESS);
        }
        if (entity instanceof Player p) {
            p.sendActionBar(net.kyori.adventure.text.Component.text("§7Freeze ended."));
        }
    }

    public boolean isFrozen(UUID uid) { return frozenLoc.containsKey(uid); }

    public void unfreezeAll() {
        frozenTasks.values().forEach(id ->
            plugin.getServer().getScheduler().cancelTask(id));
        frozenLoc.clear();
        frozenTasks.clear();
    }
}
