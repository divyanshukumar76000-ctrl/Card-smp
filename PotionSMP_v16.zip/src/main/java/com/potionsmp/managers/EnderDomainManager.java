package com.potionsmp.managers;

import com.potionsmp.PotionSMP;
import com.potionsmp.utils.PotionType;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import java.util.*;

/**
 * Manages the Abyss Domain for Ender Potion active ability.
 *
 * Domain effects:
 * - 15 block radius void zone
 * - Enemies: Blindness, Weakness II, True DOT, Glowing
 * - Blocks: Teleport, Shield, Regen abilities for enemies inside
 * - Void lightning every 2s on random enemy
 * - Dragon Breath aura around player
 * - Rotating void energy rings
 * - Ends with void explosion at 12s
 */
public class EnderDomainManager {

    private final PotionSMP plugin;

    // Active domain per player
    private final Map<UUID, BukkitTask> domainTasks  = new HashMap<>();
    private final Map<UUID, BukkitTask> lightnTasks  = new HashMap<>();
    private final Map<UUID, BukkitTask> auraTasks    = new HashMap<>();

    // Players INSIDE an active domain (blocked from using abilities)
    // key = target UUID, value = domain owner UUID
    private final Map<UUID, UUID> suppressedPlayers  = new HashMap<>();

    public EnderDomainManager(PotionSMP plugin) { this.plugin = plugin; }

    // ── Is a player suppressed (inside someone's domain)? ─────────────────

    public boolean isSuppressed(UUID targetUuid) {
        return suppressedPlayers.containsKey(targetUuid);
    }

    // ── Start Domain ──────────────────────────────────────────────────────

    public void startDomain(Player owner) {
        UUID uid = owner.getUniqueId();
        cancelDomain(uid);

        int    durationSec = plugin.getConfig().getInt("potions.ender.active-duration", 12);
        int    durationTick = durationSec * 20;
        double radius       = plugin.getConfig().getDouble("potions.ender.domain-radius", 15.0);
        double dotDmg       = plugin.getConfig().getDouble("potions.ender.dot-damage", 1.5);
        int    lightningInt = plugin.getConfig().getInt("potions.ender.lightning-interval-ticks", 40);
        int    lightningDmg = plugin.getConfig().getInt("potions.ender.lightning-damage", 4);

        Location center = owner.getLocation().clone();

        // ── Activation effects ────────────────────────────────────────────
        spawnActivationBurst(center, radius);
        owner.getWorld().playSound(center, Sound.ENTITY_ENDER_DRAGON_GROWL,    1.5f, 0.6f);
        owner.getWorld().playSound(center, Sound.BLOCK_END_PORTAL_SPAWN,        1.0f, 0.5f);
        owner.sendTitle("§5§l☠ ABYSS DOMAIN", "§8Void corruption spreads...", 5, 40, 10);

        // ── Main domain loop (every tick) ──────────────────────────────────
        BukkitTask domainTask = new BukkitRunnable() {
            int    ticks    = 0;
            double ringAngle = 0;

            @Override
            public void run() {
                if (ticks >= durationTick || !owner.isOnline()) {
                    endDomain(owner);
                    cancel();
                    return;
                }

                // Rotating void energy rings
                drawVoidRings(center, radius, ringAngle);
                ringAngle += 6;

                // Ground void coverage
                if (ticks % 3 == 0) spawnGroundVoid(center, radius);

                // Sky darkener — blindness pulse every 20 ticks
                if (ticks % 20 == 0) {
                    applyDomainEffects(owner, center, radius, dotDmg);
                    // Bass rumble
                    center.getWorld().playSound(center,
                        Sound.ENTITY_ENDER_DRAGON_AMBIENT, 0.6f, 0.3f);
                }

                // Dragon breath aura around owner (every 5 ticks)
                if (ticks % 5 == 0) spawnDragonAura(owner);

                ticks++;
            }
        }.runTaskTimer(plugin, 0L, 1L);
        domainTasks.put(uid, domainTask);

        // ── Void lightning every 2 seconds ────────────────────────────────
        BukkitTask lightTask = new BukkitRunnable() {
            int elapsed = 0;

            @Override
            public void run() {
                if (elapsed >= durationTick || !owner.isOnline()) { cancel(); return; }

                List<LivingEntity> enemies = getNearbyEnemies(owner, center, radius);
                if (!enemies.isEmpty()) {
                    LivingEntity target = enemies.get(new Random().nextInt(enemies.size()));
                    strikeVoidLightning(owner, target, lightningDmg);
                }
                elapsed += lightningInt;
            }
        }.runTaskTimer(plugin, lightningInt, lightningInt);
        lightnTasks.put(uid, lightTask);

        // ── Schedule domain collapse ───────────────────────────────────────
        new BukkitRunnable() {
            @Override
            public void run() {
                if (domainTasks.containsKey(uid)) endDomain(owner);
            }
        }.runTaskLater(plugin, durationTick + 2L);
    }

    // ── Apply domain effects to enemies inside ────────────────────────────

    private void applyDomainEffects(Player owner, Location center, double radius, double dotDmg) {
        List<LivingEntity> enemies = getNearbyEnemies(owner, center, radius);

        for (LivingEntity enemy : enemies) {
            UUID euid = enemy.getUniqueId();

            // Suppress abilities
            suppressedPlayers.put(euid, owner.getUniqueId());

            // Blindness + Weakness II
            enemy.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 30, 0, false, false));
            enemy.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS,  30, 1, false, false));
            enemy.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING,   30, 0, false, false));

            // True DOT damage
            enemy.damage(dotDmg, owner);
            enemy.setNoDamageTicks(0);

            // Dragon breath on enemy
            enemy.getWorld().spawnParticle(Particle.DRAGON_BREATH,
                enemy.getLocation().add(0, 1, 0), 6, 0.3, 0.5, 0.3, 0.03);

            // Notify suppressed player
            if (enemy instanceof Player p) {
                p.sendActionBar(net.kyori.adventure.text.Component.text(
                    "§5☠ You are inside §8" + owner.getName() + "§5's Abyss Domain!"));
            }
        }

        // Remove suppression for players who left the domain
        suppressedPlayers.entrySet().removeIf(entry ->
            entry.getValue().equals(owner.getUniqueId()) &&
            !isInsideDomain(entry.getKey(), center, radius));
    }

    // ── Void Lightning strike ─────────────────────────────────────────────

    private void strikeVoidLightning(Player owner, LivingEntity target, int damage) {
        Location loc = target.getLocation();

        // Visual lightning (no fire)
        loc.getWorld().strikeLightningEffect(loc);

        // True damage
        target.damage(damage, owner);
        target.setNoDamageTicks(0);

        // Extra void particles
        loc.getWorld().spawnParticle(Particle.DRAGON_BREATH, loc.clone().add(0,1,0),
            20, 0.5, 1, 0.5, 0.05);
        loc.getWorld().spawnParticle(Particle.PORTAL,        loc.clone().add(0,1,0),
            30, 0.5, 1, 0.5, 0.3);
        loc.getWorld().spawnParticle(Particle.END_ROD,       loc.clone().add(0,2,0),
            10, 0.3, 0.5, 0.3, 0.1);

        loc.getWorld().playSound(loc, Sound.ENTITY_LIGHTNING_BOLT_IMPACT, 1.0f, 0.5f);
        loc.getWorld().playSound(loc, Sound.BLOCK_END_GATEWAY_SPAWN,      1.0f, 0.8f);

        // Glowing for tracking
        target.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, 60, 0, false, false));
    }

    // ── Domain end / collapse ─────────────────────────────────────────────

    public void endDomain(Player owner) {
        UUID uid = owner.getUniqueId();

        cancelDomain(uid);

        // Clear suppression for all players in this domain
        suppressedPlayers.entrySet().removeIf(e -> e.getValue().equals(uid));

        if (!owner.isOnline()) return;

        Location center = owner.getLocation();

        // Void collapse explosion
        center.getWorld().spawnParticle(Particle.DRAGON_BREATH, center,
            200, 8, 2, 8, 0.1);
        center.getWorld().spawnParticle(Particle.PORTAL,        center,
            300, 8, 3, 8, 0.5);
        center.getWorld().spawnParticle(Particle.END_ROD,       center,
            100, 5, 3, 5, 0.3);
        center.getWorld().spawnParticle(Particle.EXPLOSION,     center,
            5, 3, 1, 3, 0);

        center.getWorld().playSound(center, Sound.ENTITY_ENDER_DRAGON_DEATH, 0.8f, 0.4f);
        center.getWorld().playSound(center, Sound.ENTITY_GENERIC_EXPLODE,    1.0f, 0.5f);

        owner.sendTitle("", "§8Domain collapsed.", 5, 20, 10);
    }

    private void cancelDomain(UUID uid) {
        BukkitTask dt = domainTasks.remove(uid);
        if (dt != null) dt.cancel();
        BukkitTask lt = lightnTasks.remove(uid);
        if (lt != null) lt.cancel();
        BukkitTask at = auraTasks.remove(uid);
        if (at != null) at.cancel();
    }

    // ── Visual helpers ────────────────────────────────────────────────────

    private void drawVoidRings(Location center, double radius, double angleOffset) {
        int points = (int)(radius * 8);
        for (int ring = 0; ring < 3; ring++) {
            double r   = radius * (0.4 + ring * 0.3);
            double yOff = ring * 1.0;
            for (int i = 0; i < points; i++) {
                double angle = Math.toRadians((360.0 / points) * i + angleOffset + ring * 60);
                double x = center.getX() + r * Math.cos(angle);
                double z = center.getZ() + r * Math.sin(angle);
                Location p = new Location(center.getWorld(), x, center.getY() + yOff, z);
                center.getWorld().spawnParticle(Particle.DRAGON_BREATH, p, 1, 0, 0, 0, 0);
                if (i % 5 == 0)
                    center.getWorld().spawnParticle(Particle.PORTAL, p, 1, 0, 0, 0, 0.1);
            }
        }
        // Vertical smoke pillars randomly
        if (Math.random() < 0.3) {
            double angle = Math.random() * Math.PI * 2;
            double r = radius * (0.3 + Math.random() * 0.6);
            Location pillar = new Location(center.getWorld(),
                center.getX() + r * Math.cos(angle),
                center.getY(),
                center.getZ() + r * Math.sin(angle));
            for (int y = 0; y < 4; y++) {
                center.getWorld().spawnParticle(Particle.SQUID_INK,
                    pillar.clone().add(0, y, 0), 2, 0.1, 0, 0.1, 0.02);
            }
        }
    }

    private void spawnGroundVoid(Location center, double radius) {
        for (int i = 0; i < 8; i++) {
            double angle = Math.random() * Math.PI * 2;
            double r = Math.random() * radius;
            double x = center.getX() + r * Math.cos(angle);
            double z = center.getZ() + r * Math.sin(angle);
            Location p = new Location(center.getWorld(), x, center.getY() + 0.1, z);
            center.getWorld().spawnParticle(Particle.DRAGON_BREATH, p, 1, 0, 0, 0, 0.01);
            center.getWorld().spawnParticle(Particle.REVERSE_PORTAL, p, 1, 0.1, 0, 0.1, 0.02);
        }
    }

    private void spawnDragonAura(Player owner) {
        Location loc = owner.getLocation().add(0, 1, 0);
        double[] angles = {0, 90, 180, 270};
        for (double a : angles) {
            double angle = Math.toRadians(a);
            Location p = loc.clone().add(Math.cos(angle) * 1.5, 0, Math.sin(angle) * 1.5);
            loc.getWorld().spawnParticle(Particle.DRAGON_BREATH, p, 3, 0.1, 0.2, 0.1, 0.02);
        }
        loc.getWorld().spawnParticle(Particle.END_ROD, loc, 2, 0.4, 0.5, 0.4, 0.05);
        loc.getWorld().spawnParticle(Particle.REVERSE_PORTAL, loc, 3, 0.3, 0.3, 0.3, 0.1);
    }

    private void spawnActivationBurst(Location center, double radius) {
        center.getWorld().spawnParticle(Particle.DRAGON_BREATH, center, 150, radius*0.5, 2, radius*0.5, 0.1);
        center.getWorld().spawnParticle(Particle.PORTAL,        center, 200, radius*0.5, 3, radius*0.5, 0.5);
        center.getWorld().spawnParticle(Particle.REVERSE_PORTAL,center, 100, radius*0.4, 2, radius*0.4, 0.2);
        center.getWorld().spawnParticle(Particle.END_ROD,       center,  80, radius*0.4, 2, radius*0.4, 0.2);
        center.getWorld().spawnParticle(Particle.SQUID_INK,     center,  60, radius*0.3, 1, radius*0.3, 0.1);
    }

    // ── Helpers ───────────────────────────────────────────────────────────

    private List<LivingEntity> getNearbyEnemies(Player owner, Location center, double radius) {
        List<LivingEntity> list = new ArrayList<>();
        for (Entity e : center.getWorld().getNearbyEntities(center, radius, radius, radius)) {
            if (!(e instanceof LivingEntity le)) continue;
            if (e.getUniqueId().equals(owner.getUniqueId())) continue;
            if (e instanceof ArmorStand) continue;
            list.add(le);
        }
        return list;
    }

    private boolean isInsideDomain(UUID targetUid, Location center, double radius) {
        Entity e = plugin.getServer().getEntity(targetUid);
        if (e == null) return false;
        return e.getLocation().distanceSquared(center) <= radius * radius;
    }

    public void cancelAll() {
        domainTasks.forEach((u, t) -> t.cancel());
        lightnTasks.forEach((u, t) -> t.cancel());
        auraTasks.forEach((u, t) -> t.cancel());
        domainTasks.clear();
        lightnTasks.clear();
        auraTasks.clear();
        suppressedPlayers.clear();
    }

    public boolean hasDomain(UUID uuid) { return domainTasks.containsKey(uuid); }
}
