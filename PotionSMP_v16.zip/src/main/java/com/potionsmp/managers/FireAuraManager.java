package com.potionsmp.managers;

import com.potionsmp.PotionSMP;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Fire Potion — Inferno Ring
 * A visible circular ring of fire appears around the player.
 * Every 1 second, all players/mobs inside the ring take true damage + get ignited.
 */
public class FireAuraManager {

    private final PotionSMP plugin;
    private final Map<UUID, Integer> activeTasks = new HashMap<>();

    public FireAuraManager(PotionSMP plugin) {
        this.plugin = plugin;
    }

    public void activateInfernoAura(Player player, int durationTicks, int radius) {
        UUID uid = player.getUniqueId();
        double dps = plugin.getConfig().getDouble("potions.fire.damage-per-second", 2.0);

        // Cancel existing
        Integer existing = activeTasks.remove(uid);
        if (existing != null) plugin.getServer().getScheduler().cancelTask(existing);

        BukkitRunnable auraTask = new BukkitRunnable() {
            int ticks = 0;
            double ringAngle = 0;

            @Override
            public void run() {
                if (ticks >= durationTicks || !player.isOnline()) {
                    activeTasks.remove(uid);
                    cancel();
                    return;
                }

                Location center = player.getLocation();

                // ── Draw circular ring ────────────────────────────────────
                drawFireRing(center, radius, ringAngle);
                ringAngle += 5; // slowly rotate ring

                // ── Inner glow ────────────────────────────────────────────
                center.getWorld().spawnParticle(Particle.FLAME,
                    center.clone().add(0, 0.1, 0), 3, 0.2, 0, 0.2, 0.02);
                center.getWorld().spawnParticle(Particle.LAVA,
                    center.clone().add(0, 0.3, 0), 1, 0.1, 0, 0.1, 0);

                // ── Damage every 20 ticks (1 second) ─────────────────────
                if (ticks % 20 == 0) {
                    for (Entity e : center.getWorld().getNearbyEntities(center, radius, 2.5, radius)) {
                        if (!(e instanceof LivingEntity le)) continue;
                        if (e.getUniqueId().equals(uid)) continue;

                        // True damage — bypass armour
                        le.damage(dps, player);
                        le.setNoDamageTicks(0);
                        le.setFireTicks(60); // 3 seconds fire

                        // Hit spark
                        le.getWorld().spawnParticle(Particle.FLAME,
                            le.getLocation().add(0, 1, 0), 8, 0.3, 0.3, 0.3, 0.05);
                    }
                    // Ring pulse sound
                    center.getWorld().playSound(center, Sound.ENTITY_BLAZE_SHOOT, 0.5f, 0.7f);
                }

                ticks++;
            }
        };

        int taskId = auraTask.runTaskTimer(plugin, 0L, 1L).getTaskId();
        activeTasks.put(uid, taskId);
    }

    /**
     * Draws a full circular ring of FLAME particles around the center.
     * Two layers: ground level + slightly elevated for visual depth.
     */
    private void drawFireRing(Location center, int radius, double angleOffset) {
        int points = Math.max(32, radius * 8);
        for (int i = 0; i < points; i++) {
            double angle = Math.toRadians((360.0 / points) * i + angleOffset);
            double x = center.getX() + radius * Math.cos(angle);
            double z = center.getZ() + radius * Math.sin(angle);

            // Ground ring
            Location ringPoint = new Location(center.getWorld(), x, center.getY() + 0.05, z);
            center.getWorld().spawnParticle(Particle.FLAME, ringPoint, 1, 0, 0, 0, 0);

            // Every 4th point: add lava + elevated flame for thickness
            if (i % 4 == 0) {
                center.getWorld().spawnParticle(Particle.LAVA, ringPoint, 1, 0, 0, 0, 0);
                center.getWorld().spawnParticle(Particle.SMALL_FLAME,
                    ringPoint.clone().add(0, 0.4, 0), 1, 0, 0, 0, 0);
            }
        }
    }

    public void cancelAura(UUID uid) {
        Integer taskId = activeTasks.remove(uid);
        if (taskId != null) plugin.getServer().getScheduler().cancelTask(taskId);
    }

    public void cancelAll() {
        for (int id : activeTasks.values())
            plugin.getServer().getScheduler().cancelTask(id);
        activeTasks.clear();
    }
}
