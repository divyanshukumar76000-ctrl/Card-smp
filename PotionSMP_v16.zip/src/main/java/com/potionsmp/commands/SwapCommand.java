package com.potionsmp.commands;

import com.potionsmp.PotionSMP;
import com.potionsmp.utils.PotionType;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

/**
 * /swap — swaps Slot 1 and Slot 2 potions.
 *
 * Examples:
 *   Slot1=FIRE  Slot2=FREEZE  →  Slot1=FREEZE  Slot2=FIRE
 *   Slot1=FIRE  Slot2=empty   →  Slot1=empty   Slot2=FIRE
 *   Both empty  →  nothing to swap
 */
public class SwapCommand implements CommandExecutor {

    private final PotionSMP plugin;

    public SwapCommand(PotionSMP plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("§cOnly players can use /swap!");
            return true;
        }

        var sm   = plugin.getSlotManager();
        var uid  = player.getUniqueId();

        PotionType s1 = sm.getSlot1(uid);
        PotionType s2 = sm.getSlot2(uid);

        if (s1 == null && s2 == null) {
            player.sendMessage("§cBoth slots are empty — nothing to swap!");
            return true;
        }

        sm.swap(uid);

        PotionType newS1 = sm.getSlot1(uid);
        PotionType newS2 = sm.getSlot2(uid);

        String slot1Name = newS1 != null ? newS1.name() : "Empty";
        String slot2Name = newS2 != null ? newS2.name() : "Empty";

        player.sendMessage("§b🔄 Swapped! §7Slot 1: §f" + slot1Name
            + " §7| Slot 2: §f" + slot2Name);

        // Update action bar instantly
        plugin.getHudManager().sendOnce(player);

        return true;
    }
}
