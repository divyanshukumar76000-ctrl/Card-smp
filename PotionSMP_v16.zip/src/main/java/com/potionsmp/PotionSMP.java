package com.potionsmp;

import com.potionsmp.abilities.*;
import com.potionsmp.commands.*;
import com.potionsmp.hud.HudManager;
import com.potionsmp.listeners.*;
import com.potionsmp.managers.*;
import com.potionsmp.utils.PotionType;
import org.bukkit.plugin.java.JavaPlugin;

public class PotionSMP extends JavaPlugin {

    private static PotionSMP instance;

    private CooldownManager     cooldownManager;
    private HitCounterManager   hitCounterManager;
    private FrozenPlayerManager frozenPlayerManager;
    private FireAuraManager     fireAuraManager;
    private RegenAbilityManager regenAbilityManager;
    private EnderDomainManager  enderDomainManager;
    private AquaDomainManager   aquaDomainManager;
    private ParticleManager     particleManager;
    private GlitchManager       glitchManager;
    private ShieldManager       shieldManager;
    private SlotManager         slotManager;
    private AbilityRegistry     abilityRegistry;
    private HudManager          hudManager;
    private JumpListener        jumpListener;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();

        cooldownManager     = new CooldownManager();
        hitCounterManager   = new HitCounterManager();
        frozenPlayerManager = new FrozenPlayerManager(this);
        fireAuraManager     = new FireAuraManager(this);
        regenAbilityManager = new RegenAbilityManager(this);
        enderDomainManager  = new EnderDomainManager(this);
        aquaDomainManager   = new AquaDomainManager(this);
        particleManager     = new ParticleManager(this);
        glitchManager       = new GlitchManager(this);
        shieldManager       = new ShieldManager(this);
        slotManager         = new SlotManager();
        abilityRegistry     = new AbilityRegistry();
        hudManager          = new HudManager(this);
        jumpListener        = new JumpListener(this);

        var pm = getServer().getPluginManager();
        pm.registerEvents(new DrinkListener(this),  this);
        pm.registerEvents(new CombatListener(this), this);
        pm.registerEvents(jumpListener,              this);
        pm.registerEvents(new GUIListener(this),    this);

        // Abilities that are also listeners
        RegenAbility regenAbility = (RegenAbility) abilityRegistry.get(PotionType.REGEN);
        EnderAbility enderAbility = (EnderAbility) abilityRegistry.get(PotionType.ENDER);
        if (regenAbility != null) regenAbility.register(this);
        if (enderAbility != null) enderAbility.register(this);

        // Commands
        PotionCommand potionCmd = new PotionCommand(this);
        getCommand("potionsmp").setExecutor(potionCmd);
        getCommand("potionsmp").setTabCompleter(potionCmd);
        getCommand("slot1").setExecutor(new SlotCommand(this, SlotManager.SLOT_1));
        getCommand("slot2").setExecutor(new SlotCommand(this, SlotManager.SLOT_2));
        getCommand("swap").setExecutor(new SwapCommand(this));

        hudManager.start();

        getLogger().info("PotionSMP enabled! Potions: Fire, Freeze, Regen, Glitch, Shield, Ender, Teleport, Aqua 🌊");
    }

    @Override
    public void onDisable() {
        frozenPlayerManager.unfreezeAll();
        fireAuraManager.cancelAll();
        enderDomainManager.cancelAll();
        aquaDomainManager.cancelAllDomains();
        particleManager.cancelAll();
        glitchManager.cancelAll();
        shieldManager.cancelAll();
        hudManager.stop();
        getLogger().info("PotionSMP disabled.");
    }

    public static PotionSMP getInstance()                    { return instance; }
    public CooldownManager getCooldownManager()              { return cooldownManager; }
    public HitCounterManager getHitCounterManager()          { return hitCounterManager; }
    public FrozenPlayerManager getFrozenPlayerManager()      { return frozenPlayerManager; }
    public FireAuraManager getFireAuraManager()              { return fireAuraManager; }
    public RegenAbilityManager getRegenAbilityManager()      { return regenAbilityManager; }
    public EnderDomainManager getEnderDomainManager()        { return enderDomainManager; }
    public AquaDomainManager getAquaDomainManager()          { return aquaDomainManager; }
    public SlotManager getSlotManager()                      { return slotManager; }
    public AbilityRegistry getAbilityRegistry()              { return abilityRegistry; }
    public HudManager getHudManager()                        { return hudManager; }
    public ParticleManager getParticleManager()              { return particleManager; }
    public GlitchManager getGlitchManager()                  { return glitchManager; }
    public ShieldManager getShieldManager()                  { return shieldManager; }
    public JumpListener getJumpListener()                    { return jumpListener; }
}
