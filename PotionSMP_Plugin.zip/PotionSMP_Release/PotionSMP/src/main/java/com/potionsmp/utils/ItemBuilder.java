package com.potionsmp.utils;

import org.bukkit.Color;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.potion.PotionEffect;

import java.util.Arrays;
import java.util.List;

public class ItemBuilder {

    public static ItemStack buildPotion(String type) {
        ItemStack item = new ItemStack(Material.POTION);
        PotionMeta meta = (PotionMeta) item.getItemMeta();

        if (type.equals(PotionUtils.FIRE)) {
            meta.setDisplayName(PotionUtils.colorize("&c&l🔥 Fire Potion"));
            meta.setColor(Color.fromRGB(255, 80, 0));
            meta.setCustomModelData(PotionUtils.getFireModelData());
            meta.setLore(List.of(
                PotionUtils.colorize("&7Passive: &fEvery 10 hits ignites enemies"),
                PotionUtils.colorize("&7Active: &c&lInferno Rage"),
                PotionUtils.colorize("&f  5x5 fire zone + fire trail"),
                PotionUtils.colorize("&f  +Fire Resistance for 10s"),
                PotionUtils.colorize("&eDuration: &f10s &7| &eCooldown: &f30s"),
                PotionUtils.colorize(""),
                PotionUtils.colorize("&eRight-Click &fto activate!")
            ));
        } else {
            meta.setDisplayName(PotionUtils.colorize("&b&l❄ Freeze Potion"));
            meta.setColor(Color.fromRGB(0, 180, 255));
            meta.setCustomModelData(PotionUtils.getFreezeModelData());
            meta.setLore(List.of(
                PotionUtils.colorize("&7Passive: &fEvery 10 hits freezes target (1 heart dmg)"),
                PotionUtils.colorize("&7Active: &b&lArctic Prison"),
                PotionUtils.colorize("&f  10-block freeze blast"),
                PotionUtils.colorize("&f  Slowness + Mining Fatigue"),
                PotionUtils.colorize("&eDuration: &f3s &7| &eCooldown: &f45s"),
                PotionUtils.colorize(""),
                PotionUtils.colorize("&eRight-Click &fto activate!")
            ));
        }

        item.setItemMeta(meta);
        return item;
    }
}
