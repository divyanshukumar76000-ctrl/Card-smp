package com.potionsmp.gui;

import com.potionsmp.utils.ItemBuilder;
import com.potionsmp.utils.PotionUtils;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;

public class PotionGUI {

    public static void open(Player player) {
        Inventory gui = Bukkit.createInventory(null, 27,
                Component.text("✨ PotionSMP — Choose Your Potion"));

        // Fill background with gray glass
        ItemStack filler = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta fillerMeta = filler.getItemMeta();
        fillerMeta.displayName(Component.text(" "));
        filler.setItemMeta(fillerMeta);
        for (int i = 0; i < 27; i++) gui.setItem(i, filler);

        // Fire Potion at slot 11
        ItemStack firePotion = ItemBuilder.buildPotion(PotionUtils.FIRE);
        gui.setItem(11, firePotion);

        // Freeze Potion at slot 15
        ItemStack freezePotion = ItemBuilder.buildPotion(PotionUtils.FREEZE);
        gui.setItem(15, freezePotion);

        // Info item at slot 13
        ItemStack info = new ItemStack(Material.NETHER_STAR);
        ItemMeta infoMeta = info.getItemMeta();
        infoMeta.displayName(Component.text(PotionUtils.colorize("&e✨ PotionSMP")));
        infoMeta.lore(List.of(
            Component.text(PotionUtils.colorize("&7Click a potion to receive it!")),
            Component.text(PotionUtils.colorize("&c🔥 Fire &7- Left | &b❄ Freeze &7- Right")),
            Component.text(PotionUtils.colorize("&7Right-Click to activate abilities."))
        ));
        info.setItemMeta(infoMeta);
        gui.setItem(13, info);

        player.openInventory(gui);
    }
}
