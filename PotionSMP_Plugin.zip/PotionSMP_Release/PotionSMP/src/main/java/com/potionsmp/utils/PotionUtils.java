package com.potionsmp.utils;

import com.potionsmp.PotionSMP;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class PotionUtils {

    public static final String FIRE = "fire";
    public static final String FREEZE = "freeze";

    public static int getFireModelData() {
        return PotionSMP.getInstance().getConfig().getInt("fire-potion.custom-model-data", 101);
    }

    public static int getFreezeModelData() {
        return PotionSMP.getInstance().getConfig().getInt("freeze-potion.custom-model-data", 102);
    }

    /**
     * Returns "fire", "freeze", or null
     */
    public static String getPotionType(ItemStack item) {
        if (item == null || item.getType() != Material.POTION) return null;
        if (!item.hasItemMeta()) return null;
        ItemMeta meta = item.getItemMeta();
        if (!meta.hasCustomModelData()) return null;
        int cmd = meta.getCustomModelData();
        if (cmd == getFireModelData()) return FIRE;
        if (cmd == getFreezeModelData()) return FREEZE;
        return null;
    }

    public static boolean isFirePotion(ItemStack item) {
        return FIRE.equals(getPotionType(item));
    }

    public static boolean isFreezePotion(ItemStack item) {
        return FREEZE.equals(getPotionType(item));
    }

    /**
     * Get the potion the player is currently holding (main or off hand)
     */
    public static String getHeldPotionType(org.bukkit.entity.Player player) {
        String type = getPotionType(player.getInventory().getItemInMainHand());
        if (type != null) return type;
        return getPotionType(player.getInventory().getItemInOffHand());
    }

    public static String msg(String key) {
        String raw = PotionSMP.getInstance().getConfig().getString("messages." + key, "&cMissing message: " + key);
        return colorize(raw);
    }

    public static String colorize(String s) {
        return s.replace("&", "\u00a7");
    }
}
