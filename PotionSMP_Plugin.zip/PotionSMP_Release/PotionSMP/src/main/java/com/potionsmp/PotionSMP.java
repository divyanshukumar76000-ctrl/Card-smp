package com.potionsmp;

import com.potionsmp.commands.PotionCommand;
import com.potionsmp.listeners.FirePotionListener;
import com.potionsmp.listeners.FreezePotionListener;
import com.potionsmp.listeners.GUIListener;
import com.potionsmp.managers.CooldownManager;
import com.potionsmp.managers.HitCounterManager;
import com.potionsmp.managers.FrozenPlayerManager;
import com.potionsmp.managers.FireZoneManager;
import org.bukkit.plugin.java.JavaPlugin;

public class PotionSMP extends JavaPlugin {

    private static PotionSMP instance;
    private CooldownManager cooldownManager;
    private HitCounterManager hitCounterManager;
    private FrozenPlayerManager frozenPlayerManager;
    private FireZoneManager fireZoneManager;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();

        // Init managers
        cooldownManager = new CooldownManager();
        hitCounterManager = new HitCounterManager();
        frozenPlayerManager = new FrozenPlayerManager(this);
        fireZoneManager = new FireZoneManager(this);

        // Register listeners
        getServer().getPluginManager().registerEvents(new FreezePotionListener(this), this);
        getServer().getPluginManager().registerEvents(new FirePotionListener(this), this);
        getServer().getPluginManager().registerEvents(new GUIListener(this), this);

        // Register command
        PotionCommand cmd = new PotionCommand(this);
        getCommand("potionsmp").setExecutor(cmd);
        getCommand("potionsmp").setTabCompleter(cmd);

        getLogger().info("PotionSMP enabled! Fire & Freeze potions ready.");
    }

    @Override
    public void onDisable() {
        frozenPlayerManager.unfreezeAll();
        fireZoneManager.cancelAll();
        getLogger().info("PotionSMP disabled.");
    }

    public static PotionSMP getInstance() { return instance; }
    public CooldownManager getCooldownManager() { return cooldownManager; }
    public HitCounterManager getHitCounterManager() { return hitCounterManager; }
    public FrozenPlayerManager getFrozenPlayerManager() { return frozenPlayerManager; }
    public FireZoneManager getFireZoneManager() { return fireZoneManager; }
}
