package com.potionsmp.managers;

import com.potionsmp.PotionSMP;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.*;

public class FireZoneManager {

    private final PotionSMP plugin;
    // player uuid -> list of block locations to clear on expiry
    private final Map<UUID, List<Location>> fireZoneBlocks = new HashMap<>();
    // player uuid -> trail task id
    private final Map<UUID, Integer> trailTasks = new HashMap<>();
    // player uuid -> zone task id
    private final Map<UUID, Integer> zoneTasks = new HashMap<>();

    public FireZoneManager(PotionSMP plugin) {
        this.plugin = plugin;
    }

    public void activateFireZone(Player player, int durationTicks, int radius) {
        UUID uid = player.getUniqueId();
        int cd = plugin.getConfig().getInt("fire-potion.active-cooldown", 30);

        // --- 1. Create 5x5 fire zone ---
        Location center = player.getLocation().clone();
        List<Location> fireBlocks = new ArrayList<>();
        for (int x = -radius; x <= radius; x++) {
            for (int z = -radius; z <= radius; z++) {
                Location blockLoc = center.clone().add(x, 0, z);
                Location ground = getSurface(blockLoc);
                if (ground != null && ground.getBlock().getType() == Material.AIR) {
                    ground.getBlock().setType(Material.FIRE);
                    fireBlocks.add(ground);
                }
            }
        }
        fireZoneBlocks.put(uid, fireBlocks);

        // Damage entities in zone periodically
        BukkitRunnable zoneTask = new BukkitRunnable() {
            int ticks = 0;
            @Override
            public void run() {
                if (ticks >= durationTicks) {
                    clearFireZone(uid);
                    cancel();
                    return;
                }
                if (ticks % 20 == 0) { // every second
                    for (Entity e : center.getWorld().getNearbyEntities(center, radius + 1, 3, radius + 1)) {
                        if (e instanceof LivingEntity le && !e.getUniqueId().equals(uid)) {
                            le.setFireTicks(40);
                        }
                    }
                }
                // zone particle effect
                center.getWorld().spawnParticle(Particle.FLAME, center.clone().add(0, 0.5, 0), 8, radius, 0.5, radius, 0.05);
                ticks++;
            }
        };
        int zoneId = zoneTask.runTaskTimer(plugin, 0L, 1L).getTaskId();
        zoneTasks.put(uid, zoneId);

        // --- 2. Fire trail on player movement ---
        BukkitRunnable trailTask = new BukkitRunnable() {
            int ticks = 0;
            @Override
            public void run() {
                if (ticks >= durationTicks || !player.isOnline()) {
                    cancel();
                    trailTasks.remove(uid);
                    return;
                }
                Location loc = player.getLocation();
                // Particle trail
                player.getWorld().spawnParticle(Particle.FLAME, loc.clone().add(0, 0.1, 0), 5, 0.2, 0, 0.2, 0.02);
                player.getWorld().spawnParticle(Particle.LAVA, loc.clone().add(0, 0.1, 0), 1, 0.1, 0, 0.1, 0);

                // Occasionally place fire blocks on trail
                if (ticks % 10 == 0) {
                    Location trailLoc = getSurface(loc);
                    if (trailLoc != null && trailLoc.getBlock().getType() == Material.AIR) {
                        trailLoc.getBlock().setType(Material.FIRE);
                        List<Location> blocks = fireZoneBlocks.getOrDefault(uid, new ArrayList<>());
                        blocks.add(trailLoc);
                        fireZoneBlocks.put(uid, blocks);
                    }
                }
                ticks++;
            }
        };
        int trailId = trailTask.runTaskTimer(plugin, 0L, 1L).getTaskId();
        trailTasks.put(uid, trailId);
    }

    private void clearFireZone(UUID uid) {
        List<Location> blocks = fireZoneBlocks.remove(uid);
        if (blocks != null) {
            for (Location loc : blocks) {
                if (loc.getBlock().getType() == Material.FIRE) {
                    loc.getBlock().setType(Material.AIR);
                }
            }
        }
        Integer trailId = trailTasks.remove(uid);
        if (trailId != null) plugin.getServer().getScheduler().cancelTask(trailId);
    }

    private Location getSurface(Location loc) {
        Location check = loc.clone();
        // Find the first air block above ground
        for (int i = 0; i < 5; i++) {
            if (check.getBlock().getType() != Material.AIR) {
                check.add(0, 1, 0);
                return check;
            }
            check.subtract(0, 1, 0);
        }
        return loc;
    }

    public void cancelAll() {
        for (UUID uid : new HashSet<>(fireZoneBlocks.keySet())) {
            clearFireZone(uid);
        }
        for (int id : zoneTasks.values()) plugin.getServer().getScheduler().cancelTask(id);
        zoneTasks.clear();
    }
}
