package com.potionsmp.managers;

import com.potionsmp.PotionSMP;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.*;

public class FrozenPlayerManager {

    private final PotionSMP plugin;
    // frozen entity uuid -> their locked location
    private final Map<UUID, Location> frozenEntities = new HashMap<>();
    private final Map<UUID, Integer> frozenTaskIds = new HashMap<>();

    public FrozenPlayerManager(PotionSMP plugin) {
        this.plugin = plugin;
    }

    public void freezeEntity(LivingEntity entity, int durationTicks) {
        UUID uid = entity.getUniqueId();
        Location loc = entity.getLocation().clone();
        frozenEntities.put(uid, loc);

        // Apply debuffs
        int dur = durationTicks + 5;
        entity.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, dur, 254, false, false));
        entity.addPotionEffect(new PotionEffect(PotionEffectType.MINING_FATIGUE, dur, 254, false, false));
        entity.addPotionEffect(new PotionEffect(PotionEffectType.JUMP_BOOST, dur, 128, false, false)); // negative jump

        // Lock position tick-by-tick
        BukkitRunnable lockTask = new BukkitRunnable() {
            int ticks = 0;
            @Override
            public void run() {
                if (ticks >= durationTicks || !entity.isValid()) {
                    unfreeze(entity);
                    cancel();
                    return;
                }
                // Teleport back to frozen location to prevent movement
                if (entity.getLocation().distanceSquared(loc) > 0.1) {
                    entity.teleport(loc);
                }
                // Cancel pearl / velocity
                entity.setVelocity(new org.bukkit.util.Vector(0, 0, 0));

                // Ice particle aura
                entity.getWorld().spawnParticle(Particle.SNOWFLAKE, entity.getLocation().add(0, 1, 0), 6, 0.3, 0.5, 0.3, 0.01);
                entity.getWorld().spawnParticle(Particle.ITEM_SNOWBALL, entity.getLocation().add(0, 0.5, 0), 3, 0.3, 0.3, 0.3, 0);

                ticks++;
            }
        };
        int taskId = lockTask.runTaskTimer(plugin, 0L, 1L).getTaskId();
        frozenTaskIds.put(uid, taskId);
    }

    public void unfreeze(LivingEntity entity) {
        UUID uid = entity.getUniqueId();
        frozenEntities.remove(uid);
        Integer taskId = frozenTaskIds.remove(uid);
        if (taskId != null) plugin.getServer().getScheduler().cancelTask(taskId);
        entity.removePotionEffect(PotionEffectType.SLOWNESS);
        entity.removePotionEffect(PotionEffectType.MINING_FATIGUE);
        entity.removePotionEffect(PotionEffectType.JUMP_BOOST);
    }

    public boolean isFrozen(UUID uid) {
        return frozenEntities.containsKey(uid);
    }

    public void unfreezeAll() {
        for (int id : frozenTaskIds.values()) {
            plugin.getServer().getScheduler().cancelTask(id);
        }
        frozenEntities.clear();
        frozenTaskIds.clear();
    }
}
