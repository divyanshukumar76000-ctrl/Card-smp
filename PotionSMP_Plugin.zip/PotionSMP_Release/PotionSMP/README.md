# 🧪 PotionSMP Plugin

A custom Fire 🔥 and Freeze ❄️ Potion plugin for PaperMC / Spigot 1.21.1 (Java 21).

---

## 📦 Building the Plugin

Requirements:
- Java 21+
- Maven 3.8+

```bash
cd PotionSMP
mvn clean package
```

The compiled `.jar` will be at:
```
target/PotionSMP.jar
```

Drop it into your server's `plugins/` folder.

---

## 🗂️ Texture Pack

The `CustomPotions_SMP_TexturePack.zip` is already included.

1. Put the zip into `server-root/resource_packs/`
2. Or host it and set in `server.properties`:
   ```
   resource-pack=https://yourhost.com/CustomPotions_SMP_TexturePack.zip
   ```

---

## 🎮 Commands

| Command | Description |
|---|---|
| `/potionSMP` | Open potion GUI (pick Fire or Freeze) |
| `/potionSMP give fire [player]` | Give Fire Potion (op only) |
| `/potionSMP give freeze [player]` | Give Freeze Potion (op only) |

Aliases: `/psmp`, `/potion`

---

## 🔥 Fire Potion — Inferno Rage

**CustomModelData: 101** (linked to texture pack)

| | |
|---|---|
| **Passive** | Every 10 hits: ignites target + nearby enemies in 3-block radius |
| **Active** | Right-click → 5×5 fire zone on ground, fire trail while moving, fire resistance for self |
| **Duration** | 10 seconds |
| **Cooldown** | 30 seconds |

---

## ❄️ Freeze Potion — Arctic Prison

**CustomModelData: 102** (linked to texture pack)

| | |
|---|---|
| **Passive** | Every 10 hits: deals 1 extra heart + briefly freezes target (2s) |
| **Active** | Right-click → 10-block radius freeze blast, all enemies frozen 3s (Slowness + Mining Fatigue, locked in place) |
| **Duration** | 3 seconds freeze |
| **Cooldown** | 45 seconds |

---

## ⚙️ config.yml

All values are configurable in `plugins/PotionSMP/config.yml`:
- Cooldowns, durations, radii, hit thresholds, custom model data IDs, messages.

---

## 🔗 Texture Pack Connection

The potions use `CustomModelData` to match the texture pack:
- Fire Potion → `custom-model-data: 101` → `fire_potion.png`
- Freeze Potion → `custom-model-data: 102` → `freeze_potion.png`

When you give a potion via `/potionSMP give` or the GUI, the item automatically has the correct model data set so it shows the custom texture in-game.

---

## 📋 Permissions

| Permission | Default | Description |
|---|---|---|
| `potionsmp.use` | true (everyone) | Open GUI, use potions |
| `potionsmp.give` | op only | Give potions to players |
