package mwgameryt._73669.cardsmp.abilities;

import mwgameryt._73669.cardsmp.CardSMPPlugin;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;

/**
 * Time Card Ability
 * Freezes all entities within 50 blocks for 15 seconds
 * Creates temporal ring and spiral particle effects
 */
public class TimeCardAbility implements CardAbility {

    private final CardSMPPlugin plugin;
    private final Map<UUID, BukkitTask> activeTasks;
    private final Map<UUID, List<UUID>> frozenEntitiesByPlayer;

    public TimeCardAbility(CardSMPPlugin plugin) {
        this.plugin = plugin;
        this.activeTasks = new HashMap<>();
        this.frozenEntitiesByPlayer = new HashMap<>();
    }

    @Override
    public void activate(Player player) {
        int radius = plugin.getConfig().getInt("cards.time.radius", 50);
        int duration = plugin.getConfig().getInt("cards.time.duration", 15);

        Location center = player.getLocation();
        List<Entity> nearbyEntities = player.getNearbyEntities(radius, radius, radius);
        List<UUID> frozenUUIDs = new ArrayList<>();

        // Freeze all entities except the caster
        for (Entity entity : nearbyEntities) {
            if (entity.equals(player)) {
                continue;
            }

            plugin.getFreezeManager().freezeEntity(entity);
            frozenUUIDs.add(entity.getUniqueId());
        }

        frozenEntitiesByPlayer.put(player.getUniqueId(), frozenUUIDs);

        // Start particle effects
        BukkitTask particleTask = new BukkitRunnable() {
            int ticks = 0;
            final int maxTicks = duration * 20;
            double angle = 0;

            @Override
            public void run() {
                if (ticks >= maxTicks || !player.isOnline()) {
                    unfreezeAll(player);
                    cancel();
                    return;
                }

                Location playerLoc = player.getLocation();

                // Temporal ring effect
                plugin.getParticleManager().spawnRing(
                    playerLoc.clone().add(0, 1, 0),
                    radius * 0.8,
                    Particle.END_ROD,
                    30
                );

                // Spiral effect
                plugin.getParticleManager().spawnSpiral(
                    playerLoc.clone(),
                    3.0,
                    5.0,
                    Particle.ENCHANT,
                    2,
                    5
                );

                // Floating particles
                if (ticks % 5 == 0) {
                    for (int i = 0; i < 10; i++) {
                        double x = playerLoc.getX() + (Math.random() - 0.5) * radius;
                        double y = playerLoc.getY() + Math.random() * 3;
                        double z = playerLoc.getZ() + (Math.random() - 0.5) * radius;
                        
                        Location particleLoc = new Location(playerLoc.getWorld(), x, y, z);
                        playerLoc.getWorld().spawnParticle(Particle.WHITE_ASH, particleLoc, 1, 0, 0, 0, 0);
                    }
                }

                angle += 0.2;
                ticks++;
            }
        }.runTaskTimer(plugin, 0L, 1L);

        activeTasks.put(player.getUniqueId(), particleTask);
    }

    /**
     * Unfreeze all entities frozen by this player
     */
    private void unfreezeAll(Player player) {
        UUID playerUUID = player.getUniqueId();
        List<UUID> frozenUUIDs = frozenEntitiesByPlayer.remove(playerUUID);
        
        if (frozenUUIDs == null) {
            return;
        }

        // Unfreeze all entities
        player.getWorld().getEntities().forEach(entity -> {
            if (frozenUUIDs.contains(entity.getUniqueId())) {
                plugin.getFreezeManager().unfreezeEntity(entity);
            }
        });

        // Cancel particle task
        BukkitTask task = activeTasks.remove(playerUUID);
        if (task != null) {
            task.cancel();
        }
    }

    @Override
    public String getId() {
        return "time";
    }

    @Override
    public long getCooldown() {
        return plugin.getConfig().getLong("cards.time.cooldown", 60) * 1000;
    }

    @Override
    public void cleanup(Player player) {
        unfreezeAll(player);
    }
}
