package mwgameryt._73669.cardsmp.abilities;

import mwgameryt._73669.cardsmp.CardSMPPlugin;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Thunder Card Ability
 * Creates a lightning storm around the player for 10 seconds
 * Strikes lightning every 5 ticks with electric particles
 */
public class ThunderCardAbility implements CardAbility {

    private final CardSMPPlugin plugin;
    private final Map<UUID, BukkitTask> activeTasks;
    private final Map<UUID, Long> activeCasters; // Track active thunder card users

    public ThunderCardAbility(CardSMPPlugin plugin) {
        this.plugin = plugin;
        this.activeTasks = new HashMap<>();
        this.activeCasters = new HashMap<>();
    }

    @Override
    public void activate(Player player) {
        int duration = plugin.getConfig().getInt("cards.thunder.duration", 10);
        double radius = plugin.getConfig().getDouble("cards.thunder.radius", 10.0);
        int strikeInterval = plugin.getConfig().getInt("cards.thunder.strike-interval", 5);

        Location center = player.getLocation();

        // Track caster for immunity
        activeCasters.put(player.getUniqueId(), System.currentTimeMillis() + (duration * 1000L));
        
        BukkitTask task = new BukkitRunnable() {
            int ticks = 0;
            final int maxTicks = duration * 20;

            @Override
            public void run() {
                if (ticks >= maxTicks || !player.isOnline()) {
                    activeTasks.remove(player.getUniqueId());
                    activeCasters.remove(player.getUniqueId());
                    cancel();
                    return;
                }

                Location playerLoc = player.getLocation();

                // Strike REAL lightning every tick (as specified: 1 time per tick)
                if (ticks % 1 == 0) {
                    // Random location within radius
                    double angle = Math.random() * 2 * Math.PI;
                    double distance = Math.random() * radius;
                    
                    double x = playerLoc.getX() + distance * Math.cos(angle);
                    double z = playerLoc.getZ() + distance * Math.sin(angle);
                    
                    Location strikeLoc = new Location(playerLoc.getWorld(), x, playerLoc.getY(), z);
                    
                    // Get highest block
                    strikeLoc.setY(strikeLoc.getWorld().getHighestBlockYAt(strikeLoc));
                    
                    // Strike REAL lightning (inflicts vanilla damage, fire, knockback)
                    // Caster is immune (handled by event listener if needed)
                    playerLoc.getWorld().strikeLightning(strikeLoc);

                    // Electric spark particles
                    for (int i = 0; i < 10; i++) {
                        double offsetX = (Math.random() - 0.5) * 2;
                        double offsetY = Math.random() * 3;
                        double offsetZ = (Math.random() - 0.5) * 2;
                        
                        Location particleLoc = strikeLoc.clone().add(offsetX, offsetY, offsetZ);
                        playerLoc.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, particleLoc, 1, 0, 0, 0, 0);
                    }
                }

                // Ambient storm particles every 5 ticks
                if (ticks % 5 == 0) {
                    // Cloud particles in sky
                    for (int i = 0; i < 5; i++) {
                        double x = playerLoc.getX() + (Math.random() - 0.5) * radius * 2;
                        double y = playerLoc.getY() + 10 + Math.random() * 5;
                        double z = playerLoc.getZ() + (Math.random() - 0.5) * radius * 2;
                        
                        Location cloudLoc = new Location(playerLoc.getWorld(), x, y, z);
                        playerLoc.getWorld().spawnParticle(Particle.CLOUD, cloudLoc, 1, 0.5, 0.1, 0.5, 0);
                    }

                    // Flash particles
                    plugin.getParticleManager().spawnCircle(
                        playerLoc.clone().add(0, 10, 0),
                        radius * 0.5,
                        Particle.FLASH,
                        8
                    );

                    // Electric sparks around player
                    for (int i = 0; i < 3; i++) {
                        double offsetX = (Math.random() - 0.5) * 3;
                        double offsetY = Math.random() * 2;
                        double offsetZ = (Math.random() - 0.5) * 3;
                        
                        Location sparkLoc = playerLoc.clone().add(offsetX, offsetY, offsetZ);
                        playerLoc.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, sparkLoc, 1, 0, 0, 0, 0);
                    }
                }

                ticks++;
            }
        }.runTaskTimer(plugin, 0L, 1L);

        activeTasks.put(player.getUniqueId(), task);
    }

    @Override
    public String getId() {
        return "thunder";
    }

    @Override
    public long getCooldown() {
        return plugin.getConfig().getLong("cards.thunder.cooldown", 30) * 1000;
    }

    @Override
    public void cleanup(Player player) {
        BukkitTask task = activeTasks.remove(player.getUniqueId());
        if (task != null) {
            task.cancel();
        }
        activeCasters.remove(player.getUniqueId());
    }
    
    /**
     * Check if a player is currently casting Thunder Card
     */
    public boolean isActiveCaster(Player player) {
        Long endTime = activeCasters.get(player.getUniqueId());
        if (endTime == null) return false;
        
        if (System.currentTimeMillis() > endTime) {
            activeCasters.remove(player.getUniqueId());
            return false;
        }
        
        return true;
    }
}
