package mwgameryt._73669.cardsmp.abilities;

import mwgameryt._73669.cardsmp.CardSMPPlugin;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;

/**
 * Glitch Card Ability
 * Forces nearby players to drop their held item every second for 30 seconds
 * Creates glitchy particle effects
 */
public class GlitchCardAbility implements CardAbility {

    private final CardSMPPlugin plugin;
    private final Map<UUID, BukkitTask> activeTasks;
    private final Map<UUID, Set<UUID>> droppedThisCycle;

    public GlitchCardAbility(CardSMPPlugin plugin) {
        this.plugin = plugin;
        this.activeTasks = new HashMap<>();
        this.droppedThisCycle = new HashMap<>();
    }

    @Override
    public void activate(Player player) {
        int duration = plugin.getConfig().getInt("cards.glitch.duration", 30);
        double radius = plugin.getConfig().getDouble("cards.glitch.radius", 15.0);

        Set<UUID> dropped = new HashSet<>();
        droppedThisCycle.put(player.getUniqueId(), dropped);

        BukkitTask task = new BukkitRunnable() {
            int ticks = 0;
            final int maxTicks = duration * 20;
            int dropCycle = 0;

            @Override
            public void run() {
                if (ticks >= maxTicks || !player.isOnline()) {
                    droppedThisCycle.remove(player.getUniqueId());
                    activeTasks.remove(player.getUniqueId());
                    cancel();
                    return;
                }

                Location center = player.getLocation();

                // Force item drop every second (20 ticks)
                if (ticks % 20 == 0) {
                    dropCycle++;
                    Set<UUID> droppedSet = droppedThisCycle.get(player.getUniqueId());
                    droppedSet.clear();

                    Collection<Player> nearbyPlayers = center.getWorld().getNearbyPlayers(center, radius);
                    
                    for (Player target : nearbyPlayers) {
                        if (target.equals(player)) {
                            continue; // Don't affect caster
                        }

                        UUID targetUUID = target.getUniqueId();
                        
                        // Check if already dropped this cycle
                        if (droppedSet.contains(targetUUID)) {
                            continue;
                        }

                        ItemStack heldItem = target.getInventory().getItemInMainHand();
                        
                        if (heldItem != null && !heldItem.getType().isAir()) {
                            // Drop the item
                            target.getWorld().dropItemNaturally(target.getLocation(), heldItem.clone());
                            target.getInventory().setItemInMainHand(null);
                            
                            droppedSet.add(targetUUID);

                            // Glitch particles around target
                            for (int i = 0; i < 5; i++) {
                                double offsetX = (Math.random() - 0.5) * 2;
                                double offsetY = Math.random() * 2;
                                double offsetZ = (Math.random() - 0.5) * 2;
                                
                                Location particleLoc = target.getLocation().add(offsetX, offsetY, offsetZ);
                                target.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, particleLoc, 1, 0, 0, 0, 0);
                            }
                        }
                    }
                }

                // Ambient glitch particles
                if (ticks % 5 == 0) {
                    Collection<Player> nearbyPlayers = center.getWorld().getNearbyPlayers(center, radius);
                    
                    for (Player target : nearbyPlayers) {
                        if (target.equals(player)) {
                            continue;
                        }

                        Location targetLoc = target.getLocation();
                        
                        // Random glitch particles
                        for (int i = 0; i < 2; i++) {
                            double offsetX = (Math.random() - 0.5) * 1.5;
                            double offsetY = Math.random() * 2;
                            double offsetZ = (Math.random() - 0.5) * 1.5;
                            
                            Location particleLoc = targetLoc.clone().add(offsetX, offsetY, offsetZ);
                            targetLoc.getWorld().spawnParticle(Particle.CRIT, particleLoc, 1, 0, 0, 0, 0);
                        }
                    }
                }

                ticks++;
            }
        }.runTaskTimer(plugin, 0L, 1L);

        activeTasks.put(player.getUniqueId(), task);
    }

    @Override
    public String getId() {
        return "glitch";
    }

    @Override
    public long getCooldown() {
        return plugin.getConfig().getLong("cards.glitch.cooldown", 45) * 1000;
    }

    @Override
    public void cleanup(Player player) {
        BukkitTask task = activeTasks.remove(player.getUniqueId());
        if (task != null) {
            task.cancel();
        }
        droppedThisCycle.remove(player.getUniqueId());
    }
}
