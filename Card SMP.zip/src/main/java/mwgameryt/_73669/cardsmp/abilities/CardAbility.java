package mwgameryt._73669.cardsmp.abilities;

import org.bukkit.entity.Player;

/**
 * Interface defining the contract for all card abilities
 * Ensures consistent implementation across all card types
 */
public interface CardAbility {
    
    /**
     * Activate the card ability for the specified player
     * 
     * @param player The player activating the ability
     */
    void activate(Player player);
    
    /**
     * Get the unique identifier for this ability
     * 
     * @return The ability ID
     */
    String getId();
    
    /**
     * Get the cooldown duration in milliseconds
     * 
     * @return Cooldown duration
     */
    long getCooldown();
    
    /**
     * Cleanup method called when plugin disables or player disconnects
     * Should cancel any running tasks and remove entities
     * 
     * @param player The player to cleanup for
     */
    default void cleanup(Player player) {
        // Default implementation - can be overridden
    }
}
