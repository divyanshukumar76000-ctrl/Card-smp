package mwgameryt._73669.cardsmp.abilities;

import mwgameryt._73669.cardsmp.CardSMPPlugin;
import mwgameryt._73669.cardsmp.model.CardType;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;

/**
 * Demon Card Ability
 * Passive: 5 orbiting ItemDisplays showing random cards
 * Active: Randomly casts one of the orbiting card abilities
 */
public class DemonCardAbility implements CardAbility {

    private final CardSMPPlugin plugin;
    private final Map<UUID, BukkitTask> particleTasks;
    private final Random random;

    public DemonCardAbility(CardSMPPlugin plugin) {
        this.plugin = plugin;
        this.particleTasks = new HashMap<>();
        this.random = new Random();
    }

    @Override
    public void activate(Player player) {
        // Get all available card types except Demon and Revival
        List<CardType> availableCards = new ArrayList<>(Arrays.asList(CardType.values()));
        availableCards.remove(CardType.DEMON);
        availableCards.remove(CardType.REVIVAL);

        if (availableCards.isEmpty()) {
            return;
        }

        // Randomly select a card ability to cast (1-5)
        CardType randomCard = availableCards.get(random.nextInt(availableCards.size()));
        CardAbility ability = plugin.getAbilityManager().getAbility(randomCard.getAbilityId());

        if (ability == null) {
            return;
        }

        // Send message
        player.sendMessage(Component.text("Demon Card activates: ")
            .color(NamedTextColor.DARK_RED)
            .append(Component.text(randomCard.getDisplayName())
                .color(NamedTextColor.RED)));

        // Cast the random ability
        ability.activate(player);

        Location loc = player.getLocation();
        
        // Vertical beam effect (3 seconds)
        new BukkitRunnable() {
            int tick = 0;
            
            @Override
            public void run() {
                if (!player.isOnline() || tick >= 60) { // 3 seconds = 60 ticks
                    cancel();
                    return;
                }
                
                Location beamLoc = player.getLocation();
                
                // Vertical beam particles
                for (int y = 0; y < 30; y++) {
                    Location particleLoc = beamLoc.clone().add(0, y * 0.3, 0);
                    
                    if (tick % 2 == 0) {
                        beamLoc.getWorld().spawnParticle(Particle.END_ROD, particleLoc, 1, 0.1, 0, 0.1, 0);
                    }
                    if (tick % 3 == 0) {
                        beamLoc.getWorld().spawnParticle(Particle.SOUL_FIRE_FLAME, particleLoc, 1, 0.05, 0, 0.05, 0);
                    }
                    if (y % 5 == 0) {
                        beamLoc.getWorld().spawnParticle(Particle.REVERSE_PORTAL, particleLoc, 2, 0.1, 0.1, 0.1, 0);
                    }
                }
                
                // Flash particle occasionally
                if (tick % 10 == 0) {
                    beamLoc.getWorld().spawnParticle(Particle.FLASH, beamLoc.clone().add(0, 15, 0), 1, 0, 0, 0, 0);
                }
                
                tick++;
            }
        }.runTaskTimer(plugin, 0L, 1L);
        
        // Visual Earthquake effect (3 seconds)
        new BukkitRunnable() {
            int tick = 0;
            
            @Override
            public void run() {
                if (!player.isOnline() || tick >= 60) { // 3 seconds
                    cancel();
                    return;
                }
                
                Location earthquakeLoc = player.getLocation();
                
                // Ground crack particles (stone and dirt)
                for (int i = 0; i < 8; i++) {
                    double angle = random.nextDouble() * 2 * Math.PI;
                    double distance = random.nextDouble() * 3;
                    double x = earthquakeLoc.getX() + distance * Math.cos(angle);
                    double z = earthquakeLoc.getZ() + distance * Math.sin(angle);
                    
                    Location crackLoc = new Location(earthquakeLoc.getWorld(), x, earthquakeLoc.getY(), z);
                    earthquakeLoc.getWorld().spawnParticle(Particle.BLOCK, crackLoc, 3, 0.2, 0.1, 0.2, 0, Material.STONE.createBlockData());
                    earthquakeLoc.getWorld().spawnParticle(Particle.BLOCK, crackLoc, 2, 0.2, 0.1, 0.2, 0, Material.DIRT.createBlockData());
                }
                
                // Smoke and ash
                if (tick % 3 == 0) {
                    for (int i = 0; i < 5; i++) {
                        double offsetX = (random.nextDouble() - 0.5) * 4;
                        double offsetZ = (random.nextDouble() - 0.5) * 4;
                        Location smokeLoc = earthquakeLoc.clone().add(offsetX, 0.1, offsetZ);
                        
                        earthquakeLoc.getWorld().spawnParticle(Particle.SMOKE, smokeLoc, 1, 0.1, 0.2, 0.1, 0.02);
                        earthquakeLoc.getWorld().spawnParticle(Particle.WHITE_SMOKE, smokeLoc, 1, 0.1, 0.1, 0.1, 0.01);
                    }
                }
                
                // Minecart rumbling sound
                if (tick % 10 == 0) {
                    player.playSound(earthquakeLoc, org.bukkit.Sound.ENTITY_MINECART_RIDING, 0.5f, 0.5f);
                }
                
                // Lava drip particles occasionally
                if (tick % 5 == 0 && random.nextBoolean()) {
                    Location lavaLoc = earthquakeLoc.clone().add(
                        (random.nextDouble() - 0.5) * 3,
                        0,
                        (random.nextDouble() - 0.5) * 3
                    );
                    earthquakeLoc.getWorld().spawnParticle(Particle.DRIPPING_LAVA, lavaLoc, 2, 0.5, 0, 0.5, 0);
                }
                
                tick++;
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    /**
     * Start passive particle effects for orbiting displays
     * Called when displays are created
     */
    public void startPassiveParticles(Player player) {
        UUID uuid = player.getUniqueId();

        // Cancel existing task if any
        BukkitTask existing = particleTasks.remove(uuid);
        if (existing != null) {
            existing.cancel();
        }

        double radius = plugin.getConfig().getDouble("cards.demon.orbit-radius", 2.5);

        BukkitTask task = new BukkitRunnable() {
            double angle = 0;

            @Override
            public void run() {
                if (!player.isOnline() || !plugin.getDisplayManager().hasDisplays(player)) {
                    particleTasks.remove(uuid);
                    cancel();
                    return;
                }

                Location center = player.getLocation().add(0, 1.5, 0);

                // Spawn particles at orbit positions
                for (int i = 0; i < 5; i++) {
                    double currentAngle = angle + (i * 2 * Math.PI / 5);
                    double x = center.getX() + radius * Math.cos(currentAngle);
                    double z = center.getZ() + radius * Math.sin(currentAngle);
                    
                    Location particleLoc = new Location(center.getWorld(), x, center.getY(), z);

                    // Flame particles
                    center.getWorld().spawnParticle(Particle.FLAME, particleLoc, 1, 0.05, 0.05, 0.05, 0);
                    
                    // Occasional soul fire
                    if (random.nextInt(3) == 0) {
                        center.getWorld().spawnParticle(Particle.SOUL_FIRE_FLAME, particleLoc, 1, 0.05, 0.05, 0.05, 0);
                    }
                    
                    // Occasional crimson spore
                    if (random.nextInt(5) == 0) {
                        center.getWorld().spawnParticle(Particle.CRIMSON_SPORE, particleLoc, 1, 0.05, 0.05, 0.05, 0);
                    }
                }

                angle += 0.1;
                if (angle >= 2 * Math.PI) {
                    angle -= 2 * Math.PI;
                }
            }
        }.runTaskTimer(plugin, 0L, 5L); // Update every 5 ticks for performance

        particleTasks.put(uuid, task);
    }

    /**
     * Stop passive particle effects
     */
    public void stopPassiveParticles(Player player) {
        BukkitTask task = particleTasks.remove(player.getUniqueId());
        if (task != null) {
            task.cancel();
        }
    }

    @Override
    public String getId() {
        return "demon";
    }

    @Override
    public long getCooldown() {
        return plugin.getConfig().getLong("cards.demon.cooldown", 60) * 1000;
    }

    @Override
    public void cleanup(Player player) {
        stopPassiveParticles(player);
    }
}
