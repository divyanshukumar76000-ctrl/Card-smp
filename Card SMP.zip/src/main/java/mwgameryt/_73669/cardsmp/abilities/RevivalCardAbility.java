package mwgameryt._73669.cardsmp.abilities;

import mwgameryt._73669.cardsmp.CardSMPPlugin;
import mwgameryt._73669.cardsmp.gui.RevivalGUI;
import org.bukkit.entity.Player;

/**
 * Revival Card Ability
 * Opens GUI to select banned players for unbanning ritual
 * Performs 60-second ritual with particle effects
 */
public class RevivalCardAbility implements CardAbility {

    private final CardSMPPlugin plugin;

    public RevivalCardAbility(CardSMPPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public void activate(Player player) {
        // Open revival GUI
        new RevivalGUI(plugin, player).open();
    }

    @Override
    public String getId() {
        return "revival";
    }

    @Override
    public long getCooldown() {
        return 0L; // No cooldown, card is consumed on use
    }

    @Override
    public void cleanup(Player player) {
        // No persistent effects to cleanup
    }
}
