package mwgameryt._73669.cardsmp.abilities;

import mwgameryt._73669.cardsmp.CardSMPPlugin;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Gravity Card Ability
 * Creates a black hole that pulls entities and items
 * Ends with an explosion after 5 seconds
 */
public class GravityCardAbility implements CardAbility {

    private final CardSMPPlugin plugin;
    private final Map<UUID, BukkitTask> activeTasks;

    public GravityCardAbility(CardSMPPlugin plugin) {
        this.plugin = plugin;
        this.activeTasks = new HashMap<>();
    }

    @Override
    public void activate(Player player) {
        int duration = plugin.getConfig().getInt("cards.gravity.duration", 5);
        double radius = plugin.getConfig().getDouble("cards.gravity.radius", 8.0);
        double pullStrength = plugin.getConfig().getDouble("cards.gravity.pull-strength", 1.5);
        float explosionPower = (float) plugin.getConfig().getDouble("cards.gravity.explosion-power", 2.0);

        Location blackHoleCenter = player.getLocation().add(0, 2, 0);

        BukkitTask task = new BukkitRunnable() {
            int ticks = 0;
            final int maxTicks = duration * 20;

            @Override
            public void run() {
                if (ticks >= maxTicks || !player.isOnline()) {
                    // Create explosion
                    blackHoleCenter.getWorld().createExplosion(blackHoleCenter, explosionPower, false, false);
                    
                    activeTasks.remove(player.getUniqueId());
                    cancel();
                    return;
                }

                // Pull entities toward black hole
                List<Entity> nearbyEntities = blackHoleCenter.getWorld().getNearbyEntities(blackHoleCenter, radius, radius, radius)
                    .stream().toList();

                for (Entity entity : nearbyEntities) {
                    if (entity.equals(player)) {
                        continue;
                    }

                    // Calculate pull vector
                    Vector direction = blackHoleCenter.toVector().subtract(entity.getLocation().toVector());
                    double distance = direction.length();
                    
                    if (distance < 0.5) {
                        continue; // Too close to center
                    }

                    // Normalize and apply strength with distance falloff
                    direction.normalize();
                    double strength = pullStrength * (1.0 - (distance / radius));
                    direction.multiply(strength);

                    // Clamp velocity
                    Vector currentVel = entity.getVelocity();
                    Vector newVel = currentVel.add(direction);
                    
                    if (newVel.length() > pullStrength) {
                        newVel.normalize().multiply(pullStrength);
                    }

                    entity.setVelocity(newVel);
                }

                // Spawn particles every 5 ticks
                if (ticks % 5 == 0) {
                    // Black hole core
                    plugin.getParticleManager().spawnSphere(
                        blackHoleCenter,
                        1.0,
                        Particle.SQUID_INK,
                        20
                    );

                    // Portal effect
                    plugin.getParticleManager().spawnCircle(
                        blackHoleCenter,
                        radius * 0.5,
                        Particle.PORTAL,
                        25
                    );

                    // Dragon breath spiral
                    plugin.getParticleManager().spawnSpiral(
                        blackHoleCenter.clone().subtract(0, 2, 0),
                        radius * 0.3,
                        4.0,
                        Particle.DRAGON_BREATH,
                        2,
                        8
                    );
                }

                ticks++;
            }
        }.runTaskTimer(plugin, 0L, 1L);

        activeTasks.put(player.getUniqueId(), task);
    }

    @Override
    public String getId() {
        return "gravity";
    }

    @Override
    public long getCooldown() {
        return plugin.getConfig().getLong("cards.gravity.cooldown", 45) * 1000;
    }

    @Override
    public void cleanup(Player player) {
        BukkitTask task = activeTasks.remove(player.getUniqueId());
        if (task != null) {
            task.cancel();
        }
    }
}
