package mwgameryt._73669.cardsmp.abilities;

import mwgameryt._73669.cardsmp.CardSMPPlugin;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Soul Card Ability
 * Grants 10 seconds of immunity
 * Stores all damage taken and applies it afterward
 */
public class SoulCardAbility implements CardAbility {

    private final CardSMPPlugin plugin;
    private final Map<UUID, Double> storedDamage;
    private final Map<UUID, BukkitTask> activeTasks;
    private final Map<UUID, Long> immunityExpiry;

    public SoulCardAbility(CardSMPPlugin plugin) {
        this.plugin = plugin;
        this.storedDamage = new HashMap<>();
        this.activeTasks = new HashMap<>();
        this.immunityExpiry = new HashMap<>();
    }

    @Override
    public void activate(Player player) {
        int duration = plugin.getConfig().getInt("cards.soul.duration", 10);

        // Initialize stored damage
        storedDamage.put(player.getUniqueId(), 0.0);
        immunityExpiry.put(player.getUniqueId(), System.currentTimeMillis() + (duration * 1000L));

        BukkitTask task = new BukkitRunnable() {
            int ticks = 0;
            final int maxTicks = duration * 20;

            @Override
            public void run() {
                if (ticks >= maxTicks || !player.isOnline()) {
                    // Apply stored damage
                    applyStoredDamage(player);
                    
                    immunityExpiry.remove(player.getUniqueId());
                    activeTasks.remove(player.getUniqueId());
                    cancel();
                    return;
                }

                Location playerLoc = player.getLocation();

                // Soul particles every 2 ticks
                if (ticks % 2 == 0) {
                    // Soul aura
                    plugin.getParticleManager().spawnCircle(
                        playerLoc.clone().add(0, 1, 0),
                        1.5,
                        Particle.SOUL,
                        12
                    );

                    // Soul fire flames
                    for (int i = 0; i < 3; i++) {
                        double offsetX = (Math.random() - 0.5) * 1.5;
                        double offsetY = Math.random() * 2;
                        double offsetZ = (Math.random() - 0.5) * 1.5;
                        
                        Location flameLoc = playerLoc.clone().add(offsetX, offsetY, offsetZ);
                        playerLoc.getWorld().spawnParticle(Particle.SOUL_FIRE_FLAME, flameLoc, 1, 0, 0.1, 0, 0.01);
                    }

                    // Sculk soul particles
                    if (ticks % 10 == 0) {
                        plugin.getParticleManager().spawnSphere(
                            playerLoc.clone().add(0, 1, 0),
                            2.0,
                            Particle.SCULK_SOUL,
                            8
                        );
                    }
                }

                // Display stored damage every second
                if (ticks % 20 == 0) {
                    double damage = storedDamage.getOrDefault(player.getUniqueId(), 0.0);
                    player.sendActionBar(
                        Component.text("Immunity Active | Stored Damage: ")
                            .color(NamedTextColor.AQUA)
                            .append(Component.text(String.format("%.1f", damage))
                                .color(NamedTextColor.RED))
                    );
                }

                ticks++;
            }
        }.runTaskTimer(plugin, 0L, 1L);

        activeTasks.put(player.getUniqueId(), task);
    }

    /**
     * Check if a player is immune
     */
    public boolean isImmune(Player player) {
        Long expiry = immunityExpiry.get(player.getUniqueId());
        if (expiry == null) {
            return false;
        }
        
        return System.currentTimeMillis() < expiry;
    }

    /**
     * Add damage to stored damage
     */
    public void addStoredDamage(Player player, double damage) {
        UUID uuid = player.getUniqueId();
        double current = storedDamage.getOrDefault(uuid, 0.0);
        storedDamage.put(uuid, current + damage);
    }

    /**
     * Apply all stored damage to the player
     */
    private void applyStoredDamage(Player player) {
        UUID uuid = player.getUniqueId();
        Double damage = storedDamage.remove(uuid);
        
        if (damage == null || damage <= 0) {
            player.sendMessage(Component.text("Soul immunity ended. No damage taken!")
                .color(NamedTextColor.GREEN));
            return;
        }

        // Apply the damage
        player.damage(damage);
        
        player.sendMessage(Component.text("Soul immunity ended! Applying stored damage: ")
            .color(NamedTextColor.RED)
            .append(Component.text(String.format("%.1f", damage))
                .color(NamedTextColor.DARK_RED)));
    }

    @Override
    public String getId() {
        return "soul";
    }

    @Override
    public long getCooldown() {
        return plugin.getConfig().getLong("cards.soul.cooldown", 40) * 1000;
    }

    @Override
    public void cleanup(Player player) {
        BukkitTask task = activeTasks.remove(player.getUniqueId());
        if (task != null) {
            task.cancel();
        }
        
        // Don't apply damage on cleanup, just remove immunity
        storedDamage.remove(player.getUniqueId());
        immunityExpiry.remove(player.getUniqueId());
    }
}
