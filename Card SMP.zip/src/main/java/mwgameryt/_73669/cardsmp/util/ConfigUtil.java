package mwgameryt._73669.cardsmp.util;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.plugin.Plugin;

/**
 * Utility class for configuration management
 */
public class ConfigUtil {

    private final Plugin plugin;
    private final LegacyComponentSerializer serializer;

    public ConfigUtil(Plugin plugin) {
        this.plugin = plugin;
        this.serializer = LegacyComponentSerializer.legacyAmpersand();
    }

    /**
     * Get a message from config with prefix
     */
    public Component getMessage(String path) {
        FileConfiguration config = plugin.getConfig();
        String prefix = config.getString("messages.prefix", "&8[&6Card SMP&8]&r ");
        String message = config.getString("messages." + path, "&cMessage not found: " + path);
        return serializer.deserialize(prefix + message);
    }

    /**
     * Get a message with placeholder replacement
     */
    public Component getMessage(String path, String placeholder, String value) {
        FileConfiguration config = plugin.getConfig();
        String prefix = config.getString("messages.prefix", "&8[&6Card SMP&8]&r ");
        String message = config.getString("messages." + path, "&cMessage not found: " + path);
        message = message.replace("{" + placeholder + "}", value);
        return serializer.deserialize(prefix + message);
    }

    /**
     * Get a message with multiple placeholders
     */
    public Component getMessage(String path, String... replacements) {
        FileConfiguration config = plugin.getConfig();
        String prefix = config.getString("messages.prefix", "&8[&6Card SMP&8]&r ");
        String message = config.getString("messages." + path, "&cMessage not found: " + path);
        
        for (int i = 0; i < replacements.length - 1; i += 2) {
            message = message.replace("{" + replacements[i] + "}", replacements[i + 1]);
        }
        
        return serializer.deserialize(prefix + message);
    }

    /**
     * Format time in seconds to readable format
     */
    public static String formatTime(long seconds) {
        if (seconds < 60) {
            return seconds + "s";
        }
        long minutes = seconds / 60;
        long remainingSeconds = seconds % 60;
        if (remainingSeconds == 0) {
            return minutes + "m";
        }
        return minutes + "m " + remainingSeconds + "s";
    }
}
