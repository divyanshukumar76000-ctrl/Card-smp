package mwgameryt._73669.cardsmp.util;

import mwgameryt._73669.cardsmp.model.CardType;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Utility class for card-related operations
 * Handles PDC-based card creation, validation, and identification
 */
public class CardUtil {

    // PDC Keys
    public static final String CARD_TYPE_KEY = "card_type";
    public static final String OWNER_UUID_KEY = "owner_uuid";
    public static final String UNIQUE_CARD_ID_KEY = "unique_card_id";

    /**
     * Create a new card item with PDC security
     * 
     * @param plugin The plugin instance
     * @param type The card type to create
     * @param owner The UUID of the card owner
     * @return The created card ItemStack
     */
    public static ItemStack createCard(Plugin plugin, CardType type, UUID owner) {
        ItemStack item = new ItemStack(type.getMaterial());
        ItemMeta meta = item.getItemMeta();
        
        // Set custom model data
        meta.setCustomModelData(type.getCustomModelData());
        
        // Set display name
        meta.displayName(Component.text(type.getDisplayName())
                .color(NamedTextColor.GOLD)
                .decoration(TextDecoration.ITALIC, false));
        
        // Set lore
        List<Component> lore = new ArrayList<>();
        lore.add(Component.text("A mystical card with unique powers")
                .color(NamedTextColor.GRAY)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.empty());
        lore.add(Component.text("Right-click to activate")
                .color(NamedTextColor.YELLOW)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.empty());
        lore.add(Component.text("Owner: " + owner.toString().substring(0, 8))
                .color(NamedTextColor.DARK_GRAY)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(lore);
        
        // Add PDC data
        PersistentDataContainer pdc = meta.getPersistentDataContainer();
        NamespacedKey cardTypeKey = new NamespacedKey(plugin, CARD_TYPE_KEY);
        NamespacedKey ownerKey = new NamespacedKey(plugin, OWNER_UUID_KEY);
        NamespacedKey uniqueIdKey = new NamespacedKey(plugin, UNIQUE_CARD_ID_KEY);
        
        pdc.set(cardTypeKey, PersistentDataType.STRING, type.getAbilityId());
        pdc.set(ownerKey, PersistentDataType.STRING, owner.toString());
        pdc.set(uniqueIdKey, PersistentDataType.STRING, UUID.randomUUID().toString());
        
        item.setItemMeta(meta);
        return item;
    }

    /**
     * Check if an item is a valid card
     * 
     * @param plugin The plugin instance
     * @param item The item to check
     * @return True if the item is a card
     */
    public static boolean isCard(Plugin plugin, ItemStack item) {
        if (item == null || !item.hasItemMeta()) {
            return false;
        }
        
        ItemMeta meta = item.getItemMeta();
        PersistentDataContainer pdc = meta.getPersistentDataContainer();
        NamespacedKey cardTypeKey = new NamespacedKey(plugin, CARD_TYPE_KEY);
        
        return pdc.has(cardTypeKey, PersistentDataType.STRING);
    }

    /**
     * Get the card type from an item
     * 
     * @param plugin The plugin instance
     * @param item The item to check
     * @return The CardType, or null if not a card
     */
    public static CardType getCardType(Plugin plugin, ItemStack item) {
        if (!isCard(plugin, item)) {
            return null;
        }
        
        ItemMeta meta = item.getItemMeta();
        PersistentDataContainer pdc = meta.getPersistentDataContainer();
        NamespacedKey cardTypeKey = new NamespacedKey(plugin, CARD_TYPE_KEY);
        
        String abilityId = pdc.get(cardTypeKey, PersistentDataType.STRING);
        return CardType.fromAbilityId(abilityId);
    }

    /**
     * Get the owner UUID from a card
     * 
     * @param plugin The plugin instance
     * @param item The card item
     * @return The owner UUID, or null if not a card
     */
    public static UUID getOwnerUUID(Plugin plugin, ItemStack item) {
        if (!isCard(plugin, item)) {
            return null;
        }
        
        ItemMeta meta = item.getItemMeta();
        PersistentDataContainer pdc = meta.getPersistentDataContainer();
        NamespacedKey ownerKey = new NamespacedKey(plugin, OWNER_UUID_KEY);
        
        String uuidString = pdc.get(ownerKey, PersistentDataType.STRING);
        if (uuidString == null) {
            return null;
        }
        
        try {
            return UUID.fromString(uuidString);
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    /**
     * Check if a player is the owner of a card
     * 
     * @param plugin The plugin instance
     * @param item The card item
     * @param playerUUID The player's UUID to check
     * @return True if the player owns the card
     */
    public static boolean isOwner(Plugin plugin, ItemStack item, UUID playerUUID) {
        UUID owner = getOwnerUUID(plugin, item);
        return owner != null && owner.equals(playerUUID);
    }

    /**
     * Get the unique card ID
     * 
     * @param plugin The plugin instance
     * @param item The card item
     * @return The unique card ID, or null if not a card
     */
    public static String getUniqueCardId(Plugin plugin, ItemStack item) {
        if (!isCard(plugin, item)) {
            return null;
        }
        
        ItemMeta meta = item.getItemMeta();
        PersistentDataContainer pdc = meta.getPersistentDataContainer();
        NamespacedKey uniqueIdKey = new NamespacedKey(plugin, UNIQUE_CARD_ID_KEY);
        
        return pdc.get(uniqueIdKey, PersistentDataType.STRING);
    }

    /**
     * Prevent cards from stacking by ensuring unique IDs
     * 
     * @param item1 First card
     * @param item2 Second card
     * @return True if cards are identical (should not happen with unique IDs)
     */
    public static boolean areSameCard(Plugin plugin, ItemStack item1, ItemStack item2) {
        if (!isCard(plugin, item1) || !isCard(plugin, item2)) {
            return false;
        }
        
        String id1 = getUniqueCardId(plugin, item1);
        String id2 = getUniqueCardId(plugin, item2);
        
        return id1 != null && id1.equals(id2);
    }
}
