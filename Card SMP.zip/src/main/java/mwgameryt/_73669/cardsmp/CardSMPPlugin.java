package mwgameryt._73669.cardsmp;

import mwgameryt._73669.cardsmp.abilities.*;
import mwgameryt._73669.cardsmp.commands.CardSMPCommand;
import mwgameryt._73669.cardsmp.listeners.*;
import mwgameryt._73669.cardsmp.managers.*;
import mwgameryt._73669.cardsmp.util.ConfigUtil;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * Main plugin class for Card SMP
 * Handles plugin initialization, manager setup, and registration
 */
public final class CardSMPPlugin extends JavaPlugin {

    // Manager instances
    private AbilityManager abilityManager;
    private CooldownManager cooldownManager;
    private CardRegistryManager cardRegistryManager;
    private DisplayManager displayManager;
    private FreezeManager freezeManager;
    private ParticleManager particleManager;
    private PassiveParticleManager passiveParticleManager;
    private CardSpinManager cardSpinManager;
    private RevivalRitualManager revivalRitualManager;
    private ConfigUtil configUtil;

    @Override
    public void onEnable() {
        // Save default configuration
        saveDefaultConfig();
        
        // Initialize configuration utility
        this.configUtil = new ConfigUtil(this);
        
        // Initialize managers in proper order
        initializeManagers();
        
        // Register abilities
        registerAbilities();
        
        // Register commands
        registerCommands();
        
        // Register listeners
        registerListeners();
        
        getLogger().info("Card SMP has been enabled successfully!");
        getLogger().info("Author: mwgameryt._73669");
    }

    @Override
    public void onDisable() {
        // Cleanup all active effects and entities
        if (freezeManager != null) {
            freezeManager.cleanup();
        }
        
        if (displayManager != null) {
            displayManager.cleanup();
        }
        
        if (passiveParticleManager != null) {
            passiveParticleManager.cleanup();
        }
        
        if (cardSpinManager != null) {
            cardSpinManager.cleanup();
        }
        
        if (revivalRitualManager != null) {
            revivalRitualManager.cleanup();
        }
        
        if (abilityManager != null) {
            abilityManager.cleanup();
        }
        
        if (cardRegistryManager != null) {
            cardRegistryManager.saveData();
        }
        
        getLogger().info("Card SMP has been disabled successfully!");
    }

    /**
     * Initialize all manager instances
     */
    private void initializeManagers() {
        this.cooldownManager = new CooldownManager(this);
        this.cardRegistryManager = new CardRegistryManager(this);
        this.freezeManager = new FreezeManager(this);
        this.particleManager = new ParticleManager(this);
        this.displayManager = new DisplayManager(this);
        this.passiveParticleManager = new PassiveParticleManager(this);
        this.cardSpinManager = new CardSpinManager(this);
        this.revivalRitualManager = new RevivalRitualManager(this);
        this.abilityManager = new AbilityManager(this);
        
        // Load player data
        cardRegistryManager.loadData();
    }

    /**
     * Register all card abilities
     */
    private void registerAbilities() {
        abilityManager.registerAbility(new TimeCardAbility(this));
        abilityManager.registerAbility(new GravityCardAbility(this));
        abilityManager.registerAbility(new GlitchCardAbility(this));
        abilityManager.registerAbility(new ThunderCardAbility(this));
        abilityManager.registerAbility(new SoulCardAbility(this));
        abilityManager.registerAbility(new DemonCardAbility(this));
        abilityManager.registerAbility(new RevivalCardAbility(this));
    }

    /**
     * Register plugin commands
     */
    private void registerCommands() {
        getCommand("cardsmp").setExecutor(new CardSMPCommand(this));
    }

    /**
     * Register event listeners
     */
    private void registerListeners() {
        getServer().getPluginManager().registerEvents(new CardInteractListener(this), this);
        getServer().getPluginManager().registerEvents(new CardProtectionListener(this), this);
        getServer().getPluginManager().registerEvents(new PlayerCleanupListener(this), this);
        getServer().getPluginManager().registerEvents(new SoulCardListener(this), this);
        getServer().getPluginManager().registerEvents(new ThunderCardListener(this), this);
        getServer().getPluginManager().registerEvents(new PluginDisableListener(this), this);
    }

    // Getters for managers
    public AbilityManager getAbilityManager() {
        return abilityManager;
    }

    public CooldownManager getCooldownManager() {
        return cooldownManager;
    }

    public CardRegistryManager getCardRegistryManager() {
        return cardRegistryManager;
    }

    public DisplayManager getDisplayManager() {
        return displayManager;
    }

    public FreezeManager getFreezeManager() {
        return freezeManager;
    }

    public ParticleManager getParticleManager() {
        return particleManager;
    }

    public ConfigUtil getConfigUtil() {
        return configUtil;
    }

    public PassiveParticleManager getPassiveParticleManager() {
        return passiveParticleManager;
    }

    public CardSpinManager getCardSpinManager() {
        return cardSpinManager;
    }

    public RevivalRitualManager getRevivalRitualManager() {
        return revivalRitualManager;
    }
}
