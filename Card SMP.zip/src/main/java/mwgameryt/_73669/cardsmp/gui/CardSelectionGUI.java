package mwgameryt._73669.cardsmp.gui;

import mwgameryt._73669.cardsmp.CardSMPPlugin;
import mwgameryt._73669.cardsmp.model.CardType;
import mwgameryt._73669.cardsmp.util.CardUtil;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

/**
 * GUI for card selection
 * Allows players to choose their card type
 */
public class CardSelectionGUI implements Listener {

    private final CardSMPPlugin plugin;
    private final Player player;
    private final Inventory inventory;

    public CardSelectionGUI(CardSMPPlugin plugin, Player player) {
        this.plugin = plugin;
        this.player = player;
        this.inventory = Bukkit.createInventory(null, 27, Component.text("Select Your Card").color(NamedTextColor.GOLD));

        setupGUI();
        plugin.getServer().getPluginManager().registerEvents(this, plugin);
    }

    /**
     * Setup the GUI with card options
     */
    private void setupGUI() {
        // Add card items in specific slots
        CardType[] cards = CardType.values();
        int[] slots = {10, 11, 12, 13, 14, 15}; // Bottom row with spacing

        for (int i = 0; i < cards.length && i < slots.length; i++) {
            ItemStack cardItem = createGUICard(cards[i]);
            inventory.setItem(slots[i], cardItem);
        }

        // Add decorative glass panes
        ItemStack filler = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta fillerMeta = filler.getItemMeta();
        fillerMeta.displayName(Component.empty());
        filler.setItemMeta(fillerMeta);

        for (int i = 0; i < inventory.getSize(); i++) {
            if (inventory.getItem(i) == null) {
                inventory.setItem(i, filler);
            }
        }
    }

    /**
     * Create a GUI representation of a card
     */
    private ItemStack createGUICard(CardType type) {
        ItemStack item = new ItemStack(type.getMaterial());
        ItemMeta meta = item.getItemMeta();

        meta.setCustomModelData(type.getCustomModelData());
        meta.displayName(Component.text(type.getDisplayName())
                .color(NamedTextColor.GOLD)
                .decoration(TextDecoration.ITALIC, false)
                .decoration(TextDecoration.BOLD, true));

        List<Component> lore = new ArrayList<>();
        lore.add(Component.empty());
        lore.add(Component.text("Click to select this card!")
                .color(NamedTextColor.YELLOW)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.empty());
        lore.add(Component.text("Cooldown: " + (type.getCooldown() / 1000) + "s")
                .color(NamedTextColor.GRAY)
                .decoration(TextDecoration.ITALIC, false));

        meta.lore(lore);
        item.setItemMeta(meta);

        return item;
    }

    /**
     * Open the GUI for the player
     */
    public void open() {
        player.openInventory(inventory);
    }

    /**
     * Handle inventory click events
     */
    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player clickedPlayer)) {
            return;
        }

        if (!event.getView().getTopInventory().equals(inventory)) {
            return;
        }

        event.setCancelled(true);

        if (event.getCurrentItem() == null || event.getCurrentItem().getType() == Material.AIR) {
            return;
        }

        // Find clicked card type
        ItemStack clicked = event.getCurrentItem();
        CardType selectedType = null;

        for (CardType type : CardType.values()) {
            if (clicked.getType() == type.getMaterial() && 
                clicked.hasItemMeta() && 
                clicked.getItemMeta().hasCustomModelData() &&
                clicked.getItemMeta().getCustomModelData() == type.getCustomModelData()) {
                selectedType = type;
                break;
            }
        }

        if (selectedType == null) {
            return;
        }

        // Give the card to the player
        ItemStack card = CardUtil.createCard(plugin, selectedType, clickedPlayer.getUniqueId());
        clickedPlayer.getInventory().addItem(card);

        // Register the card
        plugin.getCardRegistryManager().registerCard(clickedPlayer, selectedType);

        // Send message
        clickedPlayer.sendMessage(plugin.getConfigUtil().getMessage("card-registered", "card", selectedType.getDisplayName()));

        // Close GUI
        clickedPlayer.closeInventory();
    }
}
