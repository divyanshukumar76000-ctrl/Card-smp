package mwgameryt._73669.cardsmp.gui;

import mwgameryt._73669.cardsmp.CardSMPPlugin;
import mwgameryt._73669.cardsmp.managers.RevivalRitualManager;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * GUI for selecting banned players to revive
 */
public class RevivalGUI implements Listener {

    private final CardSMPPlugin plugin;
    private final Player viewer;
    private final Inventory inventory;

    public RevivalGUI(CardSMPPlugin plugin, Player viewer) {
        this.plugin = plugin;
        this.viewer = viewer;
        this.inventory = Bukkit.createInventory(null, 27, 
            Component.text("Select Player to Revive").color(NamedTextColor.DARK_PURPLE));
        
        plugin.getServer().getPluginManager().registerEvents(this, plugin);
        
        populateGUI();
    }

    private void populateGUI() {
        Set<OfflinePlayer> bannedPlayers = Bukkit.getBannedPlayers();
        
        if (bannedPlayers.isEmpty()) {
            // No banned players
            ItemStack noPlayers = new ItemStack(Material.BARRIER);
            noPlayers.editMeta(meta -> {
                meta.displayName(Component.text("No Banned Players")
                    .color(NamedTextColor.RED)
                    .decoration(TextDecoration.ITALIC, false));
            });
            inventory.setItem(13, noPlayers);
            return;
        }
        
        int slot = 0;
        for (OfflinePlayer banned : bannedPlayers) {
            if (slot >= 27) break;
            
            ItemStack skull = new ItemStack(Material.PLAYER_HEAD);
            skull.editMeta(SkullMeta.class, meta -> {
                meta.setOwningPlayer(banned);
                meta.displayName(Component.text(banned.getName() != null ? banned.getName() : "Unknown")
                    .color(NamedTextColor.YELLOW)
                    .decoration(TextDecoration.ITALIC, false));
                
                List<Component> lore = new ArrayList<>();
                lore.add(Component.empty());
                lore.add(Component.text("Click to start revival ritual")
                    .color(NamedTextColor.GRAY)
                    .decoration(TextDecoration.ITALIC, false));
                lore.add(Component.text("⚠ Consumes 1 Revival Card")
                    .color(NamedTextColor.RED)
                    .decoration(TextDecoration.ITALIC, false));
                lore.add(Component.text("⚠ Must stand still for 60s")
                    .color(NamedTextColor.RED)
                    .decoration(TextDecoration.ITALIC, false));
                meta.lore(lore);
            });
            
            inventory.setItem(slot, skull);
            slot++;
        }
    }

    public void open() {
        viewer.openInventory(inventory);
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!event.getInventory().equals(inventory)) return;
        if (!(event.getWhoClicked() instanceof Player player)) return;
        
        event.setCancelled(true);
        
        ItemStack clicked = event.getCurrentItem();
        if (clicked == null || clicked.getType() != Material.PLAYER_HEAD) return;
        
        if (!(clicked.getItemMeta() instanceof SkullMeta skullMeta)) return;
        OfflinePlayer target = skullMeta.getOwningPlayer();
        
        if (target == null) return;
        
        player.closeInventory();
        
        // Start ritual
        plugin.getRevivalRitualManager().startRitual(player, target);
    }
}
