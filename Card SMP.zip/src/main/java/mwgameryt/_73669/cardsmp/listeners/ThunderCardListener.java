package mwgameryt._73669.cardsmp.listeners;

import mwgameryt._73669.cardsmp.CardSMPPlugin;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;

/**
 * Handles Thunder Card caster immunity to their own lightning
 */
public class ThunderCardListener implements Listener {

    private final CardSMPPlugin plugin;

    public ThunderCardListener(CardSMPPlugin plugin) {
        this.plugin = plugin;
    }

    /**
     * Make caster immune to their own Thunder Card lightning
     */
    @EventHandler
    public void onLightningDamage(EntityDamageByEntityEvent event) {
        // Check if damage is from lightning
        if (event.getDamager().getType() != EntityType.LIGHTNING_BOLT) {
            return;
        }

        // Check if damaged entity is a player
        if (!(event.getEntity() instanceof Player damaged)) {
            return;
        }

        // Get Thunder Card ability and check if player is active caster
        var thunderAbility = (mwgameryt._73669.cardsmp.abilities.ThunderCardAbility) 
            plugin.getAbilityManager().getAbility("thunder");
        
        if (thunderAbility != null && thunderAbility.isActiveCaster(damaged)) {
            // Player is the caster - cancel damage
            event.setCancelled(true);
        }
    }
}
