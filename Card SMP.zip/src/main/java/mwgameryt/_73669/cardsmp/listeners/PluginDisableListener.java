package mwgameryt._73669.cardsmp.listeners;

import mwgameryt._73669.cardsmp.CardSMPPlugin;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.server.PluginDisableEvent;

/**
 * Handles cleanup on plugin disable and server reload
 * Ensures all resources are properly released
 */
public class PluginDisableListener implements Listener {

    private final CardSMPPlugin plugin;

    public PluginDisableListener(CardSMPPlugin plugin) {
        this.plugin = plugin;
    }

    /**
     * Cleanup all plugin resources when disabled
     */
    @EventHandler
    public void onPluginDisable(PluginDisableEvent event) {
        if (!event.getPlugin().equals(plugin)) {
            return;
        }

        // Cleanup all online players
        for (Player player : Bukkit.getOnlinePlayers()) {
            // Remove displays
            plugin.getDisplayManager().removeDisplays(player);
            
            // Stop passive particles
            plugin.getPassiveParticleManager().cleanup(player);
            
            // Cancel spins
            plugin.getCardSpinManager().cleanup(player);
            
            // Cancel rituals
            plugin.getRevivalRitualManager().cleanup(player);
            
            // Cleanup abilities
            plugin.getAbilityManager().cleanup(player);
            
            // Restore attributes
            plugin.getFreezeManager().unfreeze(player);
            player.setWalkSpeed(0.2f);
            player.setFlySpeed(0.1f);
        }

        // Global cleanup
        plugin.getDisplayManager().cleanup();
        plugin.getPassiveParticleManager().cleanup();
        plugin.getCardSpinManager().cleanup();
        plugin.getRevivalRitualManager().cleanup();
        plugin.getFreezeManager().cleanup();
    }
}
