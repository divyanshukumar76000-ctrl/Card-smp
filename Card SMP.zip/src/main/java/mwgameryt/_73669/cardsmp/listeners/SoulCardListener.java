package mwgameryt._73669.cardsmp.listeners;

import mwgameryt._73669.cardsmp.CardSMPPlugin;
import mwgameryt._73669.cardsmp.abilities.SoulCardAbility;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;

/**
 * Handles damage events for Soul Card immunity
 * Cancels damage and stores it for later application
 */
public class SoulCardListener implements Listener {

    private final CardSMPPlugin plugin;

    public SoulCardListener(CardSMPPlugin plugin) {
        this.plugin = plugin;
    }

    /**
     * Handle entity damage for Soul Card immunity
     */
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onEntityDamage(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player player)) {
            return;
        }

        // Get Soul Card ability
        SoulCardAbility soulAbility = (SoulCardAbility) plugin.getAbilityManager().getAbility("soul");
        if (soulAbility == null) {
            return;
        }

        // Check if player is immune
        if (soulAbility.isImmune(player)) {
            double damage = event.getFinalDamage();
            
            // Store the damage
            soulAbility.addStoredDamage(player, damage);
            
            // Cancel the damage
            event.setCancelled(true);
        }
    }
}
