package mwgameryt._73669.cardsmp.listeners;

import mwgameryt._73669.cardsmp.CardSMPPlugin;
import mwgameryt._73669.cardsmp.abilities.CardAbility;
import mwgameryt._73669.cardsmp.model.CardType;
import mwgameryt._73669.cardsmp.util.CardUtil;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

/**
 * Handles card interaction and equip events
 * Activates card abilities and manages passive effects
 */
public class CardInteractListener implements Listener {

    private final CardSMPPlugin plugin;

    public CardInteractListener(CardSMPPlugin plugin) {
        this.plugin = plugin;
    }

    /**
     * Handle right-click card activation
     */
    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        // Only handle right-click actions
        if (event.getAction() != Action.RIGHT_CLICK_AIR && event.getAction() != Action.RIGHT_CLICK_BLOCK) {
            return;
        }

        // Ignore off-hand interactions
        if (event.getHand() != EquipmentSlot.HAND) {
            return;
        }

        Player player = event.getPlayer();
        ItemStack item = player.getInventory().getItemInMainHand();

        // Check if item is a card
        if (!CardUtil.isCard(plugin, item)) {
            return;
        }

        event.setCancelled(true);

        // Get card type
        CardType cardType = CardUtil.getCardType(plugin, item);
        if (cardType == null) {
            return;
        }

        // Check ownership unless admin
        if (!player.hasPermission("cardsmp.admin")) {
            if (!CardUtil.isOwner(plugin, item, player.getUniqueId())) {
                player.sendMessage(plugin.getConfigUtil().getMessage("not-owner"));
                return;
            }

            // Check if card is registered
            CardType registeredType = plugin.getCardRegistryManager().getRegisteredCard(player);
            if (registeredType != cardType) {
                player.sendMessage(plugin.getConfigUtil().getMessage("not-owner"));
                return;
            }
        }

        // Get ability
        CardAbility ability = plugin.getAbilityManager().getAbility(cardType.getAbilityId());
        if (ability == null) {
            return;
        }

        // Check cooldown
        if (plugin.getCooldownManager().hasCooldown(player, ability.getId())) {
            plugin.getCooldownManager().sendCooldownMessage(player, ability.getId());
            return;
        }

        // Activate ability
        ability.activate(player);

        // Set cooldown
        plugin.getCooldownManager().setCooldown(player, ability.getId(), ability.getCooldown());

        // Send activation message
        player.sendMessage(plugin.getConfigUtil().getMessage("card-activated", "card", cardType.getDisplayName()));
    }

    /**
     * Handle item held change for passive effects (Demon Card orbit + all card particles)
     */
    @EventHandler
    public void onItemHeld(PlayerItemHeldEvent event) {
        Player player = event.getPlayer();
        ItemStack newItem = player.getInventory().getItem(event.getNewSlot());
        ItemStack oldItem = player.getInventory().getItem(event.getPreviousSlot());

        // Stop old passive effects
        if (oldItem != null && CardUtil.isCard(plugin, oldItem)) {
            CardType oldCardType = CardUtil.getCardType(plugin, oldItem);
            
            // Stop passive particles
            plugin.getPassiveParticleManager().stopPassiveParticles(player);
            
            // Stop Demon Card orbit
            if (oldCardType == CardType.DEMON) {
                plugin.getDisplayManager().removeDisplays(player);
            }
        }

        // Start new passive effects
        if (newItem != null && CardUtil.isCard(plugin, newItem)) {
            CardType newCardType = CardUtil.getCardType(plugin, newItem);
            
            // Check ownership
            if (player.hasPermission("cardsmp.admin") || CardUtil.isOwner(plugin, newItem, player.getUniqueId())) {
                // Start passive particles for all card types
                plugin.getPassiveParticleManager().startPassiveParticles(player, newCardType);
                
                // Start Demon Card orbit displays
                if (newCardType == CardType.DEMON) {
                    double radius = plugin.getConfig().getDouble("cards.demon.orbit-radius", 2.5);
                    double speed = plugin.getConfig().getDouble("cards.demon.orbit-speed", 0.1);
                    plugin.getDisplayManager().createOrbitingDisplays(player, newCardType, radius, speed);
                }
            }
        }
    }
}
