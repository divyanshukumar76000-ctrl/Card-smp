package mwgameryt._73669.cardsmp.listeners;

import mwgameryt._73669.cardsmp.CardSMPPlugin;
import mwgameryt._73669.cardsmp.util.CardUtil;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Item;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.ItemDespawnEvent;
import org.bukkit.event.inventory.*;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.inventory.ItemStack;

/**
 * Protects cards from unauthorized modifications
 * Prevents: hoppers, anvils, crafting, stacking, despawning
 */
public class CardProtectionListener implements Listener {

    private final CardSMPPlugin plugin;

    public CardProtectionListener(CardSMPPlugin plugin) {
        this.plugin = plugin;
    }

    /**
     * Prevent cards from being moved by hoppers
     */
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onInventoryMoveItem(InventoryMoveItemEvent event) {
        ItemStack item = event.getItem();
        
        if (CardUtil.isCard(plugin, item)) {
            event.setCancelled(true);
        }
    }

    /**
     * Prevent cards from being used in anvils
     */
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPrepareAnvil(PrepareAnvilEvent event) {
        ItemStack first = event.getInventory().getFirstItem();
        ItemStack second = event.getInventory().getSecondItem();
        
        if ((first != null && CardUtil.isCard(plugin, first)) || 
            (second != null && CardUtil.isCard(plugin, second))) {
            event.setResult(null);
        }
    }

    /**
     * Prevent cards from being used in crafting
     */
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPrepareCraft(PrepareItemCraftEvent event) {
        for (ItemStack item : event.getInventory().getMatrix()) {
            if (item != null && CardUtil.isCard(plugin, item)) {
                event.getInventory().setResult(null);
                return;
            }
        }
    }

    /**
     * Prevent cards from despawning
     */
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onItemDespawn(ItemDespawnEvent event) {
        ItemStack item = event.getEntity().getItemStack();
        
        if (CardUtil.isCard(plugin, item)) {
            event.setCancelled(true);
        }
    }

    /**
     * Prevent card stacking in inventory
     * This is handled by unique card IDs in PDC
     */
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onInventoryClick(InventoryClickEvent event) {
        ItemStack cursor = event.getCursor();
        ItemStack current = event.getCurrentItem();
        
        // Prevent combining cards
        if (cursor != null && current != null && 
            CardUtil.isCard(plugin, cursor) && CardUtil.isCard(plugin, current)) {
            
            // Allow if same card (shouldn't happen with unique IDs)
            if (!CardUtil.areSameCard(plugin, cursor, current)) {
                event.setCancelled(true);
            }
        }
    }

    /**
     * Allow dropping cards (but they won't despawn)
     * This is optional - remove if you want to prevent dropping entirely
     */
    @EventHandler(priority = EventPriority.NORMAL)
    public void onPlayerDropItem(PlayerDropItemEvent event) {
        // Cards can be dropped but won't despawn due to ItemDespawnEvent handler
        // Uncomment below to prevent dropping entirely:
        /*
        ItemStack item = event.getItemDrop().getItemStack();
        if (CardUtil.isCard(plugin, item)) {
            event.setCancelled(true);
            event.getPlayer().sendMessage(plugin.getConfigUtil().getMessage("cannot-drop"));
        }
        */
    }
}
