package mwgameryt._73669.cardsmp.listeners;

import mwgameryt._73669.cardsmp.CardSMPPlugin;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerQuitEvent;

/**
 * Handles cleanup when players disconnect, die, or change worlds
 * Ensures no memory leaks or ghost entities
 */
public class PlayerCleanupListener implements Listener {

    private final CardSMPPlugin plugin;

    public PlayerCleanupListener(CardSMPPlugin plugin) {
        this.plugin = plugin;
    }

    /**
     * Cleanup when player quits
     */
    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        cleanupPlayer(player);
    }

    /**
     * Cleanup when player dies
     */
    @EventHandler
    public void onPlayerDeath(PlayerDeathEvent event) {
        Player player = event.getPlayer();
        cleanupPlayer(player);
    }

    /**
     * Cleanup when player changes world
     */
    @EventHandler
    public void onWorldChange(PlayerChangedWorldEvent event) {
        Player player = event.getPlayer();
        cleanupPlayer(player);
    }

    /**
     * Perform all cleanup operations for a player
     * CRITICAL: Zero-tolerance memory leak prevention
     */
    private void cleanupPlayer(Player player) {
        // Remove orbiting displays (Demon Card)
        plugin.getDisplayManager().removeDisplays(player);
        
        // Stop passive particle effects
        plugin.getPassiveParticleManager().cleanup(player);
        
        // Cancel card spin animations
        plugin.getCardSpinManager().cleanup(player);
        
        // Cancel revival rituals
        plugin.getRevivalRitualManager().cleanup(player);
        
        // Cleanup ability-specific data (BukkitRunnables, effects, etc.)
        plugin.getAbilityManager().cleanup(player);
        
        // Restore player attributes
        plugin.getFreezeManager().unfreeze(player);
        
        // Reset walk speed to default
        player.setWalkSpeed(0.2f);
        player.setFlySpeed(0.1f);
        
        // Note: We don't clear cooldowns or card registrations
        // as those should persist across sessions/deaths
    }
}
