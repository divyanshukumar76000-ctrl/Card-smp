package mwgameryt._73669.cardsmp.model;

import org.bukkit.Material;

/**
 * Enum representing all available card types in the SMP
 * Each card has unique properties and abilities
 */
public enum CardType {
    
    TIME("Time Card", Material.LIGHT_BLUE_DYE, 1, "time", 60000L),
    GRAVITY("Gravity Card", Material.BLACK_DYE, 2, "gravity", 45000L),
    GLITCH("Glitch Card", Material.GRAY_DYE, 3, "glitch", 45000L),
    THUNDER("Thunder Card", Material.YELLOW_DYE, 4, "thunder", 30000L),
    SOUL("Soul Card", Material.WHITE_DYE, 5, "soul", 40000L),
    DEMON("Demon Card", Material.RED_DYE, 6, "demon", 60000L),
    REVIVAL("Revival Card", Material.GREEN_DYE, 7, "revival", 0L);

    private final String displayName;
    private final Material material;
    private final int customModelData;
    private final String abilityId;
    private final long cooldown;

    CardType(String displayName, Material material, int customModelData, String abilityId, long cooldown) {
        this.displayName = displayName;
        this.material = material;
        this.customModelData = customModelData;
        this.abilityId = abilityId;
        this.cooldown = cooldown;
    }

    public String getDisplayName() {
        return displayName;
    }

    public Material getMaterial() {
        return material;
    }

    public int getCustomModelData() {
        return customModelData;
    }

    public String getAbilityId() {
        return abilityId;
    }

    public long getCooldown() {
        return cooldown;
    }

    /**
     * Get CardType from ability ID
     */
    public static CardType fromAbilityId(String abilityId) {
        for (CardType type : values()) {
            if (type.getAbilityId().equalsIgnoreCase(abilityId)) {
                return type;
            }
        }
        return null;
    }

    /**
     * Get CardType from custom model data
     */
    public static CardType fromCustomModelData(int cmd) {
        for (CardType type : values()) {
            if (type.getCustomModelData() == cmd) {
                return type;
            }
        }
        return null;
    }
}
