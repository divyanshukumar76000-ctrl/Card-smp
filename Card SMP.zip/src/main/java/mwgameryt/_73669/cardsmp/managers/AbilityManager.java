package mwgameryt._73669.cardsmp.managers;

import mwgameryt._73669.cardsmp.abilities.CardAbility;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

import java.util.HashMap;
import java.util.Map;

/**
 * Manages all card abilities
 * Handles registration, retrieval, and cleanup of abilities
 */
public class AbilityManager {

    private final Plugin plugin;
    private final Map<String, CardAbility> abilities;

    public AbilityManager(Plugin plugin) {
        this.plugin = plugin;
        this.abilities = new HashMap<>();
    }

    /**
     * Register a card ability
     * 
     * @param ability The ability to register
     */
    public void registerAbility(CardAbility ability) {
        abilities.put(ability.getId(), ability);
        plugin.getLogger().info("Registered ability: " + ability.getId());
    }

    /**
     * Get an ability by ID
     * 
     * @param abilityId The ability identifier
     * @return The CardAbility, or null if not found
     */
    public CardAbility getAbility(String abilityId) {
        return abilities.get(abilityId);
    }

    /**
     * Check if an ability exists
     * 
     * @param abilityId The ability identifier
     * @return True if the ability is registered
     */
    public boolean hasAbility(String abilityId) {
        return abilities.containsKey(abilityId);
    }

    /**
     * Get all registered abilities
     * 
     * @return Map of all abilities
     */
    public Map<String, CardAbility> getAllAbilities() {
        return new HashMap<>(abilities);
    }

    /**
     * Cleanup all abilities for a player
     * Called when player disconnects or plugin disables
     * 
     * @param player The player to cleanup for
     */
    public void cleanup(Player player) {
        for (CardAbility ability : abilities.values()) {
            ability.cleanup(player);
        }
    }

    /**
     * Cleanup all abilities for all players
     */
    public void cleanup() {
        // This method is called on plugin disable
        // Individual player cleanup is handled by listeners
    }
}
