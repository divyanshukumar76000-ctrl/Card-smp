package mwgameryt._73669.cardsmp.managers;

import mwgameryt._73669.cardsmp.CardSMPPlugin;
import mwgameryt._73669.cardsmp.model.CardType;
import mwgameryt._73669.cardsmp.util.CardUtil;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Manages revival rituals for unbanning players
 * 60-second ritual with particle effects and movement detection
 */
public class RevivalRitualManager {

    private final CardSMPPlugin plugin;
    private final Map<UUID, RitualSession> activeSessions;

    public RevivalRitualManager(CardSMPPlugin plugin) {
        this.plugin = plugin;
        this.activeSessions = new HashMap<>();
    }

    /**
     * Start a revival ritual
     */
    public void startRitual(Player caster, OfflinePlayer target) {
        UUID uuid = caster.getUniqueId();
        
        // Check if already in ritual
        if (activeSessions.containsKey(uuid)) {
            caster.sendMessage(Component.text("You are already performing a ritual!").color(NamedTextColor.RED));
            return;
        }
        
        // Check for Revival Card in inventory
        ItemStack revivalCard = findRevivalCard(caster);
        if (revivalCard == null) {
            caster.sendMessage(Component.text("You need a Revival Card to perform this ritual!").color(NamedTextColor.RED));
            return;
        }
        
        // Consume the card
        revivalCard.setAmount(revivalCard.getAmount() - 1);
        
        // Create and start session
        RitualSession session = new RitualSession(caster, target);
        activeSessions.put(uuid, session);
        session.start();
    }

    /**
     * Cancel a ritual (called on disconnect, death, etc.)
     */
    public void cancelRitual(Player player) {
        RitualSession session = activeSessions.remove(player.getUniqueId());
        if (session != null) {
            session.cancel();
        }
    }

    /**
     * Find Revival Card in player inventory
     */
    private ItemStack findRevivalCard(Player player) {
        for (ItemStack item : player.getInventory().getContents()) {
            if (CardUtil.isCard(plugin, item)) {
                CardType type = CardUtil.getCardType(plugin, item);
                if (type == CardType.REVIVAL) {
                    return item;
                }
            }
        }
        return null;
    }

    /**
     * Cleanup all active rituals
     */
    public void cleanup() {
        for (RitualSession session : activeSessions.values()) {
            session.cancel();
        }
        activeSessions.clear();
    }

    /**
     * Cleanup for specific player
     */
    public void cleanup(Player player) {
        cancelRitual(player);
    }

    /**
     * Inner class representing a ritual session
     */
    private class RitualSession {
        private final Player caster;
        private final OfflinePlayer target;
        private final Location startLocation;
        private BukkitTask particleTask;
        private BukkitTask timerTask;
        
        private static final int RITUAL_DURATION = 1200; // 60 seconds (1200 ticks)
        private static final double MAX_MOVEMENT = 5.0;

        public RitualSession(Player caster, OfflinePlayer target) {
            this.caster = caster;
            this.target = target;
            this.startLocation = caster.getLocation().clone();
        }

        public void start() {
            // Send start message
            caster.sendMessage(Component.empty());
            caster.sendMessage(Component.text("═══════════════════════════════")
                .color(NamedTextColor.DARK_PURPLE));
            caster.sendMessage(Component.text("Revival Ritual Started")
                .color(NamedTextColor.LIGHT_PURPLE));
            caster.sendMessage(Component.text("Target: " + (target.getName() != null ? target.getName() : "Unknown"))
                .color(NamedTextColor.WHITE));
            caster.sendMessage(Component.text("⚠ Do not move more than 5 blocks!")
                .color(NamedTextColor.RED));
            caster.sendMessage(Component.text("Duration: 60 seconds")
                .color(NamedTextColor.GRAY));
            caster.sendMessage(Component.text("═══════════════════════════════")
                .color(NamedTextColor.DARK_PURPLE));
            caster.sendMessage(Component.empty());
            
            startParticles();
            startTimer();
        }

        private void startParticles() {
            particleTask = new BukkitRunnable() {
                double angle = 0;
                int tick = 0;
                
                @Override
                public void run() {
                    if (!caster.isOnline()) {
                        cancel();
                        return;
                    }
                    
                    Location loc = caster.getLocation();
                    
                    // Beacon beam effect
                    if (tick % 5 == 0) {
                        for (int y = 0; y < 20; y++) {
                            loc.getWorld().spawnParticle(Particle.END_ROD, 
                                loc.clone().add(0, y * 0.5, 0), 1, 0.1, 0.1, 0.1, 0);
                        }
                    }
                    
                    // Floating souls
                    for (int i = 0; i < 3; i++) {
                        double currentAngle = angle + (i * 2 * Math.PI / 3);
                        double radius = 1.5;
                        double x = loc.getX() + radius * Math.cos(currentAngle);
                        double z = loc.getZ() + radius * Math.sin(currentAngle);
                        double y = loc.getY() + 1 + Math.sin(tick * 0.1 + i) * 0.5;
                        
                        Location particleLoc = new Location(loc.getWorld(), x, y, z);
                        loc.getWorld().spawnParticle(Particle.SOUL, particleLoc, 1, 0, 0.05, 0, 0);
                        loc.getWorld().spawnParticle(Particle.SOUL_FIRE_FLAME, particleLoc, 1, 0, 0, 0, 0);
                    }
                    
                    // Magic circle on ground
                    if (tick % 3 == 0) {
                        for (int i = 0; i < 16; i++) {
                            double circleAngle = (i * 2 * Math.PI / 16);
                            double radius = 2.0;
                            double x = loc.getX() + radius * Math.cos(circleAngle);
                            double z = loc.getZ() + radius * Math.sin(circleAngle);
                            
                            Location circleLoc = new Location(loc.getWorld(), x, loc.getY() + 0.1, z);
                            loc.getWorld().spawnParticle(Particle.ENCHANT, circleLoc, 1, 0, 0, 0, 0);
                        }
                    }
                    
                    angle += 0.05;
                    tick++;
                }
            }.runTaskTimer(plugin, 0L, 1L);
        }

        private void startTimer() {
            timerTask = new BukkitRunnable() {
                int tick = 0;
                
                @Override
                public void run() {
                    if (!caster.isOnline()) {
                        cancel();
                        activeSessions.remove(caster.getUniqueId());
                        return;
                    }
                    
                    // Check movement
                    if (startLocation.distance(caster.getLocation()) > MAX_MOVEMENT) {
                        caster.sendMessage(Component.text("✖ Ritual failed - you moved too far!")
                            .color(NamedTextColor.RED));
                        cancel();
                        return;
                    }
                    
                    // Send progress every 5 seconds
                    if (tick % 100 == 0) {
                        int secondsRemaining = (RITUAL_DURATION - tick) / 20;
                        caster.sendActionBar(Component.text("Ritual: " + secondsRemaining + "s remaining")
                            .color(NamedTextColor.LIGHT_PURPLE));
                    }
                    
                    tick++;
                    
                    // Complete ritual
                    if (tick >= RITUAL_DURATION) {
                        complete();
                        cancel();
                    }
                }
            }.runTaskTimer(plugin, 0L, 1L);
        }

        private void complete() {
            // Unban the target
            if (target.isBanned()) {
                Bukkit.getBanList(BanList.Type.NAME).pardon(target.getName());
            }
            
            // Success effects
            Location loc = caster.getLocation();
            loc.getWorld().spawnParticle(Particle.FLASH, loc, 1, 0, 0, 0, 0);
            loc.getWorld().spawnParticle(Particle.TOTEM_OF_UNDYING, loc, 50, 1, 1, 1, 0.1);
            loc.getWorld().spawnParticle(Particle.END_ROD, loc, 30, 0.5, 2, 0.5, 0.1);
            
            caster.playSound(loc, Sound.UI_TOAST_CHALLENGE_COMPLETE, 1.0f, 1.0f);
            caster.playSound(loc, Sound.BLOCK_BEACON_ACTIVATE, 1.0f, 1.5f);
            
            // Broadcast
            String targetName = target.getName() != null ? target.getName() : "Unknown";
            Component broadcast = Component.text(caster.getName())
                .color(NamedTextColor.YELLOW)
                .append(Component.text(" has revived ").color(NamedTextColor.GRAY))
                .append(Component.text(targetName).color(NamedTextColor.GREEN))
                .append(Component.text("!").color(NamedTextColor.GRAY));
            
            Bukkit.broadcast(broadcast);
            
            // Remove from active sessions
            activeSessions.remove(caster.getUniqueId());
        }

        public void cancel() {
            if (particleTask != null) {
                particleTask.cancel();
            }
            if (timerTask != null) {
                timerTask.cancel();
            }
            activeSessions.remove(caster.getUniqueId());
        }
    }
}
