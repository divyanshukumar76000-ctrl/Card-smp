package mwgameryt._73669.cardsmp.managers;

import mwgameryt._73669.cardsmp.CardSMPPlugin;
import mwgameryt._73669.cardsmp.model.CardType;
import mwgameryt._73669.cardsmp.util.CardUtil;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.*;
import org.bukkit.entity.Display;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;

/**
 * Manages the cinematic card spin animation system
 * Triggered by /cardsmp start for first-time players
 */
public class CardSpinManager {

    private final CardSMPPlugin plugin;
    private final Map<UUID, SpinSession> activeSessions;
    private final Random random;
    
    private static final NamespacedKey HAS_STARTER_CARD_KEY = new NamespacedKey("cardsmp", "has_starter_card");
    
    // Rarity weights (must sum to 100)
    private static final int WEIGHT_TIME = 20;
    private static final int WEIGHT_GRAVITY = 20;
    private static final int WEIGHT_GLITCH = 20;
    private static final int WEIGHT_THUNDER = 15;
    private static final int WEIGHT_SOUL = 15;
    private static final int WEIGHT_DEMON = 7;
    private static final int WEIGHT_REVIVAL = 3;

    public CardSpinManager(CardSMPPlugin plugin) {
        this.plugin = plugin;
        this.activeSessions = new HashMap<>();
        this.random = new Random();
    }

    /**
     * Start spin animation for all eligible online players
     */
    public void startGlobalSpin() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            if (!hasStarterCard(player)) {
                startPlayerSpin(player);
            } else {
                player.sendMessage(Component.text("You already have a starter card!").color(NamedTextColor.RED));
            }
        }
    }

    /**
     * Start spin animation for a specific player
     */
    public void startPlayerSpin(Player player) {
        UUID uuid = player.getUniqueId();
        
        // Cancel existing session if any
        cancelPlayerSpin(player);
        
        // Lock movement
        player.setWalkSpeed(0.0f);
        
        // Select winning card based on rarity weights
        CardType winningCard = selectWeightedCard();
        
        // Create spin session
        SpinSession session = new SpinSession(player, winningCard);
        activeSessions.put(uuid, session);
        
        // Start animation
        session.start();
    }

    /**
     * Cancel spin for a player (used for cleanup)
     */
    public void cancelPlayerSpin(Player player) {
        SpinSession session = activeSessions.remove(player.getUniqueId());
        if (session != null) {
            session.cleanup();
            player.setWalkSpeed(0.2f); // Restore default walk speed
        }
    }

    /**
     * Check if player has received starter card
     */
    private boolean hasStarterCard(Player player) {
        return player.getPersistentDataContainer().getOrDefault(
            HAS_STARTER_CARD_KEY, 
            PersistentDataType.BOOLEAN, 
            false
        );
    }

    /**
     * Mark player as having received starter card
     */
    private void markHasStarterCard(Player player) {
        player.getPersistentDataContainer().set(
            HAS_STARTER_CARD_KEY, 
            PersistentDataType.BOOLEAN, 
            true
        );
    }

    /**
     * Select a card based on weighted rarities
     */
    private CardType selectWeightedCard() {
        int totalWeight = WEIGHT_TIME + WEIGHT_GRAVITY + WEIGHT_GLITCH + 
                         WEIGHT_THUNDER + WEIGHT_SOUL + WEIGHT_DEMON + WEIGHT_REVIVAL;
        int roll = random.nextInt(totalWeight);
        
        int cumulative = 0;
        
        cumulative += WEIGHT_TIME;
        if (roll < cumulative) return CardType.TIME;
        
        cumulative += WEIGHT_GRAVITY;
        if (roll < cumulative) return CardType.GRAVITY;
        
        cumulative += WEIGHT_GLITCH;
        if (roll < cumulative) return CardType.GLITCH;
        
        cumulative += WEIGHT_THUNDER;
        if (roll < cumulative) return CardType.THUNDER;
        
        cumulative += WEIGHT_SOUL;
        if (roll < cumulative) return CardType.SOUL;
        
        cumulative += WEIGHT_DEMON;
        if (roll < cumulative) return CardType.DEMON;
        
        return CardType.REVIVAL;
    }

    /**
     * Remove any existing custom cards from player inventory
     */
    private void removeExistingCards(Player player) {
        // Check inventory
        for (ItemStack item : player.getInventory().getContents()) {
            if (CardUtil.isCard(plugin, item)) {
                player.getInventory().remove(item);
            }
        }
        
        // Check ender chest
        for (ItemStack item : player.getEnderChest().getContents()) {
            if (CardUtil.isCard(plugin, item)) {
                player.getEnderChest().remove(item);
            }
        }
    }

    /**
     * Cleanup all active spin sessions
     */
    public void cleanup() {
        for (SpinSession session : new ArrayList<>(activeSessions.values())) {
            session.cleanup();
        }
        activeSessions.clear();
    }

    /**
     * Cleanup for specific player
     */
    public void cleanup(Player player) {
        cancelPlayerSpin(player);
    }

    /**
     * Inner class representing a spin session for a player
     */
    private class SpinSession {
        private final Player player;
        private final CardType winningCard;
        private final List<ItemDisplay> displays;
        private final Location startLocation;
        private BukkitTask animationTask;
        private BukkitTask particleTask;
        
        private static final double RADIUS = 1.5;
        private static final double HEIGHT = 1.6;
        private static final int SPIN_DURATION = 200; // 10 seconds

        public SpinSession(Player player, CardType winningCard) {
            this.player = player;
            this.winningCard = winningCard;
            this.displays = new ArrayList<>();
            this.startLocation = player.getLocation().clone();
        }

        public void start() {
            // Spawn 5 orbiting displays
            createDisplays();
            
            // Start animation
            startAnimation();
            
            // Start particle effects
            startParticles();
            
            // Send message
            player.sendMessage(Component.text("Your fate is being decided...")
                .color(NamedTextColor.GOLD)
                .decorate(TextDecoration.BOLD));
        }

        private void createDisplays() {
            CardType[] allTypes = {CardType.TIME, CardType.GRAVITY, CardType.GLITCH, 
                                  CardType.THUNDER, CardType.SOUL};
            
            Location center = player.getEyeLocation();
            
            for (int i = 0; i < 5; i++) {
                double angle = (i * 2 * Math.PI / 5);
                double x = center.getX() + RADIUS * Math.cos(angle);
                double z = center.getZ() + RADIUS * Math.sin(angle);
                
                Location spawnLoc = new Location(center.getWorld(), x, center.getY(), z);
                
                int typeIndex = i % allTypes.length;
                ItemStack displayItem = CardUtil.createCard(plugin, allTypes[typeIndex], player.getUniqueId());
                
                ItemDisplay display = player.getWorld().spawn(spawnLoc, ItemDisplay.class, entity -> {
                    entity.setItemStack(displayItem);
                    entity.setBillboard(Display.Billboard.VERTICAL);
                    entity.setViewRange(64.0f);
                    
                    org.joml.Matrix4f matrix = new org.joml.Matrix4f()
                        .identity()
                        .scale(0.6f, 0.6f, 0.6f);
                    entity.setTransformationMatrix(matrix);
                });
                
                displays.add(display);
            }
        }

        private void startAnimation() {
            animationTask = new BukkitRunnable() {
                int tick = 0;
                double baseSpeed = 0.3;
                
                @Override
                public void run() {
                    if (!player.isOnline() || tick >= SPIN_DURATION) {
                        finishSpin();
                        cancel();
                        return;
                    }
                    
                    // Check if player moved too far
                    if (startLocation.distance(player.getLocation()) > 5) {
                        player.sendMessage(Component.text("Spin cancelled - you moved too far!").color(NamedTextColor.RED));
                        cleanup();
                        cancel();
                        return;
                    }
                    
                    // Exponential slowdown
                    double progress = (double) tick / SPIN_DURATION;
                    double speed = baseSpeed * Math.pow(1 - progress, 2);
                    
                    Location center = player.getEyeLocation();
                    
                    for (int i = 0; i < displays.size(); i++) {
                        ItemDisplay display = displays.get(i);
                        if (display == null || !display.isValid()) continue;
                        
                        double angle = (tick * speed) + (i * 2 * Math.PI / 5);
                        double x = center.getX() + RADIUS * Math.cos(angle);
                        double z = center.getZ() + RADIUS * Math.sin(angle);
                        
                        Location displayLoc = new Location(center.getWorld(), x, center.getY(), z);
                        display.teleport(displayLoc);
                    }
                    
                    tick++;
                }
            }.runTaskTimer(plugin, 0L, 1L);
        }

        private void startParticles() {
            particleTask = new BukkitRunnable() {
                int tick = 0;
                
                @Override
                public void run() {
                    if (!player.isOnline() || tick >= SPIN_DURATION) {
                        cancel();
                        return;
                    }
                    
                    if (tick % 3 == 0) { // Only spawn every 3 ticks
                        Location center = player.getEyeLocation();
                        
                        for (int i = 0; i < 3; i++) {
                            double angle = random.nextDouble() * 2 * Math.PI;
                            double r = RADIUS + random.nextDouble() * 0.5;
                            double x = center.getX() + r * Math.cos(angle);
                            double z = center.getZ() + r * Math.sin(angle);
                            
                            Location particleLoc = new Location(center.getWorld(), x, center.getY(), z);
                            center.getWorld().spawnParticle(Particle.END_ROD, particleLoc, 1, 0, 0, 0, 0);
                            center.getWorld().spawnParticle(Particle.ENCHANT, particleLoc, 1, 0.1, 0.1, 0.1, 0);
                        }
                    }
                    
                    tick++;
                }
            }.runTaskTimer(plugin, 0L, 1L);
        }

        private void finishSpin() {
            // Remove existing cards
            removeExistingCards(player);
            
            // Give winning card
            ItemStack card = CardUtil.createCard(plugin, winningCard, player.getUniqueId());
            player.getInventory().addItem(card);
            
            // Register card
            plugin.getCardRegistryManager().registerCard(player, winningCard);
            
            // Mark as received starter
            markHasStarterCard(player);
            
            // Win effects
            playWinEffects();
            
            // Restore walk speed
            player.setWalkSpeed(0.2f);
            
            // Delay display cleanup
            Bukkit.getScheduler().runTaskLater(plugin, this::cleanup, 60L);
            
            // Remove from active sessions
            activeSessions.remove(player.getUniqueId());
        }

        private void playWinEffects() {
            Location loc = player.getLocation().add(0, 1, 0);
            
            // Particle burst
            loc.getWorld().spawnParticle(Particle.FLASH, loc, 1, 0, 0, 0, 0);
            loc.getWorld().spawnParticle(Particle.SOUL_FIRE_FLAME, loc, 20, 0.5, 0.5, 0.5, 0.1);
            loc.getWorld().spawnParticle(Particle.TOTEM_OF_UNDYING, loc, 15, 0.3, 0.3, 0.3, 0.05);
            
            // Sound effects
            player.playSound(loc, Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.0f);
            player.playSound(loc, Sound.BLOCK_BEACON_ACTIVATE, 1.0f, 1.2f);
            
            // Message
            player.sendMessage(Component.empty());
            player.sendMessage(Component.text("╔═══════════════════════╗")
                .color(NamedTextColor.GOLD)
                .decorate(TextDecoration.BOLD));
            player.sendMessage(Component.text("║  ").color(NamedTextColor.GOLD)
                .append(Component.text("YOU RECEIVED").color(NamedTextColor.YELLOW))
                .append(Component.text("  ║").color(NamedTextColor.GOLD)));
            player.sendMessage(Component.text("║   ").color(NamedTextColor.GOLD)
                .append(Component.text(winningCard.getDisplayName())
                    .color(NamedTextColor.WHITE)
                    .decorate(TextDecoration.BOLD))
                .append(Component.text("   ║").color(NamedTextColor.GOLD)));
            player.sendMessage(Component.text("╚═══════════════════════╝")
                .color(NamedTextColor.GOLD)
                .decorate(TextDecoration.BOLD));
            player.sendMessage(Component.empty());
        }

        public void cleanup() {
            // Cancel tasks
            if (animationTask != null) {
                animationTask.cancel();
            }
            if (particleTask != null) {
                particleTask.cancel();
            }
            
            // Remove displays
            for (ItemDisplay display : displays) {
                if (display != null && display.isValid()) {
                    display.remove();
                }
            }
            displays.clear();
            
            // Restore walk speed
            if (player.isOnline()) {
                player.setWalkSpeed(0.2f);
            }
        }
    }
}
