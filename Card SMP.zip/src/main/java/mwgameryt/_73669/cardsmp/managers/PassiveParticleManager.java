package mwgameryt._73669.cardsmp.managers;

import mwgameryt._73669.cardsmp.CardSMPPlugin;
import mwgameryt._73669.cardsmp.model.CardType;
import mwgameryt._73669.cardsmp.util.CardUtil;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

/**
 * Manages optimized passive particle effects when players hold cards
 * Implements strict performance constraints and distance checks
 */
public class PassiveParticleManager {

    private final CardSMPPlugin plugin;
    private final Map<UUID, BukkitTask> particleTasks;
    private final Random random;
    
    private static final int MAX_PARTICLES_PER_CYCLE = 20;
    private static final int HEAVY_PARTICLE_INTERVAL = 3; // Heavy particles spawn every 3 ticks

    public PassiveParticleManager(CardSMPPlugin plugin) {
        this.plugin = plugin;
        this.particleTasks = new HashMap<>();
        this.random = new Random();
    }

    /**
     * Start passive particles for a player holding a card
     */
    public void startPassiveParticles(Player player, CardType cardType) {
        UUID uuid = player.getUniqueId();
        
        // Cancel existing task if any
        stopPassiveParticles(player);
        
        BukkitTask task = new BukkitRunnable() {
            int tickCounter = 0;
            
            @Override
            public void run() {
                if (!player.isOnline()) {
                    stopPassiveParticles(player);
                    cancel();
                    return;
                }
                
                // Verify player still holds the card
                ItemStack handItem = player.getInventory().getItemInMainHand();
                if (!CardUtil.isCard(plugin, handItem) || CardUtil.getCardType(plugin, handItem) != cardType) {
                    stopPassiveParticles(player);
                    cancel();
                    return;
                }
                
                // Distance check - only spawn particles if players are nearby
                boolean hasNearbyPlayers = player.getWorld().getPlayers().stream()
                    .anyMatch(p -> !p.equals(player) && p.getLocation().distance(player.getLocation()) <= 32);
                
                if (!hasNearbyPlayers && !plugin.getConfig().getBoolean("settings.always-show-particles", false)) {
                    tickCounter++;
                    return;
                }
                
                Location loc = player.getLocation().add(0, 1, 0);
                
                // Spawn particles based on card type
                switch (cardType) {
                    case TIME -> spawnTimeParticles(loc, tickCounter);
                    case GRAVITY -> spawnGravityParticles(loc, tickCounter);
                    case GLITCH -> spawnGlitchParticles(loc, tickCounter);
                    case THUNDER -> spawnThunderParticles(loc, tickCounter);
                    case SOUL -> spawnSoulParticles(loc, tickCounter);
                    case DEMON -> spawnDemonParticles(loc, tickCounter);
                    case REVIVAL -> spawnRevivalParticles(loc, tickCounter);
                }
                
                tickCounter++;
            }
        }.runTaskTimer(plugin, 0L, 1L);
        
        particleTasks.put(uuid, task);
    }

    /**
     * Stop passive particles for a player
     */
    public void stopPassiveParticles(Player player) {
        BukkitTask task = particleTasks.remove(player.getUniqueId());
        if (task != null) {
            task.cancel();
        }
    }

    /**
     * Time Card particles: END_ROD, WHITE_ASH, ENCHANT
     */
    private void spawnTimeParticles(Location loc, int tick) {
        double radius = 0.5;
        int particles = 0;
        
        // Circular pattern
        for (int i = 0; i < 8 && particles < MAX_PARTICLES_PER_CYCLE; i++) {
            double angle = (tick * 0.1) + (i * Math.PI / 4);
            double x = loc.getX() + radius * Math.cos(angle);
            double z = loc.getZ() + radius * Math.sin(angle);
            Location particleLoc = new Location(loc.getWorld(), x, loc.getY(), z);
            
            loc.getWorld().spawnParticle(Particle.END_ROD, particleLoc, 1, 0, 0, 0, 0);
            particles++;
            
            if (tick % HEAVY_PARTICLE_INTERVAL == 0) {
                loc.getWorld().spawnParticle(Particle.ENCHANT, particleLoc, 1, 0.1, 0.1, 0.1, 0);
                particles++;
            }
        }
        
        if (tick % HEAVY_PARTICLE_INTERVAL == 0 && particles < MAX_PARTICLES_PER_CYCLE) {
            loc.getWorld().spawnParticle(Particle.WAX_OFF, loc, 2, 0.2, 0.2, 0.2, 0);
        }
    }

    /**
     * Gravity Card particles: REVERSE_PORTAL, SQUID_INK, DRAGON_BREATH
     */
    private void spawnGravityParticles(Location loc, int tick) {
        if (tick % HEAVY_PARTICLE_INTERVAL != 0) return;
        
        int particles = 0;
        
        // Spiral inward effect
        for (int i = 0; i < 6 && particles < MAX_PARTICLES_PER_CYCLE; i++) {
            double angle = (tick * 0.15) + (i * Math.PI / 3);
            double radius = 0.8 - (tick % 20) * 0.04;
            double x = loc.getX() + radius * Math.cos(angle);
            double z = loc.getZ() + radius * Math.sin(angle);
            Location particleLoc = new Location(loc.getWorld(), x, loc.getY(), z);
            
            loc.getWorld().spawnParticle(Particle.REVERSE_PORTAL, particleLoc, 2, 0, 0, 0, 0);
            particles += 2;
            
            if (random.nextBoolean()) {
                loc.getWorld().spawnParticle(Particle.SQUID_INK, particleLoc, 1, 0, 0, 0, 0);
                particles++;
            }
        }
    }

    /**
     * Glitch Card particles: ELECTRIC_SPARK, CRIT, SMALL_FLAME
     */
    private void spawnGlitchParticles(Location loc, int tick) {
        int particles = 0;
        
        // Random glitch positions
        for (int i = 0; i < 5 && particles < MAX_PARTICLES_PER_CYCLE; i++) {
            double offsetX = (random.nextDouble() - 0.5) * 1.0;
            double offsetY = (random.nextDouble() - 0.5) * 1.0;
            double offsetZ = (random.nextDouble() - 0.5) * 1.0;
            
            Location particleLoc = loc.clone().add(offsetX, offsetY, offsetZ);
            loc.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, particleLoc, 1, 0, 0, 0, 0);
            particles++;
            
            if (random.nextInt(3) == 0) {
                loc.getWorld().spawnParticle(Particle.CRIT, particleLoc, 1, 0, 0, 0, 0);
                particles++;
            }
        }
    }

    /**
     * Thunder Card particles: ELECTRIC_SPARK, FLASH, CLOUD
     */
    private void spawnThunderParticles(Location loc, int tick) {
        int particles = 0;
        
        // Vertical lightning-like pattern
        for (double y = 0; y <= 1.5 && particles < MAX_PARTICLES_PER_CYCLE; y += 0.3) {
            Location particleLoc = loc.clone().add(
                (random.nextDouble() - 0.5) * 0.3,
                y,
                (random.nextDouble() - 0.5) * 0.3
            );
            
            loc.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, particleLoc, 1, 0.1, 0.1, 0.1, 0);
            particles++;
            
            if (tick % HEAVY_PARTICLE_INTERVAL == 0) {
                loc.getWorld().spawnParticle(Particle.CLOUD, particleLoc, 1, 0, 0, 0, 0);
                particles++;
            }
        }
    }

    /**
     * Soul Card particles: SOUL, SOUL_FIRE_FLAME, SCULK_SOUL
     */
    private void spawnSoulParticles(Location loc, int tick) {
        if (tick % HEAVY_PARTICLE_INTERVAL != 0) return;
        
        int particles = 0;
        
        // Floating soul effect
        for (int i = 0; i < 4 && particles < MAX_PARTICLES_PER_CYCLE; i++) {
            double angle = (tick * 0.08) + (i * Math.PI / 2);
            double x = loc.getX() + 0.4 * Math.cos(angle);
            double z = loc.getZ() + 0.4 * Math.sin(angle);
            double y = loc.getY() + Math.sin(tick * 0.1 + i) * 0.3;
            
            Location particleLoc = new Location(loc.getWorld(), x, y, z);
            loc.getWorld().spawnParticle(Particle.SOUL, particleLoc, 1, 0, 0.05, 0, 0);
            particles++;
            
            if (random.nextBoolean()) {
                loc.getWorld().spawnParticle(Particle.SOUL_FIRE_FLAME, particleLoc, 1, 0, 0, 0, 0);
                particles++;
            }
        }
    }

    /**
     * Demon Card particles: FLAME, SOUL_FIRE_FLAME, CRIMSON_SPORE
     */
    private void spawnDemonParticles(Location loc, int tick) {
        if (tick % HEAVY_PARTICLE_INTERVAL != 0) return;
        
        int particles = 0;
        
        // Ring of fire
        for (int i = 0; i < 6 && particles < MAX_PARTICLES_PER_CYCLE; i++) {
            double angle = (tick * 0.12) + (i * Math.PI / 3);
            double x = loc.getX() + 0.6 * Math.cos(angle);
            double z = loc.getZ() + 0.6 * Math.sin(angle);
            
            Location particleLoc = new Location(loc.getWorld(), x, loc.getY(), z);
            loc.getWorld().spawnParticle(Particle.FLAME, particleLoc, 1, 0, 0, 0, 0);
            particles++;
            
            if (random.nextInt(3) == 0) {
                loc.getWorld().spawnParticle(Particle.SOUL_FIRE_FLAME, particleLoc, 1, 0, 0, 0, 0);
                particles++;
            }
        }
    }

    /**
     * Revival Card particles: TOTEM, GLOW, END_ROD
     */
    private void spawnRevivalParticles(Location loc, int tick) {
        if (tick % HEAVY_PARTICLE_INTERVAL != 0) return;
        
        int particles = 0;
        
        // Upward spiraling effect
        double angle = tick * 0.2;
        double radius = 0.4;
        double height = (tick % 30) * 0.05;
        
        for (int i = 0; i < 3 && particles < MAX_PARTICLES_PER_CYCLE; i++) {
            double currentAngle = angle + (i * 2 * Math.PI / 3);
            double x = loc.getX() + radius * Math.cos(currentAngle);
            double z = loc.getZ() + radius * Math.sin(currentAngle);
            
            Location particleLoc = new Location(loc.getWorld(), x, loc.getY() + height, z);
            loc.getWorld().spawnParticle(Particle.GLOW, particleLoc, 1, 0, 0, 0, 0);
            particles++;
            
            loc.getWorld().spawnParticle(Particle.END_ROD, particleLoc, 1, 0, 0.1, 0, 0);
            particles++;
        }
    }

    /**
     * Cleanup all particle tasks
     */
    public void cleanup() {
        particleTasks.values().forEach(BukkitTask::cancel);
        particleTasks.clear();
    }

    /**
     * Cleanup for specific player
     */
    public void cleanup(Player player) {
        stopPassiveParticles(player);
    }
}
