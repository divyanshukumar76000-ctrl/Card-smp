package mwgameryt._73669.cardsmp.managers;

import org.bukkit.attribute.Attribute;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.*;

/**
 * Manages entity freezing for Time Card
 * Stores and restores original entity states
 */
public class FreezeManager {

    private final Plugin plugin;
    private final Map<UUID, FrozenEntityData> frozenEntities;

    public FreezeManager(Plugin plugin) {
        this.plugin = plugin;
        this.frozenEntities = new HashMap<>();
    }

    /**
     * Freeze an entity
     * 
     * @param entity The entity to freeze
     */
    public void freezeEntity(Entity entity) {
        if (!(entity instanceof LivingEntity living)) {
            return;
        }

        UUID uuid = entity.getUniqueId();
        if (frozenEntities.containsKey(uuid)) {
            return; // Already frozen
        }

        // Store original data
        FrozenEntityData data = new FrozenEntityData(living);
        frozenEntities.put(uuid, data);

        // Apply freeze effects
        living.setAI(false);
        
        // Set movement speeds to 0
        var moveAttr = living.getAttribute(Attribute.MOVEMENT_SPEED);
        if (moveAttr != null) moveAttr.setBaseValue(0);
        
        var flyAttr = living.getAttribute(Attribute.FLYING_SPEED);
        if (flyAttr != null) flyAttr.setBaseValue(0);
        
        // Add slowness and jump boost to prevent movement
        living.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, Integer.MAX_VALUE, 255, false, false));
        living.addPotionEffect(new PotionEffect(PotionEffectType.JUMP_BOOST, Integer.MAX_VALUE, 250, false, false));
        
        // Freeze velocity
        living.setVelocity(living.getVelocity().zero());
    }

    /**
     * Unfreeze an entity
     * 
     * @param entity The entity to unfreeze
     */
    public void unfreezeEntity(Entity entity) {
        if (!(entity instanceof LivingEntity living)) {
            return;
        }

        UUID uuid = entity.getUniqueId();
        FrozenEntityData data = frozenEntities.remove(uuid);
        
        if (data == null) {
            return; // Not frozen
        }

        // Restore original data
        living.setAI(data.hadAI);
        
        var moveAttr = living.getAttribute(Attribute.MOVEMENT_SPEED);
        if (moveAttr != null) moveAttr.setBaseValue(data.movementSpeed);
        
        var flyAttr = living.getAttribute(Attribute.FLYING_SPEED);
        if (flyAttr != null) flyAttr.setBaseValue(data.flyingSpeed);
        
        // Remove freeze effects
        living.removePotionEffect(PotionEffectType.SLOWNESS);
        living.removePotionEffect(PotionEffectType.JUMP_BOOST);
    }

    /**
     * Check if an entity is frozen
     * 
     * @param entity The entity to check
     * @return True if the entity is frozen
     */
    public boolean isFrozen(Entity entity) {
        return frozenEntities.containsKey(entity.getUniqueId());
    }

    /**
     * Cleanup all frozen entities
     */
    public void cleanup() {
        List<UUID> toUnfreeze = new ArrayList<>(frozenEntities.keySet());
        
        for (UUID uuid : toUnfreeze) {
            // Find the entity and unfreeze it
            plugin.getServer().getWorlds().forEach(world -> {
                world.getEntities().stream()
                    .filter(e -> e.getUniqueId().equals(uuid))
                    .findFirst()
                    .ifPresent(this::unfreezeEntity);
            });
        }
        
        frozenEntities.clear();
    }

    /**
     * Get all frozen entity UUIDs
     * 
     * @return Set of frozen entity UUIDs
     */
    public Set<UUID> getFrozenEntities() {
        return new HashSet<>(frozenEntities.keySet());
    }

    /**
     * Data class to store original entity state
     */
    private static class FrozenEntityData {
        boolean hadAI;
        double movementSpeed;
        double flyingSpeed;

        FrozenEntityData(LivingEntity entity) {
            this.hadAI = entity.hasAI();
            
            var moveAttr = entity.getAttribute(Attribute.MOVEMENT_SPEED);
            this.movementSpeed = moveAttr != null ? moveAttr.getBaseValue() : 0.7;
            
            var flyAttr = entity.getAttribute(Attribute.FLYING_SPEED);
            this.flyingSpeed = flyAttr != null ? flyAttr.getBaseValue() : 0.4;
        }
    }
}
