package mwgameryt._73669.cardsmp.managers;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Manages cooldowns for card abilities
 * Tracks cooldown expiration times and provides utility methods
 */
public class CooldownManager {

    private final Plugin plugin;
    private final Map<UUID, Map<String, Long>> cooldowns;

    public CooldownManager(Plugin plugin) {
        this.plugin = plugin;
        this.cooldowns = new HashMap<>();
    }

    /**
     * Set a cooldown for a player and ability
     * 
     * @param player The player
     * @param abilityId The ability identifier
     * @param duration Cooldown duration in milliseconds
     */
    public void setCooldown(Player player, String abilityId, long duration) {
        UUID uuid = player.getUniqueId();
        cooldowns.computeIfAbsent(uuid, k -> new HashMap<>());
        cooldowns.get(uuid).put(abilityId, System.currentTimeMillis() + duration);
    }

    /**
     * Check if a player has an active cooldown
     * 
     * @param player The player to check
     * @param abilityId The ability identifier
     * @return True if cooldown is active
     */
    public boolean hasCooldown(Player player, String abilityId) {
        UUID uuid = player.getUniqueId();
        if (!cooldowns.containsKey(uuid)) {
            return false;
        }
        
        Map<String, Long> playerCooldowns = cooldowns.get(uuid);
        if (!playerCooldowns.containsKey(abilityId)) {
            return false;
        }
        
        long expireTime = playerCooldowns.get(abilityId);
        if (System.currentTimeMillis() >= expireTime) {
            playerCooldowns.remove(abilityId);
            return false;
        }
        
        return true;
    }

    /**
     * Get remaining cooldown time in milliseconds
     * 
     * @param player The player
     * @param abilityId The ability identifier
     * @return Remaining time in milliseconds, or 0 if no cooldown
     */
    public long getRemainingCooldown(Player player, String abilityId) {
        UUID uuid = player.getUniqueId();
        if (!cooldowns.containsKey(uuid)) {
            return 0;
        }
        
        Map<String, Long> playerCooldowns = cooldowns.get(uuid);
        if (!playerCooldowns.containsKey(abilityId)) {
            return 0;
        }
        
        long expireTime = playerCooldowns.get(abilityId);
        long remaining = expireTime - System.currentTimeMillis();
        
        return Math.max(0, remaining);
    }

    /**
     * Send cooldown message to player via ActionBar
     * 
     * @param player The player
     * @param abilityId The ability identifier
     */
    public void sendCooldownMessage(Player player, String abilityId) {
        long remaining = getRemainingCooldown(player, abilityId);
        if (remaining <= 0) {
            return;
        }
        
        long seconds = (remaining / 1000) + 1;
        String timeFormatted = formatTime(seconds);
        
        Component message = Component.text("Cooldown: " + timeFormatted)
                .color(NamedTextColor.RED);
        player.sendActionBar(message);
    }

    /**
     * Format time for display
     */
    private String formatTime(long seconds) {
        if (seconds < 60) {
            return seconds + "s";
        }
        long minutes = seconds / 60;
        long remainingSeconds = seconds % 60;
        if (remainingSeconds == 0) {
            return minutes + "m";
        }
        return minutes + "m " + remainingSeconds + "s";
    }

    /**
     * Clear all cooldowns for a player
     * 
     * @param player The player
     */
    public void clearCooldowns(Player player) {
        cooldowns.remove(player.getUniqueId());
    }

    /**
     * Clear a specific cooldown
     * 
     * @param player The player
     * @param abilityId The ability identifier
     */
    public void clearCooldown(Player player, String abilityId) {
        UUID uuid = player.getUniqueId();
        if (cooldowns.containsKey(uuid)) {
            cooldowns.get(uuid).remove(abilityId);
        }
    }
}
