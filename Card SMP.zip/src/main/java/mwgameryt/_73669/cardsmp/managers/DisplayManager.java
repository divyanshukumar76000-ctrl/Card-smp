package mwgameryt._73669.cardsmp.managers;

import mwgameryt._73669.cardsmp.model.CardType;
import mwgameryt._73669.cardsmp.util.CardUtil;
import org.bukkit.Location;
import org.bukkit.entity.Display;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.joml.AxisAngle4f;
import org.joml.Vector3f;

import java.util.*;

/**
 * Manages ItemDisplay entities for Demon Card orbit effect
 * Handles creation, animation, and cleanup of orbiting displays
 */
public class DisplayManager {

    private final Plugin plugin;
    private final Map<UUID, List<ItemDisplay>> playerDisplays;
    private final Map<UUID, BukkitTask> orbitTasks;

    public DisplayManager(Plugin plugin) {
        this.plugin = plugin;
        this.playerDisplays = new HashMap<>();
        this.orbitTasks = new HashMap<>();
    }

    /**
     * Create orbiting displays for a player
     * 
     * @param player The player
     * @param cardType The card type to display
     * @param radius The orbit radius
     * @param rotationSpeed The rotation speed
     */
    public void createOrbitingDisplays(Player player, CardType cardType, double radius, double rotationSpeed) {
        // Remove existing displays
        removeDisplays(player);

        List<ItemDisplay> displays = new ArrayList<>();
        Location playerLoc = player.getLocation();

        // Create 5 orbiting displays
        for (int i = 0; i < 5; i++) {
            ItemStack displayItem = CardUtil.createCard(plugin, cardType, player.getUniqueId());
            
            Location spawnLoc = playerLoc.clone().add(0, 1.5, 0);
            ItemDisplay display = player.getWorld().spawn(spawnLoc, ItemDisplay.class, (entity) -> {
                entity.setItemStack(displayItem);
                entity.setBillboard(Display.Billboard.VERTICAL);
                entity.setViewRange(64.0f);
                
                // Set transform scale using JOML Transformation
                org.joml.Matrix4f matrix = new org.joml.Matrix4f()
                    .identity()
                    .scale(0.5f, 0.5f, 0.5f);
                entity.setTransformationMatrix(matrix);
            });
            
            displays.add(display);
        }

        playerDisplays.put(player.getUniqueId(), displays);

        // Start orbit animation
        startOrbitAnimation(player, radius, rotationSpeed);
    }

    /**
     * Start the orbit animation task
     * 
     * @param player The player
     * @param radius The orbit radius
     * @param rotationSpeed The rotation speed (radians per tick)
     */
    private void startOrbitAnimation(Player player, double radius, double rotationSpeed) {
        UUID uuid = player.getUniqueId();
        
        BukkitTask task = new BukkitRunnable() {
            double angle = 0;
            
            @Override
            public void run() {
                if (!player.isOnline() || !playerDisplays.containsKey(uuid)) {
                    cancel();
                    return;
                }

                List<ItemDisplay> displays = playerDisplays.get(uuid);
                Location center = player.getLocation().add(0, 1.5, 0);

                // Update each display position
                for (int i = 0; i < displays.size(); i++) {
                    ItemDisplay display = displays.get(i);
                    
                    if (display == null || !display.isValid()) {
                        continue;
                    }

                    // Calculate position using trigonometry
                    double currentAngle = angle + (i * 2 * Math.PI / 5);
                    double x = center.getX() + radius * Math.cos(currentAngle);
                    double z = center.getZ() + radius * Math.sin(currentAngle);
                    
                    Location displayLoc = new Location(center.getWorld(), x, center.getY(), z);
                    display.teleport(displayLoc);
                }

                angle += rotationSpeed;
                if (angle >= 2 * Math.PI) {
                    angle -= 2 * Math.PI;
                }
            }
        }.runTaskTimer(plugin, 0L, 1L);

        orbitTasks.put(uuid, task);
    }

    /**
     * Remove displays for a player
     * 
     * @param player The player
     */
    public void removeDisplays(Player player) {
        UUID uuid = player.getUniqueId();

        // Cancel orbit task
        BukkitTask task = orbitTasks.remove(uuid);
        if (task != null) {
            task.cancel();
        }

        // Remove display entities
        List<ItemDisplay> displays = playerDisplays.remove(uuid);
        if (displays != null) {
            for (ItemDisplay display : displays) {
                if (display != null && display.isValid()) {
                    display.remove();
                }
            }
        }
    }

    /**
     * Check if a player has active displays
     * 
     * @param player The player
     * @return True if the player has displays
     */
    public boolean hasDisplays(Player player) {
        return playerDisplays.containsKey(player.getUniqueId());
    }

    /**
     * Cleanup all displays
     */
    public void cleanup() {
        // Cancel all tasks
        orbitTasks.values().forEach(BukkitTask::cancel);
        orbitTasks.clear();

        // Remove all displays
        playerDisplays.values().forEach(displays -> 
            displays.forEach(display -> {
                if (display != null && display.isValid()) {
                    display.remove();
                }
            })
        );
        playerDisplays.clear();
    }

    /**
     * Get displays for a player
     * 
     * @param player The player
     * @return List of ItemDisplays, or null if none
     */
    public List<ItemDisplay> getDisplays(Player player) {
        return playerDisplays.get(player.getUniqueId());
    }
}
