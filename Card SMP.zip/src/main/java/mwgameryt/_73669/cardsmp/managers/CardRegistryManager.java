package mwgameryt._73669.cardsmp.managers;

import mwgameryt._73669.cardsmp.model.CardType;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Manages player card registrations
 * Tracks which card each player has registered and persists data
 */
public class CardRegistryManager {

    private final Plugin plugin;
    private final Map<UUID, CardType> registeredCards;
    private File dataFile;
    private FileConfiguration dataConfig;

    public CardRegistryManager(Plugin plugin) {
        this.plugin = plugin;
        this.registeredCards = new HashMap<>();
        setupDataFile();
    }

    /**
     * Setup the player data file
     */
    private void setupDataFile() {
        File dataFolder = new File(plugin.getDataFolder(), "playerdata");
        if (!dataFolder.exists()) {
            dataFolder.mkdirs();
        }
        
        dataFile = new File(dataFolder, "playerdata.yml");
        if (!dataFile.exists()) {
            try {
                dataFile.createNewFile();
            } catch (IOException e) {
                plugin.getLogger().severe("Could not create playerdata.yml!");
                e.printStackTrace();
            }
        }
        
        dataConfig = YamlConfiguration.loadConfiguration(dataFile);
    }

    /**
     * Register a card for a player
     * 
     * @param player The player
     * @param cardType The card type to register
     */
    public void registerCard(Player player, CardType cardType) {
        registeredCards.put(player.getUniqueId(), cardType);
        saveData();
    }

    /**
     * Get a player's registered card
     * 
     * @param player The player
     * @return The registered CardType, or null if none
     */
    public CardType getRegisteredCard(Player player) {
        return registeredCards.get(player.getUniqueId());
    }

    /**
     * Check if a player has a registered card
     * 
     * @param player The player
     * @return True if the player has a registered card
     */
    public boolean hasRegisteredCard(Player player) {
        return registeredCards.containsKey(player.getUniqueId());
    }

    /**
     * Unregister a player's card
     * 
     * @param player The player
     */
    public void unregisterCard(Player player) {
        registeredCards.remove(player.getUniqueId());
        saveData();
    }

    /**
     * Save player data to file
     */
    public void saveData() {
        for (Map.Entry<UUID, CardType> entry : registeredCards.entrySet()) {
            dataConfig.set(entry.getKey().toString(), entry.getValue().getAbilityId());
        }
        
        try {
            dataConfig.save(dataFile);
        } catch (IOException e) {
            plugin.getLogger().severe("Could not save playerdata.yml!");
            e.printStackTrace();
        }
    }

    /**
     * Load player data from file
     */
    public void loadData() {
        for (String key : dataConfig.getKeys(false)) {
            try {
                UUID uuid = UUID.fromString(key);
                String abilityId = dataConfig.getString(key);
                CardType cardType = CardType.fromAbilityId(abilityId);
                
                if (cardType != null) {
                    registeredCards.put(uuid, cardType);
                }
            } catch (IllegalArgumentException e) {
                plugin.getLogger().warning("Invalid UUID in playerdata.yml: " + key);
            }
        }
        
        plugin.getLogger().info("Loaded " + registeredCards.size() + " player registrations");
    }
}
