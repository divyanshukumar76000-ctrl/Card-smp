package mwgameryt._73669.cardsmp.managers;

import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.plugin.Plugin;
import org.bukkit.util.Vector;

/**
 * Manages particle effects for card abilities
 * Provides optimized particle spawning methods
 */
public class ParticleManager {

    private final Plugin plugin;
    private final int maxParticlesPerCycle;

    public ParticleManager(Plugin plugin) {
        this.plugin = plugin;
        this.maxParticlesPerCycle = plugin.getConfig().getInt("settings.max-particles", 30);
    }

    /**
     * Spawn a circle of particles
     * 
     * @param center The center location
     * @param radius The circle radius
     * @param particle The particle type
     * @param count Number of particles
     */
    public void spawnCircle(Location center, double radius, Particle particle, int count) {
        World world = center.getWorld();
        if (world == null) return;

        count = Math.min(count, maxParticlesPerCycle);
        double angleIncrement = (2 * Math.PI) / count;

        for (int i = 0; i < count; i++) {
            double angle = i * angleIncrement;
            double x = center.getX() + radius * Math.cos(angle);
            double z = center.getZ() + radius * Math.sin(angle);
            
            Location particleLocation = new Location(world, x, center.getY(), z);
            world.spawnParticle(particle, particleLocation, 1, 0, 0, 0, 0);
        }
    }

    /**
     * Spawn a sphere of particles
     * 
     * @param center The center location
     * @param radius The sphere radius
     * @param particle The particle type
     * @param count Number of particles
     */
    public void spawnSphere(Location center, double radius, Particle particle, int count) {
        World world = center.getWorld();
        if (world == null) return;

        count = Math.min(count, maxParticlesPerCycle);

        for (int i = 0; i < count; i++) {
            double phi = Math.random() * Math.PI;
            double theta = Math.random() * 2 * Math.PI;
            
            double x = radius * Math.sin(phi) * Math.cos(theta);
            double y = radius * Math.sin(phi) * Math.sin(theta);
            double z = radius * Math.cos(phi);
            
            Location particleLocation = center.clone().add(x, y, z);
            world.spawnParticle(particle, particleLocation, 1, 0, 0, 0, 0);
        }
    }

    /**
     * Spawn a spiral of particles
     * 
     * @param center The center location
     * @param radius The spiral radius
     * @param height The spiral height
     * @param particle The particle type
     * @param rotations Number of rotations
     * @param points Points per rotation
     */
    public void spawnSpiral(Location center, double radius, double height, Particle particle, int rotations, int points) {
        World world = center.getWorld();
        if (world == null) return;

        int totalPoints = rotations * points;
        totalPoints = Math.min(totalPoints, maxParticlesPerCycle);
        
        double angleIncrement = (2 * Math.PI) / points;
        double heightIncrement = height / totalPoints;

        for (int i = 0; i < totalPoints; i++) {
            double angle = (i % points) * angleIncrement + (i / points) * (2 * Math.PI / rotations);
            double y = center.getY() + (i * heightIncrement);
            
            double x = center.getX() + radius * Math.cos(angle);
            double z = center.getZ() + radius * Math.sin(angle);
            
            Location particleLocation = new Location(world, x, y, z);
            world.spawnParticle(particle, particleLocation, 1, 0, 0, 0, 0);
        }
    }

    /**
     * Spawn a ring of particles
     * 
     * @param center The center location
     * @param radius The ring radius
     * @param particle The particle type
     * @param count Number of particles
     */
    public void spawnRing(Location center, double radius, Particle particle, int count) {
        spawnCircle(center, radius, particle, count);
    }

    /**
     * Spawn a helix of particles
     * 
     * @param center The center location
     * @param radius The helix radius
     * @param height The helix height
     * @param particle The particle type
     * @param strands Number of strands
     * @param points Points per strand
     */
    public void spawnHelix(Location center, double radius, double height, Particle particle, int strands, int points) {
        World world = center.getWorld();
        if (world == null) return;

        int totalPoints = strands * points;
        totalPoints = Math.min(totalPoints, maxParticlesPerCycle);

        for (int strand = 0; strand < strands; strand++) {
            double strandOffset = (2 * Math.PI / strands) * strand;
            
            for (int i = 0; i < points && (strand * points + i) < totalPoints; i++) {
                double angle = strandOffset + (i * 2 * Math.PI / points);
                double y = center.getY() + (i * height / points);
                
                double x = center.getX() + radius * Math.cos(angle);
                double z = center.getZ() + radius * Math.sin(angle);
                
                Location particleLocation = new Location(world, x, y, z);
                world.spawnParticle(particle, particleLocation, 1, 0, 0, 0, 0);
            }
        }
    }

    /**
     * Spawn particles with velocity
     * 
     * @param location The spawn location
     * @param particle The particle type
     * @param count Number of particles
     * @param velocity The velocity vector
     */
    public void spawnWithVelocity(Location location, Particle particle, int count, Vector velocity) {
        World world = location.getWorld();
        if (world == null) return;

        count = Math.min(count, maxParticlesPerCycle);
        world.spawnParticle(particle, location, count, velocity.getX(), velocity.getY(), velocity.getZ(), 0.1);
    }
}
