package mwgameryt._73669.cardsmp.commands;

import mwgameryt._73669.cardsmp.CardSMPPlugin;
import mwgameryt._73669.cardsmp.gui.CardSelectionGUI;
import mwgameryt._73669.cardsmp.model.CardType;
import mwgameryt._73669.cardsmp.util.CardUtil;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

/**
 * Main command handler for /cardsmp
 * Handles: start, gui, give, reset, reroll
 */
public class CardSMPCommand implements CommandExecutor, TabCompleter {

    private final CardSMPPlugin plugin;
    private final Random random;

    public CardSMPCommand(CardSMPPlugin plugin) {
        this.plugin = plugin;
        this.random = new Random();
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
        if (args.length == 0) {
            sendHelp(sender);
            return true;
        }

        String subcommand = args[0].toLowerCase();

        switch (subcommand) {
            case "start" -> handleStart(sender);
            case "gui" -> handleGui(sender);
            case "give" -> handleGive(sender, args);
            case "reset" -> handleReset(sender);
            case "reroll" -> handleReroll(sender);
            default -> sendHelp(sender);
        }

        return true;
    }

    /**
     * Handle /cardsmp start - Global card spin event for all online players
     */
    private void handleStart(CommandSender sender) {
        if (!sender.hasPermission("cardsmp.admin")) {
            sender.sendMessage(plugin.getConfigUtil().getMessage("no-permission"));
            return;
        }

        plugin.getCardSpinManager().startGlobalSpin();
        sender.sendMessage(Component.text("Card spin event started for all eligible players!").color(NamedTextColor.GREEN));
    }

    /**
     * Handle /cardsmp gui - Opens card selection GUI
     */
    private void handleGui(CommandSender sender) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(plugin.getConfigUtil().getMessage("player-only"));
            return;
        }

        new CardSelectionGUI(plugin, player).open();
    }

    /**
     * Handle /cardsmp give <player> <card> - Give a card to a player
     */
    private void handleGive(CommandSender sender, String[] args) {
        if (!sender.hasPermission("cardsmp.admin")) {
            sender.sendMessage(plugin.getConfigUtil().getMessage("no-permission"));
            return;
        }

        if (args.length < 3) {
            sender.sendMessage(Component.text("Usage: /cardsmp give <player> <card>").color(NamedTextColor.RED));
            return;
        }

        Player target = Bukkit.getPlayer(args[1]);
        if (target == null) {
            sender.sendMessage(Component.text("Player not found!").color(NamedTextColor.RED));
            return;
        }

        CardType cardType;
        try {
            cardType = CardType.valueOf(args[2].toUpperCase());
        } catch (IllegalArgumentException e) {
            sender.sendMessage(Component.text("Invalid card type!").color(NamedTextColor.RED));
            sender.sendMessage(Component.text("Available: " + Arrays.stream(CardType.values())
                    .map(CardType::name)
                    .collect(Collectors.joining(", "))).color(NamedTextColor.GRAY));
            return;
        }

        ItemStack card = CardUtil.createCard(plugin, cardType, target.getUniqueId());
        target.getInventory().addItem(card);

        // Register the card
        plugin.getCardRegistryManager().registerCard(target, cardType);

        sender.sendMessage(plugin.getConfigUtil().getMessage("card-given", "card", cardType.getDisplayName(), "player", target.getName()));
        target.sendMessage(plugin.getConfigUtil().getMessage("card-registered", "card", cardType.getDisplayName()));
    }

    /**
     * Handle /cardsmp reset - Flush cooldowns, terminate runnables, purge displays
     */
    private void handleReset(CommandSender sender) {
        if (!sender.hasPermission("cardsmp.admin")) {
            sender.sendMessage(plugin.getConfigUtil().getMessage("no-permission"));
            return;
        }

        // Reset all online players
        for (Player player : Bukkit.getOnlinePlayers()) {
            plugin.getDisplayManager().removeDisplays(player);
            plugin.getCooldownManager().clearCooldowns(player);
            plugin.getPassiveParticleManager().cleanup(player);
            plugin.getFreezeManager().unfreeze(player);
            plugin.getAbilityManager().cleanup(player);
            plugin.getCardSpinManager().cleanup(player);
            plugin.getRevivalRitualManager().cleanup(player);
        }

        // Cleanup managers
        plugin.getDisplayManager().cleanup();
        plugin.getPassiveParticleManager().cleanup();
        plugin.getCardSpinManager().cleanup();
        plugin.getRevivalRitualManager().cleanup();

        sender.sendMessage(Component.text("All active effects, cooldowns, and runnables have been reset!").color(NamedTextColor.GREEN));
    }

    /**
     * Handle /cardsmp reroll - Validate main hand card, delete it, give random alternative
     */
    private void handleReroll(CommandSender sender) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(plugin.getConfigUtil().getMessage("player-only"));
            return;
        }

        // Check main hand for custom card
        ItemStack handItem = player.getInventory().getItemInMainHand();
        if (!CardUtil.isCard(plugin, handItem)) {
            player.sendMessage(Component.text("You must hold a custom card to reroll!").color(NamedTextColor.RED));
            return;
        }

        CardType currentType = CardUtil.getCardType(plugin, handItem);
        if (currentType == null) {
            player.sendMessage(Component.text("Invalid card!").color(NamedTextColor.RED));
            return;
        }

        // Get all card types except the current one and Revival
        List<CardType> availableTypes = new ArrayList<>(Arrays.asList(CardType.values()));
        availableTypes.remove(currentType);
        availableTypes.remove(CardType.REVIVAL); // Revival is too rare to be rerolled into

        if (availableTypes.isEmpty()) {
            player.sendMessage(Component.text("No other cards available!").color(NamedTextColor.RED));
            return;
        }

        // Select random card
        CardType randomType = availableTypes.get(random.nextInt(availableTypes.size()));

        // Delete current card
        handItem.setAmount(0);

        // Create and give new card
        ItemStack newCard = CardUtil.createCard(plugin, randomType, player.getUniqueId());
        player.getInventory().setItemInMainHand(newCard);

        // Update registration
        plugin.getCardRegistryManager().registerCard(player, randomType);

        // Effects
        Location loc = player.getLocation();
        player.getWorld().spawnParticle(Particle.ENCHANT, loc, 50, 0.5, 1, 0.5, 0);
        player.playSound(loc, Sound.BLOCK_ENCHANTMENT_TABLE_USE, 1.0f, 1.0f);

        sender.sendMessage(Component.text("Card rerolled!").color(NamedTextColor.GREEN));
        sender.sendMessage(Component.text("Previous: ").color(NamedTextColor.GRAY)
            .append(Component.text(currentType.getDisplayName()).color(NamedTextColor.YELLOW)));
        sender.sendMessage(Component.text("New: ").color(NamedTextColor.GRAY)
            .append(Component.text(randomType.getDisplayName()).color(NamedTextColor.GREEN)));
    }

    /**
     * Send help message
     */
    private void sendHelp(CommandSender sender) {
        sender.sendMessage(Component.text("=== Card SMP Commands ===").color(NamedTextColor.GOLD));
        sender.sendMessage(Component.text("/cardsmp gui").color(NamedTextColor.YELLOW)
                .append(Component.text(" - Open card selection GUI").color(NamedTextColor.GRAY)));
        sender.sendMessage(Component.text("/cardsmp reroll").color(NamedTextColor.YELLOW)
                .append(Component.text(" - Reroll your held card").color(NamedTextColor.GRAY)));
        
        if (sender.hasPermission("cardsmp.admin")) {
            sender.sendMessage(Component.text("/cardsmp start").color(NamedTextColor.YELLOW)
                    .append(Component.text(" - Global card spin event").color(NamedTextColor.GRAY)));
            sender.sendMessage(Component.text("/cardsmp give <player> <card>").color(NamedTextColor.YELLOW)
                    .append(Component.text(" - Give a card to a player").color(NamedTextColor.GRAY)));
            sender.sendMessage(Component.text("/cardsmp reset").color(NamedTextColor.YELLOW)
                    .append(Component.text(" - Reset all effects globally").color(NamedTextColor.GRAY)));
        }
    }

    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
        List<String> completions = new ArrayList<>();

        if (args.length == 1) {
            completions.addAll(Arrays.asList("start", "gui", "reset", "reroll"));
            if (sender.hasPermission("cardsmp.admin")) {
                completions.add("give");
            }
        } else if (args.length == 2 && args[0].equalsIgnoreCase("give")) {
            return Bukkit.getOnlinePlayers().stream()
                    .map(Player::getName)
                    .collect(Collectors.toList());
        } else if (args.length == 3 && args[0].equalsIgnoreCase("give")) {
            return Arrays.stream(CardType.values())
                    .map(type -> type.name().toLowerCase())
                    .collect(Collectors.toList());
        }

        return completions.stream()
                .filter(s -> s.toLowerCase().startsWith(args[args.length - 1].toLowerCase()))
                .collect(Collectors.toList());
    }
}
