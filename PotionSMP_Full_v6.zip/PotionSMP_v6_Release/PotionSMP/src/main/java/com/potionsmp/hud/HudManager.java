package com.potionsmp.hud;

import com.potionsmp.PotionSMP;
import com.potionsmp.utils.PotionType;
import net.kyori.adventure.key.Key;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.Style;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.EnumMap;
import java.util.Map;

/**
 * Shows a single ActionBar line (just above the XP bar) combining Slot 1 and
 * Slot 2's status, using graphical icons from the resource pack's custom font
 * (assets/minecraft/font/potionsmp.json):
 *
 *   [ICON] Ready    |    [ICON] 12s
 *
 * Icon characters and colors are registered per PotionType in ICONS below.
 * Add an entry there when implementing a new potion's Ability - the HUD
 * will pick it up automatically without further changes.
 *
 * If a slot is empty, that segment is skipped. If both slots are empty,
 * nothing is sent.
 */
public class HudManager {

    private static final Key ICON_FONT = Key.key("minecraft", "potionsmp");

    private record IconInfo(String character, NamedTextColor color) {}

    private static final Map<PotionType, IconInfo> ICONS = new EnumMap<>(PotionType.class);
    static {
        ICONS.put(PotionType.FIRE, new IconInfo("\uE000", NamedTextColor.RED));
        ICONS.put(PotionType.FREEZE, new IconInfo("\uE001", NamedTextColor.AQUA));
        ICONS.put(PotionType.REGEN, new IconInfo("\uE002", NamedTextColor.GREEN));
        // Add new potions here: ICONS.put(PotionType.X, new IconInfo("\uE00N", color));
    }

    private final PotionSMP plugin;
    private BukkitTask task;

    public HudManager(PotionSMP plugin) {
        this.plugin = plugin;
    }

    public void start() {
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 0L, 10L); // every 0.5s
    }

    public void stop() {
        if (task != null) task.cancel();
    }

    private void tick() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            PotionType slot1 = plugin.getSlotManager().getSlot1(player.getUniqueId());
            PotionType slot2 = plugin.getSlotManager().getSlot2(player.getUniqueId());

            if (slot1 == null && slot2 == null) continue;

            Component bar = Component.empty();

            if (slot1 != null) {
                bar = bar.append(buildSegment(player, slot1));
            }

            if (slot1 != null && slot2 != null) {
                bar = bar.append(Component.text("   |   ", NamedTextColor.DARK_GRAY));
            }

            if (slot2 != null) {
                bar = bar.append(buildSegment(player, slot2));
            }

            player.sendActionBar(bar);
        }
    }

    private Component buildSegment(Player player, PotionType type) {
        boolean onCooldown = plugin.getCooldownManager().isOnCooldown(player.getUniqueId(), type);
        long remaining = plugin.getCooldownManager().getRemainingSeconds(player.getUniqueId(), type);

        IconInfo info = ICONS.get(type);
        Component icon;
        NamedTextColor color;

        if (info != null) {
            icon = Component.text(info.character()).style(Style.style().font(ICON_FONT).build());
            color = info.color();
        } else {
            // Fallback for a potion type that doesn't have an icon registered yet
            icon = Component.text("[" + type.getId() + "]");
            color = NamedTextColor.WHITE;
        }

        Component status;
        if (onCooldown) {
            status = Component.text(" " + remaining + "s", NamedTextColor.YELLOW);
        } else {
            status = Component.text(" Ready", NamedTextColor.GREEN);
        }

        return Component.text().color(color).append(icon).append(status).build();
    }
}
