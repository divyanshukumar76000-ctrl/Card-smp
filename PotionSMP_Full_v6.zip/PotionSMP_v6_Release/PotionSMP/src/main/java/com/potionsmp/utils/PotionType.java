package com.potionsmp.utils;

/**
 * Central registry of every PotionSMP potion type.
 * To add a new potion later: add an entry here, give it a display name +
 * custom-model-data config key, and implement its Ability class.
 */
public enum PotionType {

    FIRE("fire", "&c&l🔥 Fire Potion"),
    FREEZE("freeze", "&b&l❄ Freeze Potion"),
    REGEN("regen", "&a&l❤ Regen Potion");

    // Placeholder slots for the remaining 6 potions - uncomment and implement
    // an Ability class + config block when details are provided:
    // POISON("poison", "&2&l☠ Poison Potion"),
    // LIGHTNING("lightning", "&e&l⚡ Lightning Potion"),
    // SHADOW("shadow", "&5&l🌑 Shadow Potion"),
    // EARTH("earth", "&6&l⛰ Earth Potion"),
    // WIND("wind", "&f&l💨 Wind Potion"),
    // VOID("void", "&8&l🕳 Void Potion");

    private final String id;
    private final String displayName;

    PotionType(String id, String displayName) {
        this.id = id;
        this.displayName = displayName;
    }

    public String getId() {
        return id;
    }

    public String getDisplayName() {
        return PotionUtils.colorize(displayName);
    }

    public static PotionType fromId(String id) {
        if (id == null) return null;
        for (PotionType type : values()) {
            if (type.id.equalsIgnoreCase(id)) return type;
        }
        return null;
    }
}
