package com.potionsmp.utils;

import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.potion.PotionType;

import java.util.List;

public class ItemBuilder {

    public static ItemStack buildPotion(com.potionsmp.utils.PotionType type) {
        ItemStack item = new ItemStack(Material.POTION);
        PotionMeta meta = (PotionMeta) item.getItemMeta();

        meta.setCustomModelData(PotionUtils.getModelData(type));
        meta.setDisplayName(type.getDisplayName());

        switch (type) {
            case FIRE -> {
                meta.setBasePotionType(PotionType.FIRE_RESISTANCE);
                meta.setLore(List.of(
                    PotionUtils.colorize("&7Passive: &fEvery 10 hits ignites enemies"),
                    PotionUtils.colorize("&7Passive: &fInfinite Fire Resistance while equipped"),
                    PotionUtils.colorize("&7Active: &c&lInferno Rage"),
                    PotionUtils.colorize("&f  10x10 fire aura + fire trail"),
                    PotionUtils.colorize("&eDuration: &f10s &7| &eCooldown: &f30s"),
                    PotionUtils.colorize(""),
                    PotionUtils.colorize("&eDrink to equip to Slot 1!")
                ));
            }
            case FREEZE -> {
                meta.setBasePotionType(PotionType.SWIFTNESS);
                meta.setLore(List.of(
                    PotionUtils.colorize("&7Passive: &fEvery 10 hits stuns target for 1s"),
                    PotionUtils.colorize("&7Active: &b&lArctic Prison"),
                    PotionUtils.colorize("&f  10-block freeze blast"),
                    PotionUtils.colorize("&f  Slowness + Mining Fatigue"),
                    PotionUtils.colorize("&eDuration: &f3s &7| &eCooldown: &f45s"),
                    PotionUtils.colorize(""),
                    PotionUtils.colorize("&eDrink to equip to Slot 1!")
                ));
            }
            case REGEN -> {
                meta.setBasePotionType(PotionType.REGENERATION);
                meta.setLore(List.of(
                    PotionUtils.colorize("&7Passive: &fRegeneration I (infinite)"),
                    PotionUtils.colorize("&7Active: &a&lVitality Surge"),
                    PotionUtils.colorize("&f  Double-jump for a 10-block launch"),
                    PotionUtils.colorize("&f  Mace Dive: 10 true hearts on landing hit"),
                    PotionUtils.colorize("&f  Strong regen for 20s"),
                    PotionUtils.colorize("&eDuration: &f20s &7| &eCooldown: &f45s"),
                    PotionUtils.colorize(""),
                    PotionUtils.colorize("&eDrink to equip to Slot 1!")
                ));
            }
        }

        PotionUtils.tagPotion(meta, type);
        item.setItemMeta(meta);
        return item;
    }
}
