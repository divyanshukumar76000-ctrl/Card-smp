# 🧪 PotionSMP Plugin v3 — Slot-Based Ability System

PaperMC / Spigot 1.21.1, Java 21. Supports 9 potions total — 3 implemented now
(Fire, Freeze, Regen), 6 more scaffolded for future details.

## 🧩 Core Concept: Slots, not "active types"

This is a full architecture change from earlier versions:

- Every player has **2 slots**: Slot 1 and Slot 2.
- Drinking ANY potion always goes into **Slot 1**, replacing whatever was
  there before (that old potion's passive effects are removed).
- Slot 2 is untouched by drinking — moving a potion into Slot 2 is done via
  **`/potionSMP swap`**, which swaps Slot 1 ↔ Slot 2.
- Whatever potion occupies a slot has its **passive** ability running
  automatically, all the time, for as long as it's in that slot.
- The **active** ability for whatever's in Slot 1 is triggered by **`/slot1`**;
  Slot 2's active ability by **`/slot2`**.
- Bind `/slot1` to key **X** and `/slot2` to key **Y** using a "Bind Command"
  client mod, so players press a key instead of typing.

## 🎮 Commands

| Command | Description |
|---|---|
| `/potionSMP` | Open the GUI to pick up a potion |
| `/potionSMP give <type> [player]` | Give a potion (op only). Types: `fire`, `freeze`, `regen` |
| `/potionSMP swap` | Swap Slot 1 and Slot 2 |
| `/slot1` | Trigger whatever active ability is in Slot 1 (bind to X) |
| `/slot2` | Trigger whatever active ability is in Slot 2 (bind to Y) |

## 🧊 Implemented Potions

### ❄️ Freeze — Arctic Prison
- **Passive**: every 10 hits, target is "struck" — frozen in place for 1 second (no extra damage, just full lockout).
- **Active** (`/slot1` or `/slot2` when equipped): 10-block radius freeze blast. Everyone in range is locked in place (can't move/attack/use abilities/pearls) for 3 seconds, with Slowness + Mining Fatigue. Ice crystal particles.
- **Cooldown**: 45 seconds.

### 🔥 Fire — Inferno Rage
- **Passive**: every 10 hits, ignites target + nearby enemies (3-block radius). **Infinite Fire Resistance** for as long as Fire Potion is equipped in any slot (removed when unequipped).
- **Active**: 10×10 (radius 5) damage aura around you for 10 seconds — pure particle effect, **no fire blocks placed on the ground**. Anyone standing in it takes damage + ignites once per second. Fire trail follows your movement. No bonus Fire Resistance on activation anymore (it's already infinite from the passive) — this matches your request to remove the old "3-min Fire Resistance on activation" behavior.
- **Cooldown**: 30 seconds.

### ❤️ Regen — Vitality Surge
- **Passive**: permanent Regeneration I for as long as Regen Potion is equipped in any slot.
- **Active**: a two-step trigger.
  1. Run `/slot1` or `/slot2` (whichever has Regen equipped) — this **arms** the ability and starts its 45s cooldown immediately. Nothing happens visually yet.
  2. While armed, jump once normally, **land**, then jump again (ground-to-ground double-tap) — THIS is what actually launches you ~10 blocks up and starts the effects.
  - The moment you launch: 20 seconds of strong Regeneration + Glowing begins immediately (no need to land on anything for this part).
  - While airborne after launching, you're "charged" for a **Mace Dive**: the next hit you land while still airborne deals a flat 10-true-heart bonus hit (works with or without an actual Mace in hand), plus heart explosion + shockwave ring particles, totem-style sparkles, and Mace Smash + Thunder sound.
  - The armed state has no expiry timer — it stays armed until you either complete the double-jump launch, or drink a different potion (which unequips Regen and clears the arm state). It is NOT consumed by just waiting.
- **Cooldown**: 45 seconds (starts the moment you arm it via `/slot1`/`/slot2`, not when you launch).

## 🐛 Bug fix: passive hit-counter inconsistency (7/8/9 instead of exactly 10)

Root cause: Minecraft can fire `EntityDamageByEntityEvent` more than once for what
is visually a single swing (e.g. attack + knockback follow-up, or interaction with
another plugin). `HitCounterManager` now includes a **debounce window**: hits
against the *same target* within 2 ticks of the last counted hit are treated as
one combo hit instead of two, so the passive now reliably triggers at exactly
hit #10 for both Fire and Freeze.

## 📦 Building

```bash
cd PotionSMP
mvn clean package
```

Output: `target/PotionSMP.jar` → drop into `plugins/`.

## 🔗 Texture Pack

`PotionSMP_TexturePack.zip` includes:
- Item textures + CustomModelData overrides for Fire (101), Freeze (102), and
  Regen (103) — both the legacy `models/item/potion.json` system (for 1.21.1-era
  clients) and the new `items/potion.json` system (1.21.4+ clients).
- HUD icon font (`assets/minecraft/font/potionsmp.json`) mapping `\uE000` (fire),
  `\uE001` (freeze), `\uE002` (regen) to your icon art, rendered inline in the
  ActionBar HUD.
- **Regen's icon is currently a placeholder** (simple green heart shape) — swap
  `assets/minecraft/textures/item/regen_potion.png` and
  `assets/minecraft/textures/font/regen_icon.png` with your real art whenever
  you send it, same 32×32 transparent PNG format as Fire/Freeze.

## 🧱 Extending to the remaining 6 potions

The codebase is built so adding a new potion is mostly additive:

1. Add an entry to `PotionType` enum (`utils/PotionType.java`).
2. Add a `potions.<id>.*` block to `config.yml`.
3. Implement a new class in `abilities/` implementing the `Ability` interface
   (passive in `onHit`/`onEquip`, active in `activate`).
3. Register it in `AbilityRegistry`.
4. Add an icon entry to `HudManager.ICONS`.
5. Add the texture + model override + font entry to the resource pack, following
   the same pattern as Fire/Freeze/Regen.

No changes needed to `DrinkListener`, `CombatListener`, `SlotCommand`, `PotionGUI`,
or `HudManager`'s core loop — they all already iterate generically over whatever
`PotionType`s exist.

## 📋 Permissions

| Permission | Default | Description |
|---|---|---|
| `potionsmp.use` | true (everyone) | GUI, /slot1, /slot2, /potionSMP swap |
| `potionsmp.give` | op only | Give potions to players |
