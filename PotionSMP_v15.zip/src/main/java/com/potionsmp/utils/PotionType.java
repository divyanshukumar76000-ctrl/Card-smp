package com.potionsmp.utils;

public enum PotionType {

    FIRE     ("fire",     "&c&l🔥 Fire Potion"),
    FREEZE   ("freeze",   "&b&l❄ Freeze Potion"),
    REGEN    ("regen",    "&a&l❤ Regen Potion"),
    GLITCH   ("glitch",   "&d&l⚡ Glitch Potion"),
    SHIELD   ("shield",   "&f&l🛡 Shield Potion"),
    ENDER    ("ender",    "&8&l☠ Ender Potion"),
    TELEPORT ("teleport", "&5&l🌀 Teleport Potion");

    // Future:
    // AQUA    ("aqua",    "&3&l🌊 Aqua Potion"),
    // WARRIOR ("warrior", "&6&l⚔ Warrior Potion");

    private final String id;
    private final String displayName;

    PotionType(String id, String displayName) {
        this.id = id;
        this.displayName = displayName;
    }

    public String getId()          { return id; }
    public String getDisplayName() { return PotionUtils.colorize(displayName); }

    public static PotionType fromId(String id) {
        if (id == null) return null;
        for (PotionType t : values())
            if (t.id.equalsIgnoreCase(id)) return t;
        return null;
    }
}
