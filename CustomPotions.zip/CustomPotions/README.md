# CustomPotions Plugin

## Features
- 2 active potion slots
- Independent cooldowns
- Custom HUD with PlaceholderAPI + BetterHUD
- Resource Pack with icons

## Installation
1. Build the plugin (use Maven/Gradle - setup pom.xml if needed)
2. Place in plugins folder
3. Install PlaceholderAPI, BetterHUD
4. Place resourcepack in server resource-packs folder or auto-apply

## Resource Pack
Copy the resourcepack folder to your server and configure.

## Custom Potions
Edit config.yml to add more potions.

## HUD Example
[🔥 Fire Potion (30s)] [❄ Freeze (20s)]
XP Bar

Note: Implement full item creation, effect application, persistence, etc. for production.