package com.example.custompotions;

import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.entity.Player;

public class PotionPlaceholderExpansion extends PlaceholderExpansion {
    private final CustomPotions plugin;

    public PotionPlaceholderExpansion(CustomPotions plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getIdentifier() { return "potions"; }

    @Override
    public String getAuthor() { return "Grok"; }

    @Override
    public String getVersion() { return "1.0"; }

    @Override
    public String onPlaceholderRequest(Player player, String params) {
        if (player == null) return "";

        SlotManager slotManager = plugin.getSlotManager();
        PlayerSlots slots = slotManager.getPlayerSlots(player);

        if (params.startsWith("slot1_")) {
            ActivePotion slot = slots.getSlot1();
            if (slot == null) return getEmptySlot(params);
            if (params.endsWith("_icon")) return slot.getPotion().getIcon(); // or texture path
            if (params.endsWith("_name")) return slot.getPotion().getName();
            if (params.endsWith("_cooldown")) return String.valueOf(slot.getRemainingCooldown() / 1000);
        } else if (params.startsWith("slot2_")) {
            // similar
            ActivePotion slot = slots.getSlot2();
            if (slot == null) return getEmptySlot(params);
            // ...
        }
        return "";
    }

    private String getEmptySlot(String params) {
        if (params.endsWith("_icon")) return "empty.png";
        if (params.endsWith("_name")) return "Empty";
        if (params.endsWith("_cooldown")) return "0";
        return "";
    }
}