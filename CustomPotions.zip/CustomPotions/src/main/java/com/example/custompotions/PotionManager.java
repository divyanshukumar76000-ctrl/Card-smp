package com.example.custompotions;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.HashMap;
import java.util.Map;

public class PotionManager {
    private final CustomPotions plugin;
    private final Map<String, Potion> potions = new HashMap<>();

    public PotionManager(CustomPotions plugin) {
        this.plugin = plugin;
        loadPotions();
    }

    private void loadPotions() {
        ConfigurationSection potionsSection = plugin.getConfig().getConfigurationSection("potions");
        if (potionsSection == null) return;

        for (String key : potionsSection.getKeys(false)) {
            ConfigurationSection section = potionsSection.getConfigurationSection(key);
            if (section == null) continue;

            Potion potion = new Potion(
                key,
                section.getString("name", key),
                section.getString("material", "POTION"),
                section.getInt("duration", 200),
                section.getString("effect", ""),
                section.getLong("cooldown", 60),
                section.getString("icon", key + ".png")
            );
            potions.put(key, potion);
        }
    }

    public Potion getPotion(String id) {
        return potions.get(id);
    }

    public Map<String, Potion> getPotions() {
        return potions;
    }
}