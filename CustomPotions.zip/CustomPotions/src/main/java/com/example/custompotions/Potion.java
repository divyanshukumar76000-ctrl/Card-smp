package com.example.custompotions;

import org.bukkit.inventory.ItemStack;

public class Potion {
    private String id;
    private String name;
    private String material;
    private int duration; // ticks
    private String effect;
    private long cooldown; // seconds
    private String icon;

    public Potion(String id, String name, String material, int duration, String effect, long cooldown, String icon) {
        this.id = id;
        this.name = name;
        this.material = material;
        this.duration = duration;
        this.effect = effect;
        this.cooldown = cooldown;
        this.icon = icon;
    }

    // Getters
    public String getId() { return id; }
    public String getName() { return name; }
    public String getMaterial() { return material; }
    public int getDuration() { return duration; }
    public String getEffect() { return effect; }
    public long getCooldown() { return cooldown; }
    public String getIcon() { return icon; }

    public ItemStack createItem() {
        // TODO: Create custom item with meta
        return null; // Implement later
    }
}