package com.example.custompotions;

import org.bukkit.plugin.java.JavaPlugin;

public class HudManager {
    private final CustomPotions plugin;

    public HudManager(CustomPotions plugin) {
        this.plugin = plugin;
        // Setup BetterHUD integration if needed
    }

    // Methods to update HUD
}