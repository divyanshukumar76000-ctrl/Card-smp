package com.example.custompotions;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.Material;

public class PotionListener implements Listener {
    private final CustomPotions plugin;

    public PotionListener(CustomPotions plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onDrink(PlayerItemConsumeEvent event) {
        Player player = event.getPlayer();
        ItemStack item = event.getItem();
        if (item.getType() != Material.POTION) return;

        // Check if custom potion, e.g., by custom name or lore
        String potionId = detectPotion(item); // Implement detection
        if (potionId != null) {
            Potion potion = plugin.getPotionManager().getPotion(potionId);
            if (potion != null) {
                plugin.getSlotManager().applyPotion(player, potion);
                // Apply actual effects
            }
        }
    }

    private String detectPotion(ItemStack item) {
        // TODO: Use custom item data, PDC, etc.
        return null; // placeholder
    }
}