package com.example.custompotions;

import org.bukkit.entity.Player;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class CooldownManager {
    private final CustomPotions plugin;
    private final Map<UUID, Map<String, Long>> cooldowns = new HashMap<>();

    public CooldownManager(CustomPotions plugin) {
        this.plugin = plugin;
    }

    public void startCooldown(Player player, Potion potion) {
        cooldowns.computeIfAbsent(player.getUniqueId(), k -> new HashMap<>())
                .put(potion.getId(), System.currentTimeMillis() + potion.getCooldown() * 1000);
    }

    public long getRemainingCooldown(Player player, String potionId) {
        Map<String, Long> playerCd = cooldowns.get(player.getUniqueId());
        if (playerCd == null) return 0;
        Long end = playerCd.get(potionId);
        if (end == null) return 0;
        return Math.max(0, end - System.currentTimeMillis());
    }
}