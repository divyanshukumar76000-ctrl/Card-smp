package com.example.custompotions;

import org.bukkit.entity.Player;
import java.util.Deque;
import java.util.LinkedList;

public class PlayerSlots {
    private final CustomPotions plugin;
    private final Player player;
    private final Deque<ActivePotion> slots = new LinkedList<>(); // max 2

    public PlayerSlots(CustomPotions plugin, Player player) {
        this.plugin = plugin;
        this.player = player;
    }

    public void addPotion(Potion potion) {
        ActivePotion active = new ActivePotion(potion);
        if (slots.size() >= 2) {
            slots.pollFirst(); // remove oldest
        }
        slots.addLast(active);
    }

    public ActivePotion getSlot1() {
        return slots.size() > 0 ? slots.getFirst() : null; // adjust for FIFO
    }

    public ActivePotion getSlot2() {
        return slots.size() > 1 ? slots.getLast() : null;
    }

    // Getters for placeholders
}