package com.example.custompotions;

import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.Bukkit;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;

public class CustomPotions extends JavaPlugin {

    private PotionManager potionManager;
    private SlotManager slotManager;
    private CooldownManager cooldownManager;
    private HudManager hudManager;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        potionManager = new PotionManager(this);
        slotManager = new SlotManager(this);
        cooldownManager = new CooldownManager(this);
        hudManager = new HudManager(this);

        // Register listeners
        getServer().getPluginManager().registerEvents(new PotionListener(this), this);

        // Register placeholders
        if (Bukkit.getPluginManager().getPlugin("PlaceholderAPI") != null) {
            new PotionPlaceholderExpansion(this).register();
        }

        getLogger().info("CustomPotions enabled!");
    }

    @Override
    public void onDisable() {
        getLogger().info("CustomPotions disabled.");
    }

    public PotionManager getPotionManager() { return potionManager; }
    public SlotManager getSlotManager() { return slotManager; }
    public CooldownManager getCooldownManager() { return cooldownManager; }
    public HudManager getHudManager() { return hudManager; }
}