package com.example.custompotions;

import org.bukkit.entity.Player;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.NamespacedKey;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class SlotManager {
    private final CustomPotions plugin;
    private final Map<UUID, PlayerSlots> playerSlots = new HashMap<>();

    public SlotManager(CustomPotions plugin) {
        this.plugin = plugin;
    }

    public void applyPotion(Player player, Potion potion) {
        PlayerSlots slots = getPlayerSlots(player);
        slots.addPotion(potion);
        // Apply effects, start cooldowns etc.
        plugin.getCooldownManager().startCooldown(player, potion);
    }

    public PlayerSlots getPlayerSlots(Player player) {
        return playerSlots.computeIfAbsent(player.getUniqueId(), k -> new PlayerSlots(plugin, player));
    }

    // Load from persistence etc.
}