package com.example.custompotions;

public class ActivePotion {
    private final Potion potion;
    private long startTime;

    public ActivePotion(Potion potion) {
        this.potion = potion;
        this.startTime = System.currentTimeMillis();
    }

    public Potion getPotion() { return potion; }

    public long getRemainingCooldown() {
        // Calculate remaining time
        return Math.max(0, potion.getCooldown() * 1000 - (System.currentTimeMillis() - startTime));
    }

    public boolean isReady() {
        return getRemainingCooldown() <= 0;
    }
}