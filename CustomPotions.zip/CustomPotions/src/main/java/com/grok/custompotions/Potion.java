package com.grok.custompotions;

import org.bukkit.Material;
import org.bukkit.potion.PotionType;

public class Potion {
    private final String id;
    private final String name;
    private final Material material;
    private final PotionType potionType;
    private final int duration; // ticks
    private final int cooldown; // seconds
    private final String icon;

    public Potion(String id, String name, Material material, PotionType potionType, int duration, int cooldown, String icon) {
        this.id = id;
        this.name = name;
        this.material = material;
        this.potionType = potionType;
        this.duration = duration;
        this.cooldown = cooldown;
        this.icon = icon;
    }

    // Getters
    public String getId() { return id; }
    public String getName() { return name; }
    public Material getMaterial() { return material; }
    public PotionType getPotionType() { return potionType; }
    public int getDuration() { return duration; }
    public int getCooldown() { return cooldown; }
    public String getIcon() { return icon; }
}