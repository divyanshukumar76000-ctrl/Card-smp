package com.grok.custompotions;

import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class SlotManager {
    private final CustomPotions plugin;
    private final Map<UUID, PlayerSlots> playerSlots = new HashMap<>();

    public SlotManager(CustomPotions plugin) {
        this.plugin = plugin;
    }

    public void drinkPotion(Player player, Potion potion) {
        PlayerSlots slots = playerSlots.computeIfAbsent(player.getUniqueId(), k -> new PlayerSlots());
        ActivePotion active = new ActivePotion(potion, System.currentTimeMillis() + potion.getDuration() * 50L);
        slots.addPotion(active);
        plugin.getCooldownManager().startCooldown(player, potion);
        // Apply effects here
        player.sendMessage("§aDrank " + potion.getName() + "!");
    }

    public PlayerSlots getPlayerSlots(Player player) {
        return playerSlots.get(player.getUniqueId());
    }
}