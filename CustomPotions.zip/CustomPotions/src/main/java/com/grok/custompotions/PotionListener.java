package com.grok.custompotions;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionType;

public class PotionListener implements Listener {
    private final CustomPotions plugin;

    public PotionListener(CustomPotions plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onPotionDrink(PlayerItemConsumeEvent event) {
        ItemStack item = event.getItem();
        if (item.getType() != org.bukkit.Material.POTION) return;

        // Simple detection - improve with PDC/CustomModelData
        String potionId = detectPotion(item); 
        if (potionId == null) return;

        Potion potion = plugin.getPotionManager().getPotion(potionId);
        if (potion != null) {
            plugin.getSlotManager().drinkPotion(event.getPlayer(), potion);
        }
    }

    private String detectPotion(ItemStack item) {
        // Placeholder - use CustomModelData or name in production
        return "fire"; // or "freeze" based on logic
    }
}