package com.grok.custompotions;

public class ActivePotion {
    private final Potion potion;
    private final long expiryTime; // System.currentTimeMillis() + duration*50

    public ActivePotion(Potion potion, long expiryTime) {
        this.potion = potion;
        this.expiryTime = expiryTime;
    }

    public Potion getPotion() { return potion; }
    public long getExpiryTime() { return expiryTime; }
    public boolean isExpired() {
        return System.currentTimeMillis() > expiryTime;
    }
}