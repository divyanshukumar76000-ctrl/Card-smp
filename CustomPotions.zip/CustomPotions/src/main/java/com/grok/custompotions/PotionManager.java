package com.grok.custompotions;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;

import java.util.HashMap;
import java.util.Map;

public class PotionManager {
    private final CustomPotions plugin;
    private final Map<String, Potion> potions = new HashMap<>();

    public PotionManager(CustomPotions plugin) {
        this.plugin = plugin;
        loadPotions();
    }

    private void loadPotions() {
        FileConfiguration config = plugin.getConfig();
        ConfigurationSection section = config.getConfigurationSection("potions");
        if (section == null) return;

        for (String id : section.getKeys(false)) {
            ConfigurationSection pot = section.getConfigurationSection(id);
            if (pot == null) continue;

            String name = pot.getString("name", id);
            String matStr = pot.getString("material", "POTION");
            int duration = pot.getInt("duration", 200);
            int cooldown = pot.getInt("cooldown", 30);
            String icon = pot.getString("icon", id + ".png");

            Potion potion = new Potion(
                id,
                name,
                Material.valueOf(matStr),
                PotionType.HEALING, // Default, customize as needed
                duration,
                cooldown,
                icon
            );
            potions.put(id, potion);
            plugin.getLogger().info("Loaded potion: " + name);
        }
    }

    public Potion getPotion(String id) {
        return potions.get(id);
    }

    public Map<String, Potion> getPotions() {
        return potions;
    }
}