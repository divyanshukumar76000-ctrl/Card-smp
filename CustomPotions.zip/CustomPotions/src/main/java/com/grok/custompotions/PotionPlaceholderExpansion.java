package com.grok.custompotions;

import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

public class PotionPlaceholderExpansion extends PlaceholderExpansion {
    private final CustomPotions plugin;

    public PotionPlaceholderExpansion(CustomPotions plugin) {
        this.plugin = plugin;
    }

    @Override
    public @NotNull String getIdentifier() {
        return "potions";
    }

    @Override
    public @NotNull String getAuthor() {
        return "Grok";
    }

    @Override
    public @NotNull String getVersion() {
        return "1.0";
    }

    @Override
    public String onPlaceholderRequest(Player player, @NotNull String params) {
        if (player == null) return "";

        String[] parts = params.split("_");
        if (parts.length < 2) return "";

        String slot = parts[0]; // slot1 or slot2
        String type = parts[1]; // icon, name, cooldown

        int slotNum = slot.equals("slot1") ? 1 : 2;
        PlayerSlots slots = plugin.getSlotManager().getPlayerSlots(player);
        if (slots == null) {
            if (type.equals("icon")) return "empty";
            if (type.equals("name")) return "Empty";
            if (type.equals("cooldown")) return "0";
            return "";
        }

        ActivePotion active = slotNum == 1 ? slots.getSlot1() : slots.getSlot2();
        if (active == null || active.isExpired()) {
            if (type.equals("icon")) return "empty";
            if (type.equals("name")) return "Empty";
            if (type.equals("cooldown")) return "0";
            return "";
        }

        Potion potion = active.getPotion();
        if (type.equals("icon")) return potion.getIcon();
        if (type.equals("name")) return potion.getName();
        if (type.equals("cooldown")) {
            return String.valueOf(plugin.getCooldownManager().getRemainingCooldown(player, potion.getId()));
        }
        return "";
    }
}