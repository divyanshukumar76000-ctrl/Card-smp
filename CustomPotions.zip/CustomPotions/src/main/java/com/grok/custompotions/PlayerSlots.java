package com.grok.custompotions;

import java.util.ArrayDeque;
import java.util.Deque;

public class PlayerSlots {
    private final Deque<ActivePotion> slots = new ArrayDeque<>(2);

    public void addPotion(ActivePotion potion) {
        if (slots.size() >= 2) {
            slots.pollFirst(); // Remove oldest
        }
        slots.addLast(potion);
    }

    public ActivePotion getSlot1() {
        return slots.size() > 0 ? slots.peekFirst() : null; // For FIFO, first is oldest? Wait, adjust for slot1 newest/oldest
    }

    public ActivePotion getSlot2() {
        if (slots.size() == 2) return slots.peekLast();
        return null;
    }

    public Deque<ActivePotion> getSlots() {
        return slots;
    }
}