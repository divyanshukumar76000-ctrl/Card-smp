package com.grok.custompotions;

import org.bukkit.plugin.java.JavaPlugin;

public class CustomPotions extends JavaPlugin {

    private static CustomPotions instance;
    private PotionManager potionManager;
    private SlotManager slotManager;
    private CooldownManager cooldownManager;
    private PotionPlaceholderExpansion placeholderExpansion;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();

        potionManager = new PotionManager(this);
        slotManager = new SlotManager(this);
        cooldownManager = new CooldownManager(this);
        placeholderExpansion = new PotionPlaceholderExpansion(this);

        getServer().getPluginManager().registerEvents(new PotionListener(this), this);

        getLogger().info("CustomPotions has been enabled!");
        getLogger().info("Make sure to use the provided resource pack for icons.");
    }

    @Override
    public void onDisable() {
        getLogger().info("CustomPotions has been disabled.");
    }

    public static CustomPotions getInstance() {
        return instance;
    }

    public PotionManager getPotionManager() { return potionManager; }
    public SlotManager getSlotManager() { return slotManager; }
    public CooldownManager getCooldownManager() { return cooldownManager; }
}