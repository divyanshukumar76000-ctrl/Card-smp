package com.grok.custompotions;

import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class CooldownManager {
    private final Map<UUID, Map<String, Long>> cooldowns = new HashMap<>();

    public void startCooldown(Player player, Potion potion) {
        cooldowns.computeIfAbsent(player.getUniqueId(), k -> new HashMap<>())
                .put(potion.getId(), System.currentTimeMillis() + potion.getCooldown() * 1000L);
    }

    public int getRemainingCooldown(Player player, String potionId) {
        Map<String, Long> playerCd = cooldowns.get(player.getUniqueId());
        if (playerCd == null) return 0;
        Long end = playerCd.get(potionId);
        if (end == null) return 0;
        int remaining = (int) ((end - System.currentTimeMillis()) / 1000);
        return Math.max(0, remaining);
    }
}